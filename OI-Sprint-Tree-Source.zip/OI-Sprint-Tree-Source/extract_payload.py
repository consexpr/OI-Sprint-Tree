"""Extract runtime payload without running the executable: python extract_payload.py path/to/OI-Sprint-Tree.exe"""
from pathlib import Path
import sys
from PyInstaller.archive.readers import CArchiveReader

root=Path(__file__).resolve().parent
archive=CArchiveReader(sys.argv[1])
folder=root/'build/oi-sprint-tree/OI-Sprint-Tree/payload'
folder.mkdir(parents=True,exist_ok=True)
for name in ('runtime.tar.gz','oi-sprint-tree-agent.exe','oi-sprint-relay.exe','version.txt'):
    key=next(k for k in archive.toc if k.replace(chr(92),'/')=='payload/'+name)
    (folder/name).write_bytes(archive.extract(key))
print(folder)
