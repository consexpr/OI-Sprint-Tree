"""Authenticated, headless TLS service. SSH is not involved in its lifetime."""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
from pathlib import Path
import queue
import re
import shutil
import socket
import ssl
import threading
import time
import uuid

import wire
from runtime import Box, InfrastructureError
from worker import Worker, encoded


class Service:
    def __init__(self, root, settings):
        self.root, self.settings = Path(root), settings
        self.owner = threading.Lock()
        self.context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        self.context.minimum_version = ssl.TLSVersion.TLSv1_2
        self.context.load_cert_chain(settings["certificate"], settings["private_key"])

    def session(self, connection):
        files = {}
        worker = None
        owned = False
        closing = threading.Event()
        outgoing = queue.Queue(maxsize=8192)
        send_lock=threading.Lock()

        def enqueue(header):
            try:
                outgoing.put_nowait(header)
            except queue.Full:
                closing.set()
                connection.shutdown(socket.SHUT_RDWR)
                raise ConnectionError("结果回报队列已满，断线后由上级收回未确认任务")

        def emit(line):
            enqueue({"op": "event", "line": line})

        def writer():
            while not closing.is_set():
                try:
                    item = outgoing.get(timeout=2)
                except queue.Empty:
                    item = {"op": "event", "line": "PONG"}
                try:
                    with send_lock:wire.send(connection, item)
                except Exception:
                    closing.set()
                    try: connection.shutdown(socket.SHUT_RDWR)
                    except OSError: pass
                    return

        try:
            connection.settimeout(15)
            request, payload = wire.receive(connection)
            if request.get("op") != "authenticate" or payload or not hmac.compare_digest(
                    str(request.get("token", "")), self.settings["token"]):
                return
            owned = self.owner.acquire(blocking=False)
            if not owned:
                wire.send(connection, {"op": "event", "line": "FATAL " + encoded("节点已有有效上级连接")})
                return
            worker = Worker(self.root, self.settings, emit)
            probe = Box(worker.isolate, worker.boxes.get())
            try:
                probe.initialize()
                status, detail, _ = probe.run(["/bin/true"], 1000, 256, closing)
                if status != "OK":
                    raise InfrastructureError("Linux 沙箱自检失败：" + detail)
            finally:
                try: probe.close()
                finally: worker.boxes.put(probe.id)
            wire.send(connection, {"op": "event", "line": worker.hello()})
            threading.Thread(target=writer, daemon=True, name="results").start()
            connection.settimeout(45)
            while not closing.is_set():
                request, payload = wire.receive(connection)
                op = request.get("op")
                if op == "ping":
                    emit("PONG")
                elif op == "configure":
                    worker.configure(request["compile_limit"], request["cpu_limit"])
                elif op == "task":
                    worker.submit(request["task"])
                elif op in ("kill", "yield"):
                    worker.cancel(int(request["id"]), op == "yield")
                elif op == "reset":
                    rid=request['request']
                    if not isinstance(rid,str) or not re.fullmatch(r'[a-f0-9]{32}',rid):
                        raise ValueError('invalid reset identity')
                    worker.close();worker=None
                    for name in ('data','compile-cache'):
                        folder=self.root/name
                        if folder.is_symlink():folder.unlink()
                        elif folder.exists():shutil.rmtree(folder)
                    worker=Worker(self.root,self.settings,emit)
                    enqueue({'op':'reset_done','request':rid})
                elif op == "offer":
                    version, name, digest, size = (request[k] for k in ("version", "name", "sha256", "size"))
                    if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", version) or not re.fullmatch(r"[A-Za-z0-9_-]{1,120}\.(in|ans)", name):
                        raise ValueError("invalid data path")
                    if not re.fullmatch(r"[0-9a-f]{64}", digest) or type(size) is not int or not 0 <= size <= 32 << 30:
                        raise ValueError("invalid data descriptor")
                    if len(files) >= 4:
                        raise ValueError("too many simultaneous uploads")
                    target = self.root / "data" / version / name
                    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                    manifest = target.with_name(name + ".verified")
                    descriptor = {"sha256": digest, "size": size}
                    valid = False
                    try:
                        previous = json.loads(manifest.read_text())
                        info = target.stat()
                        valid = (previous == {**descriptor, "mtime_ns": info.st_mtime_ns, "inode": info.st_ino}
                                 and info.st_size == size and not target.is_symlink())
                    except (OSError, ValueError):
                        pass
                    rid = request["request"]
                    if not isinstance(rid, str) or not re.fullmatch(r"[a-f0-9]{32}", rid) or rid in files:
                        raise ValueError("invalid upload identity")
                    if valid:
                        enqueue({"op": "offered", "request": rid, "needed": False})
                    else:
                        temporary = target.with_name(name + ".partial-" + uuid.uuid4().hex)
                        files[rid] = dict(target=target, path=temporary, stream=open(temporary, "xb"),
                                          hash=hashlib.sha256(), received=0, **descriptor)
                        enqueue({"op": "offered", "request": rid, "needed": True})
                elif op == "chunk":
                    item = files[request["request"]]
                    if item["received"] + len(payload) > item["size"]:
                        raise ValueError("upload exceeds declared size")
                    item["stream"].write(payload); item["hash"].update(payload)
                    item["received"] += len(payload)
                elif op == "commit":
                    rid = request["request"]
                    item = files[rid]
                    item["stream"].flush(); os.fsync(item["stream"].fileno()); item["stream"].close()
                    if item["received"] != item["size"] or item["hash"].hexdigest() != item["sha256"]:
                        raise ValueError("transferred data is incomplete or corrupted")
                    os.chmod(item["path"], 0o400)
                    os.replace(item["path"], item["target"])
                    info = item["target"].stat()
                    manifest = item["target"].with_name(item["target"].name + ".verified")
                    temp_manifest = manifest.with_suffix(".tmp")
                    temp_manifest.write_text(json.dumps({"sha256": item["sha256"], "size": item["size"],
                                                         "mtime_ns": info.st_mtime_ns, "inode": info.st_ino}))
                    os.replace(temp_manifest, manifest)
                    files.pop(rid)
                    enqueue({"op": "committed", "request": rid})
                else:
                    raise ValueError("unknown protocol operation")
        except Exception as error:
            try:
                message = {"op": "event", "line": "FATAL " + encoded(str(error)[:500])}
                with send_lock:wire.send(connection, message)
            except Exception:
                pass
        finally:
            closing.set()
            try: connection.shutdown(socket.SHUT_RDWR)
            except OSError: pass
            connection.close()
            try:
                if worker:worker.close()
            finally:
                for item in files.values():
                    item["stream"].close(); item["path"].unlink(missing_ok=True)
                if owned:self.owner.release()

    def serve(self):
        listener = socket.socket()
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((self.settings.get("bind", "0.0.0.0"), self.settings.get("port", 8877)))
        listener.listen(16)
        while True:
            connection, _ = listener.accept()
            # TLS handshakes must not serialize acceptance of all other connections.
            threading.Thread(target=self.accept, args=(connection,), daemon=True).start()

    def accept(self, connection):
        try:
            connection.settimeout(10)
            secure = self.context.wrap_socket(connection, server_side=True)
        except Exception:
            connection.close()
            return
        self.session(secure)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = Path(args.config)
    if os.name != "posix" or not Path("/proc/sys/kernel/ostype").is_file():
        raise SystemExit("必须在 Linux 内运行，不支持 Windows 原生执行")
    settings = json.loads(config.read_text())
    if len(settings.get("token", "")) < 32:
        raise SystemExit("接入密钥长度不足")
    Service(settings["root"], settings).serve()


if __name__ == "__main__":
    main()
