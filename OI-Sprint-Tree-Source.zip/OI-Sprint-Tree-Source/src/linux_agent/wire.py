"""Length-delimited JSON headers and bounded binary chunks over one TLS connection."""
import json
import struct

HEADER_LIMIT = 4 << 20
CHUNK_LIMIT = 1 << 20


def exact(stream, count):
    chunks = bytearray()
    while len(chunks) < count:
        part = stream.recv(count - len(chunks))
        if not part:
            raise EOFError("connection closed")
        chunks.extend(part)
    return bytes(chunks)


def receive(stream):
    size = struct.unpack("!I", exact(stream, 4))[0]
    if not 1 <= size <= HEADER_LIMIT:
        raise ValueError("invalid protocol header length")
    header = json.loads(exact(stream, size))
    if not isinstance(header, dict):
        raise ValueError("protocol header must be an object")
    size = header.get("bytes", 0)
    if type(size) is not int or not 0 <= size <= CHUNK_LIMIT:
        raise ValueError("invalid protocol chunk length")
    return header, exact(stream, size)


def send(stream, header, payload=b""):
    if len(payload) > CHUNK_LIMIT:
        raise ValueError("protocol chunk too large")
    header = {**header, "bytes": len(payload)}
    encoded = json.dumps(header, separators=(",", ":"), ensure_ascii=True).encode()
    if len(encoded) > HEADER_LIMIT:
        raise ValueError("protocol header too large")
    stream.sendall(struct.pack("!I", len(encoded)) + encoded + payload)
