"""Linux-only execution primitives. No Windows fallback is permitted."""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import platform
import shutil
import signal
import stat
import subprocess
import tempfile
import threading
import time


class InfrastructureError(RuntimeError):
    pass


class Cancelled(Exception):
    pass


def metadata(path):
    result = {}
    try:
        for line in Path(path).read_text().splitlines():
            key, value = line.split(":", 1)
            if key in result:
                raise ValueError("duplicate metadata key")
            result[key] = value
    except (OSError, ValueError) as error:
        raise InfrastructureError("无法读取完整的沙箱运行信息") from error
    return result


def classify(meta, returncode, limit_ms):
    """Fail closed on absent accounting; never turn low-CPU wall timeout into TLE."""
    if returncode not in (0, 1) or meta.get("status") == "XX":
        return "SE", meta.get("message", "沙箱执行失败")
    try:
        cpu = float(meta["time"])
        wall = float(meta["time-wall"])
        memory = int(meta["cg-mem"])
        if not all(math.isfinite(v) and v >= 0 for v in (cpu, wall, memory)):
            raise ValueError()
    except (KeyError, ValueError):
        return "SE", "沙箱未返回有效的 CPU 时间、墙钟时间或 cgroup 内存统计"
    if meta.get("cg-oom-killed", "0") not in ("0", ""):
        return "MLE", "超过内存限制，被 Linux OOM 终止"
    if cpu * 1000 >= limit_ms:
        return "TLE", "超过 CPU 时间限制"
    if meta.get("status") == "TO":
        return "SE", "墙钟保护超时，但 CPU 时间未达到题目时限"
    if meta.get("exitsig") == str(getattr(signal, "SIGXFSZ", 25)):
        return "OLE", "超过输出文件限制"
    if meta.get("status") in ("SG", "RE") or meta.get("exitsig") or meta.get("exitcode", "0") != "0":
        return "RE", meta.get("message", "程序异常退出")
    if meta.get("status") not in (None, ""):
        return "SE", "未知沙箱状态"
    return "OK", ""


def open_regular(path, maximum):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError("输出不是普通文件")
        if info.st_size > maximum:
            raise OverflowError("输出超过限制")
        return os.fdopen(fd, "rb")
    except BaseException:
        os.close(fd)
        raise


def compare_files(output, answer, maximum=256 << 20):
    """Line-preserving comparison; only trim horizontal line ends and final empty lines."""
    try:
        actual = open_regular(output, maximum)
    except FileNotFoundError:
        return "WA", "没有生成指定的输出文件"
    except OverflowError:
        return "OLE", "超过输出大小限制"
    except (ValueError, OSError):
        return "RE", "输出文件无效或不可读取"
    with actual, open(answer, "rb") as expected:
        line = 0
        while True:
            left = actual.readline(maximum + 1)
            right = expected.readline(maximum + 1)
            if len(left) > maximum or len(right) > maximum:
                return "OLE", "单行内容超过比较器限制"
            line += 1
            if not left and not right:
                return "AC", ""
            if not left or not right:
                remaining = right if not left else left
                source = expected if not left else actual
                if remaining.strip(b" \t\r\n"):
                    return "WA", f"第 {line} 行：输出行数或内容不同"
                for remaining in source:
                    if remaining.strip(b" \t\r\n"):
                        return "WA", f"第 {line} 行之后存在多余内容"
                return "AC", ""
            a = left.rstrip(b"\r\n").rstrip(b" \t")
            b = right.rstrip(b"\r\n").rstrip(b" \t")
            if a != b:
                def excerpt(value):
                    return value[:120].decode("utf8", "replace")
                return "WA", f"第 {line} 行，应为 {excerpt(b)}，实际 {excerpt(a)}"


class CpuBudget:
    """A dedicated ancestor must contain both the agent and all Isolate groups."""
    def __init__(self, root, isolate):
        self.root = Path(root).resolve()
        if self.root != Path("/sys/fs/cgroup/oisprintlinux"):
            raise InfrastructureError("CPU 控制目录必须属于专用 oi-sprint-linux cgroup")
        try:
            cg_root = Path(subprocess.check_output([isolate, "--print-cg-root"], timeout=10,
                                                  stderr=subprocess.PIPE).decode().strip()).resolve()
            own = next(line.split("::", 1)[1] for line in Path("/proc/self/cgroup").read_text().splitlines()
                       if line.startswith("0::"))
            agent_group = Path("/sys/fs/cgroup" + own).resolve()
            if not cg_root.is_relative_to(self.root) or not agent_group.is_relative_to(self.root):
                raise ValueError("agent/Isolate outside common ancestor")
            if "cpu" not in (self.root / "cgroup.controllers").read_text().split():
                raise ValueError("CPU controller unavailable")
            if not os.access(self.root / "cpu.max", os.W_OK):
                raise ValueError("CPU quota not writable")
        except Exception as error:
            raise InfrastructureError("Linux cgroup 未正确配置，无法同时限制编译和运行") from error
        self.cores = len(os.sched_getaffinity(0))
        self.percent = 100

    def configure(self, percent):
        if type(percent) is not int or not 1 <= percent <= 100:
            raise ValueError("CPU 上限必须为 1 到 100")
        period = 100000
        quota = max(1000, self.cores * percent * period // 100)
        (self.root / "cpu.max").write_text(f"{quota} {period}\n")
        self.percent = percent


class Box:
    def __init__(self, isolate, box_id):
        self.isolate, self.id = isolate, box_id
        self.folder = None
        self.current = None
        self.lock = threading.Lock()

    def command(self, *args):
        return [self.isolate, "--cg", f"--box-id={self.id}", *args]

    def initialize(self):
        result = subprocess.run(self.command("--init"), stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
        if result.returncode:
            raise InfrastructureError("初始化 Isolate 失败：" + result.stderr.decode("utf8", "replace")[:300])
        self.folder = Path(result.stdout.decode().strip()) / "box"
        if not self.folder.is_dir():
            raise InfrastructureError("Isolate 未创建工作目录")

    def run(self, argv, cpu_ms, memory_mb, stop, *, compile=False, input_dir=None, stdin=None,
            stdout="stdout.txt", stderr="stderr.txt", output_limit=256 << 20, cpu_percent=100):
        meta = self.folder.parent / "execution.meta"
        meta.unlink(missing_ok=True)
        wall = max(30, cpu_ms / 1000 * 10 * 100 / max(1, cpu_percent) + 5)
        # Explicit mounts avoid inheriting host /mnt, Windows interop and answer directories.
        options = ["--no-default-dirs", f"--dir=/box={self.folder}:rw", "--dir=/dev:dev:norec",
                   "--dir=/proc=proc:fs", "--dir=/tmp:tmp", "--dir=/usr", "--dir=/lib",
                   "--dir=/lib64:maybe", "--dir=/bin", "--chdir=/box",
                   f"--meta={meta}", f"--time={cpu_ms / 1000:.6f}", f"--wall-time={wall:.3f}",
                   f"--cg-mem={memory_mb * 1024}", f"--stack={memory_mb * 1024}",
                   f"--fsize={output_limit // 1024}", "--open-files=128", "--core=0",
                   f"--stdout={stdout}", f"--stderr={stderr}", "--env=PATH=/usr/bin:/bin", "--env=LANG=C"]
        if compile:
            options.append("--processes=64")
        if input_dir:
            options.append(f"--dir=/input={input_dir}")
        if stdin:
            options.append(f"--stdin={stdin}")
        if stop.is_set():
            raise Cancelled()
        with self.lock:
            proc = self.current = subprocess.Popen(self.command(*options, "--run", "--", *argv),
                                                   stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                                   stderr=subprocess.PIPE, start_new_session=True)
        try:
            while True:
                try:
                    _, diagnostic = proc.communicate(timeout=.2)
                    break
                except subprocess.TimeoutExpired:
                    if stop.is_set():
                        os.killpg(proc.pid, signal.SIGKILL)
                        proc.communicate()
                        raise Cancelled()
            if stop.is_set():
                raise Cancelled()
            if not meta.is_file():
                raise InfrastructureError("沙箱未生成运行信息：" + diagnostic.decode("utf8", "replace")[:300])
            info = metadata(meta)
            status, detail = classify(info, proc.returncode, cpu_ms)
            return status, detail, info
        finally:
            with self.lock:
                self.current = None

    def close(self):
        # A fresh cgroup per execution avoids charging previous test file caches as memory.
        result = subprocess.run(self.command("--cleanup"), stdout=subprocess.DEVNULL,
                                stderr=subprocess.PIPE, timeout=20)
        self.folder = None
        if result.returncode:
            raise InfrastructureError("沙箱清理失败，不能复用该执行槽位")


class CompilerCache:
    def __init__(self, root, compiler, maximum=2 << 30):
        self.root, self.compiler, self.maximum = Path(root), compiler, maximum
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.version = subprocess.check_output([compiler, "--version"], timeout=10).decode()
        self.target = subprocess.check_output([compiler, "-dumpmachine"], timeout=10).decode().strip()
        self.locks = {}
        self.guard = threading.Lock()
        self.reserved = 0
        self.used = sum(p.stat().st_size for p in self.root.iterdir() if len(p.name)==64 and p.is_file())

    def key(self, code, args, stack_mb):
        descriptor = json.dumps([self.version, self.target, platform.machine(), args, stack_mb], ensure_ascii=True)
        return hashlib.sha256(descriptor.encode() + b"\0" + code).hexdigest()

    def lock_for(self, key):
        with self.guard:
            return self.locks.setdefault(key, threading.Lock())

    def restore(self, key, destination):
        path = self.root / key
        manifest = self.root / (key + ".json")
        try:
            expected = json.loads(manifest.read_text())
            with open_regular(path, 256 << 20) as source, open(destination, "xb") as target:
                digest = hashlib.sha256()
                while chunk := source.read(1 << 20):
                    target.write(chunk); digest.update(chunk)
            with open(destination,"rb") as header:
                elf=header.read(4)
            if digest.hexdigest() != expected["sha256"] or elf != b"\x7fELF":
                raise ValueError("corrupt cached executable")
            os.chmod(destination, 0o555)
            os.utime(path, None)
            return True
        except (OSError, ValueError, KeyError):
            Path(destination).unlink(missing_ok=True)
            return False

    def store(self, key, program):
        size=program.stat().st_size
        if size > 256 << 20:
            return
        with self.guard:
            self._evict(size)
            if self.used+self.reserved+size>self.maximum:
                return  # Cache pressure must never prevent judging a successful compilation.
            self.reserved+=size
        temporary = self.root / (key + ".tmp-" + str(threading.get_native_id()))
        try:
            shutil.copyfile(program, temporary)
            digest = hashlib.sha256(temporary.read_bytes()).hexdigest()
            os.chmod(temporary, 0o500)
            old_size=(self.root/key).stat().st_size if (self.root/key).is_file() else 0
            os.replace(temporary, self.root / key)
            with self.guard:self.used+=size-old_size
            manifest = self.root / (key + ".json.tmp")
            manifest.write_text(json.dumps({"sha256": digest}))
            os.replace(manifest, self.root / (key + ".json"))
        finally:
            temporary.unlink(missing_ok=True)
            with self.guard:self.reserved-=size

    def prune(self):
        with self.guard:
            self._evict(0)

    def _evict(self, required):
        if self.used+self.reserved+required<=self.maximum:return
        entries = sorted((p for p in self.root.iterdir() if len(p.name) == 64 and p.is_file()), key=lambda p: p.stat().st_mtime)
        for path in entries:
            if self.used+self.reserved+required<=self.maximum:break
            lock = self.locks.setdefault(path.name, threading.Lock())
            if not lock.acquire(blocking=False):continue
            try:
                size=path.stat().st_size
                path.unlink();self.used-=size
                path.with_name(path.name + ".json").unlink(missing_ok=True)
            finally:lock.release()
