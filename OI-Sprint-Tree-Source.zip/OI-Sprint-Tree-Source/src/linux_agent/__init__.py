"""Linux execution service and its transport protocol."""
