"""Prepare the dedicated cgroup subtree, then replace this process with the daemon."""
import argparse
import json
import os
from pathlib import Path
import sys


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--config',required=True)
    args=parser.parse_args()
    if os.geteuid()!=0:
        raise SystemExit('Linux 节点启动需要专用发行版中的 root 权限；考生程序由 Isolate 降权')
    config=Path(args.config)
    settings=json.loads(config.read_text())
    root=Path('/sys/fs/cgroup')
    if not (root/'cgroup.controllers').is_file():
        raise SystemExit('需要 cgroup v2')
    required={'cpu','memory','pids'}
    if not required.issubset(set((root/'cgroup.controllers').read_text().split())):
        raise SystemExit('内核未提供完整的 CPU、内存、进程数控制器')
    (root/'cgroup.subtree_control').write_text('+cpu +memory +pids')
    parent=root/'oisprintlinux';parent.mkdir(exist_ok=True)
    agent=parent/'agent';agent.mkdir(exist_ok=True)
    (agent/'cgroup.procs').write_text(str(os.getpid()))
    (parent/'cgroup.subtree_control').write_text('+cpu +memory +pids')
    boxes=parent/'boxes';boxes.mkdir(exist_ok=True)
    (boxes/'cgroup.subtree_control').write_text('+cpu +memory +pids')
    # Swapped pages must not escape the contest memory budget.
    (parent/'memory.swap.max').write_text('0')
    settings['cgroup_root']=str(parent)
    temporary=config.with_suffix('.tmp')
    temporary.write_text(json.dumps(settings));os.chmod(temporary,0o600);os.replace(temporary,config)
    os.execv(sys.executable,[sys.executable,str(Path(__file__).with_name('server.py')),'--config',str(config)])


if __name__=='__main__':main()
