"""Persistent Linux worker; one task compiles once and evaluates a batch of cases."""
from __future__ import annotations

import base64
from concurrent.futures import ThreadPoolExecutor
import fcntl
import json
import os
from pathlib import Path
import queue
import re
import shutil
import tempfile
import threading
import time

from runtime import Box, Cancelled, CompilerCache, CpuBudget, InfrastructureError, compare_files

PROTOCOL = "OI-SPRINT-LINUX/1"
IDENTIFIER = re.compile(r"^[A-Za-z0-9_-]{1,100}$")


def encoded(text):
    return base64.b64encode(str(text).encode()).decode() or "-"


class Work:
    def __init__(self, raw):
        self.id = raw["id"]
        self.problem = raw["problem"]
        self.tests = raw["tests"]
        self.cpu_ms, self.memory_mb = raw["cpu_ms"], raw["memory_mb"]
        self.source = base64.b64decode(raw["source"], validate=True)
        self.io = raw.get("io", "file")
        self.input_name = raw.get("input_name", self.problem + ".in")
        self.output_name = raw.get("output_name", self.problem + ".out")
        self.data_version = raw["data_version"]
        if type(self.id) is not int or self.id < 1 or not IDENTIFIER.fullmatch(self.problem):
            raise ValueError("无效的任务身份")
        if not IDENTIFIER.fullmatch(self.data_version):
            raise ValueError("无效的数据版本")
        if not self.tests or len(self.tests) > 100000 or len(set(self.tests)) != len(self.tests) or any(type(t) is not int or t < 1 for t in self.tests):
            raise ValueError("无效的测点列表")
        if type(self.cpu_ms) is not int or not 1 <= self.cpu_ms <= 3600000:
            raise ValueError("无效的时间限制")
        if type(self.memory_mb) is not int or not 1 <= self.memory_mb <= 1048576:
            raise ValueError("无效的内存限制")
        if len(self.source) > 2 << 20 or self.io not in ("file", "stdio"):
            raise ValueError("无效的源码或输入输出模式")
        for name in (self.input_name, self.output_name):
            if not re.fullmatch(r"[A-Za-z0-9_.-]{1,120}", name) or name in (".", "..", "program", "stdout.txt", "stderr.txt", "source.cpp"):
                raise ValueError("输入输出文件名无效或与内部文件冲突")
        if self.input_name == self.output_name:
            raise ValueError("输入输出文件名不能相同")
        self.stop = threading.Event()
        self.yield_requested = threading.Event()


class Worker:
    def __init__(self, root, settings, emit):
        self.root, self.emit = Path(root), emit
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.root, 0o700)
        self.lock_file = open(self.root / "agent.lock", "a")
        try:
            fcntl.flock(self.lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            raise InfrastructureError("该 Linux 节点已经运行，拒绝重复启动") from error
        self.isolate = settings.get("isolate", "/opt/oi-sprint-linux/bin/isolate")
        self.cache = CompilerCache(self.root / "compile-cache", settings.get("compiler", "/usr/bin/g++"))
        self.budget = CpuBudget(settings["cgroup_root"], self.isolate)
        self.budget.configure(100)
        self.lock = threading.RLock()
        self.compile_condition = threading.Condition(self.lock)
        self.compile_limit = 1
        self.compile_active = self.compile_waiting = self.cache_hits = 0
        self.tasks = {}
        self.closed = False
        # This ceiling is independent from the currently advertised task concurrency.
        self.boxes = queue.Queue()
        maximum = min(256, max(4, self.budget.cores * 2))
        for index in range(maximum):
            self.boxes.put(index)
        self.pool = ThreadPoolExecutor(max_workers=maximum, thread_name_prefix="judge")
        self.memory_mb = int(next(line.split()[1] for line in Path("/proc/meminfo").read_text().splitlines()
                                  if line.startswith("MemTotal:"))) // 1024

    def hello(self):
        # No invented calibration speed: fixed limits until a measured curve is implemented.
        return f"HELLO 1 {self.budget.cores} {self.budget.cores} 0 {self.memory_mb} 1:0:0 isolate-cgroup2 {PROTOCOL}"

    def stats(self):
        self.emit(f"STATS {self.compile_active} {self.compile_waiting} {self.cache_hits}")

    def configure(self, compile_limit, percent):
        if type(compile_limit) is not int or not 1 <= compile_limit <= 256:
            raise ValueError("无效的编译并发")
        self.budget.configure(percent)
        with self.compile_condition:
            self.compile_limit = compile_limit
            self.compile_condition.notify_all()
        self.emit(f"CONFIG_OK {percent}")

    def submit(self, raw):
        task = Work(raw)
        with self.lock:
            if self.closed or len(self.tasks) >= 256 or task.id in self.tasks:
                raise ValueError("任务队列已满或任务身份重复")
            self.tasks[task.id] = task
        self.pool.submit(self.run, task)

    def cancel(self, tid, yield_only=False):
        with self.compile_condition:
            task = self.tasks.get(tid)
            if task:
                (task.yield_requested if yield_only else task.stop).set()
                self.compile_condition.notify_all()

    def compile(self, task, destination):
        arguments = ["-std=c++14", "-O2", "-static", "source.cpp", "-o", "program"]
        key = self.cache.key(task.source, arguments, task.memory_mb)
        lock = self.cache.lock_for(key)
        while not lock.acquire(timeout=.2):
            if task.stop.is_set() or task.yield_requested.is_set():
                raise Cancelled()
        try:
            if self.cache.restore(key, destination):
                with self.lock:
                    self.cache_hits += 1
                    self.stats()
                self.emit(f"COMPILE {task.id} OK 0 - HIT")
                return True
            acquired = False
            with self.compile_condition:
                self.compile_waiting += 1
                self.stats()
                try:
                    while self.compile_active >= self.compile_limit:
                        if task.stop.is_set() or task.yield_requested.is_set():
                            raise Cancelled()
                        self.compile_condition.wait(.2)
                    if task.stop.is_set() or task.yield_requested.is_set():
                        raise Cancelled()
                    self.compile_active += 1
                    acquired = True
                finally:
                    self.compile_waiting -= 1
                    self.stats()
            box_id = self.boxes.get()
            box = Box(self.isolate, box_id)
            try:
                box.initialize()
                (box.folder / "source.cpp").write_bytes(task.source)
                os.chmod(box.folder / "source.cpp", 0o444)
                status, detail, meta = box.run([self.cache.compiler, *arguments], 30000, 3072,
                                              task.stop, compile=True, output_limit=16 << 20,
                                              cpu_percent=self.budget.percent)
                log_path = box.folder / "stderr.txt"
                from runtime import open_regular
                with open_regular(log_path, 16 << 20) as log_file:
                    log = log_file.read(12000).decode("utf8", "replace")
                ms = round(float(meta.get("time", 0)) * 1000)
                # Only an ordinary compiler rejection is CE. Resource/system failures are SE.
                if status == "RE" and meta.get("exitcode") == "1" and not meta.get("exitsig"):
                    self.emit(f"COMPILE {task.id} CE {ms} {encoded(log)}")
                    return False
                if status != "OK":
                    raise InfrastructureError(detail or "编译资源超限或编译器异常")
                from runtime import open_regular
                with open_regular(box.folder / "program", 256 << 20) as source, open(destination, "xb") as output:
                    if source.read(4) != b"\x7fELF":
                        raise InfrastructureError("编译器未生成 Linux ELF")
                    source.seek(0); shutil.copyfileobj(source, output)
                os.chmod(destination, 0o555)
                try:self.cache.store(key, Path(destination))
                except OSError:pass  # Optional cache writes cannot invalidate a successful compilation.
                self.emit(f"COMPILE {task.id} OK {ms} {encoded(log)}")
                return True
            finally:
                try:
                    box.close()
                finally:
                    self.boxes.put(box_id)
                    with self.compile_condition:
                        if acquired:
                            self.compile_active -= 1
                        self.stats(); self.compile_condition.notify_all()
        finally:
            lock.release()

    def run_case(self, task, test, program):
        source = self.root / "data" / task.data_version / (task.problem + str(test) + ".in")
        answer = source.with_suffix(".ans")
        if not source.is_file() or not answer.is_file():
            raise InfrastructureError("分配的测点数据尚未完整到达")
        box_id = self.boxes.get()
        box = Box(self.isolate, box_id)
        try:
            box.initialize()
            shutil.copyfile(program, box.folder / "program")
            os.chmod(box.folder / "program", 0o555)
            with tempfile.TemporaryDirectory(dir=self.root, prefix="input-") as private:
                # Only this case's input is mounted read-only, never its answer or the data pool.
                shutil.copyfile(source, Path(private) / "input.in")
                os.chmod(private, 0o755); os.chmod(Path(private) / "input.in", 0o444)
                if task.io == "file":
                    os.symlink("/input/input.in", box.folder / task.input_name)
                status, detail, meta = box.run(["./program"], task.cpu_ms, task.memory_mb, task.stop,
                                              input_dir=private, stdin="/input/input.in",
                                              cpu_percent=self.budget.percent)
                if status == "OK":
                    output = box.folder / (task.output_name if task.io == "file" else "stdout.txt")
                    status, detail = compare_files(output, answer)
                return (status, round(float(meta.get("time", 0)) * 1000),
                        round(float(meta.get("time-wall", 0)) * 1000), int(meta.get("cg-mem", 0)), detail)
        finally:
            try:
                box.close()
            finally:
                self.boxes.put(box_id)

    def run(self, task):
        try:
            with tempfile.TemporaryDirectory(dir=self.root, prefix="submission-") as folder:
                if not self.compile(task, Path(folder) / "program"):
                    return
                for test in task.tests:
                    if task.stop.is_set() or task.yield_requested.is_set():
                        raise Cancelled()
                    status, cpu, wall, memory, detail = self.run_case(task, test, Path(folder) / "program")
                    self.emit(f"TEST {task.id} {test} {status} {cpu} {wall} {memory} {encoded(detail)}")
        except Cancelled:
            pass
        except Exception as error:
            self.emit(f"COMPILE {task.id} SE 0 {encoded(str(error)[:500])}")
        finally:
            if task.yield_requested.is_set():
                self.emit(f"YIELDED {task.id}")
            self.emit(f"DONE {task.id}")
            with self.lock:
                self.tasks.pop(task.id, None)
            try:
                self.cache.prune()
            except OSError:
                pass

    def close(self):
        with self.compile_condition:
            if self.closed:return
            self.closed = True
            for task in self.tasks.values():
                task.stop.set()
            self.compile_condition.notify_all()
        self.pool.shutdown(wait=True, cancel_futures=False)
        fcntl.flock(self.lock_file, fcntl.LOCK_UN)
        self.lock_file.close()
