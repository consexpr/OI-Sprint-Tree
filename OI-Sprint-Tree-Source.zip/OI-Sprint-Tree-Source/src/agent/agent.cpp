// Judge agent (Windows). Long-lived worker driven over stdin/stdout by the master.
// Build: g++ -std=c++17 -O2 -static -municode agent.cpp -o agent.exe -ladvapi32 -lpsapi
//
// Protocol (one line per message, space separated):
//   master -> agent:  TASK <id> <problem> <tl_ms> <ml_mb> <flags> <tests,csv> <b64 source>
//                     KILL <id> | PING | QUIT
//   agent -> master:  HELLO <build> <logical> <physical> <perf_cores> <mem_mb> <speed curve> <sandbox>
//                     COMPILE <id> OK|CE <ms> <b64 log>
//                     TEST <id> <test> <status> <cpu_ms> <wall_ms> <mem_kb> <b64 detail>
//                     DONE <id> | PONG
//
// Student code (and the compiler) runs under a token with: Low integrity, every privilege
// removed, Administrators deny-only, inside a job with no child processes (students), no
// ExitWindows and a commit limit.
#ifndef UNICODE
#define UNICODE
#endif
#define _WIN32_WINNT 0x0A00
#include <windows.h>
#include <aclapi.h>
#include <psapi.h>
#include <sddl.h>
#include <wincrypt.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <string>
#include <thread>
#include <vector>

using std::string;
using std::wstring;

static const unsigned long long OUTPUT_LIMIT = 256ull << 20;
static const wchar_t *const KEEP_NOTHING = L"";

// ---------------------------------------------------------------- utilities
static std::mutex g_out_mu;
static HANDLE g_stdout;

static void send_line(const string &s) {
    std::lock_guard<std::mutex> lk(g_out_mu);
    string l = s + "\n";
    DWORD w;
    const char *p = l.data();
    size_t left = l.size();
    while (left) {
        if (!WriteFile(g_stdout, p, (DWORD)left, &w, NULL) || !w) ExitProcess(3);
        p += w;
        left -= w;
    }
}

static const char B64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static string b64enc(const string &in) {
    string o;
    o.reserve(in.size() * 4 / 3 + 4);
    size_t i = 0;
    for (; i + 2 < in.size(); i += 3) {
        unsigned v = ((unsigned char)in[i] << 16) | ((unsigned char)in[i + 1] << 8) | (unsigned char)in[i + 2];
        o += B64[v >> 18];
        o += B64[(v >> 12) & 63];
        o += B64[(v >> 6) & 63];
        o += B64[v & 63];
    }
    if (i + 1 == in.size()) {
        unsigned v = (unsigned char)in[i] << 16;
        o += B64[v >> 18];
        o += B64[(v >> 12) & 63];
        o += "==";
    } else if (i + 2 == in.size()) {
        unsigned v = ((unsigned char)in[i] << 16) | ((unsigned char)in[i + 1] << 8);
        o += B64[v >> 18];
        o += B64[(v >> 12) & 63];
        o += B64[(v >> 6) & 63];
        o += '=';
    }
    return o.empty() ? string("-") : o;  // "-" keeps the field non-empty on the wire
}

static string b64dec(const string &in) {
    static int T[256];
    static std::once_flag once;
    std::call_once(once, [] {
        for (int i = 0; i < 256; i++) T[i] = -1;
        for (int i = 0; i < 64; i++) T[(unsigned char)B64[i]] = i;
    });
    string o;
    unsigned val = 0;
    int bits = -8;
    for (unsigned char c : in) {
        if (T[c] < 0) continue;
        val = (val << 6) | T[c];
        bits += 6;
        if (bits >= 0) {
            o += (char)((val >> bits) & 255);
            bits -= 8;
        }
    }
    return o;
}

static wstring widen(const string &s) {
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), NULL, 0);
    wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
    return w;
}

static bool read_file(const wstring &path, string &out, unsigned long long cap = ~0ull) {
    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL,
                           OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
    if (h == INVALID_HANDLE_VALUE) return false;
    LARGE_INTEGER sz;
    if (!GetFileSizeEx(h, &sz) || sz.QuadPart < 0) {
        CloseHandle(h);
        return false;
    }
    unsigned long long n = (unsigned long long)sz.QuadPart;
    if (n > cap) n = cap;
    out.resize((size_t)n);
    size_t got = 0;
    while (got < n) {
        DWORD r = 0;
        DWORD want = (DWORD)std::min<unsigned long long>(n - got, 1u << 30);
        if (!ReadFile(h, &out[got], want, &r, NULL) || !r) break;
        got += r;
    }
    out.resize(got);
    CloseHandle(h);
    return got == n;
}

static bool write_file(const wstring &path, const string &data) {
    HANDLE h = CreateFileW(path.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return false;
    DWORD w = 0;
    BOOL ok = data.empty() ? TRUE : WriteFile(h, data.data(), (DWORD)data.size(), &w, NULL);
    CloseHandle(h);
    return ok && w == data.size();
}

static bool file_exists(const wstring &path) {
    return GetFileAttributesW(path.c_str()) != INVALID_FILE_ATTRIBUTES;
}

static bool directory_empty(const wstring &dir) {
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((dir + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return GetLastError() == ERROR_FILE_NOT_FOUND;
    bool empty = true;
    do {
        wstring name = fd.cFileName;
        if (name != L"." && name != L"..") { empty = false; break; }
    } while (FindNextFileW(h, &fd));
    FindClose(h);
    return empty;
}

// Remove everything in dir except the file named keep.
static void clean_dir(const wstring &dir, const wstring &keep) {
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((dir + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        wstring n = fd.cFileName;
        if (n == L"." || n == L".." || n == keep) continue;
        wstring p = dir + L"\\" + n;
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            clean_dir(p, KEEP_NOTHING);
            RemoveDirectoryW(p.c_str());
        } else {
            SetFileAttributesW(p.c_str(), FILE_ATTRIBUTE_NORMAL);
            for (int i = 0; i < 20 && !DeleteFileW(p.c_str()); i++) {
                DWORD e = GetLastError();
                if (e == ERROR_FILE_NOT_FOUND) break;
                Sleep(25);
            }
        }
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}

static void remove_dir(const wstring &dir) {
    clean_dir(dir, KEEP_NOTHING);
    for (int i = 0; i < 20 && !RemoveDirectoryW(dir.c_str()); i++) {
        if (GetLastError() == ERROR_FILE_NOT_FOUND) break;
        Sleep(25);
    }
}

static bool set_mandatory_label(const wstring &path, const wchar_t *sddl) {
    PSECURITY_DESCRIPTOR sd = NULL;
    if (!ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl, SDDL_REVISION_1, &sd, NULL)) return false;
    BOOL present = FALSE, defaulted = FALSE;
    PACL sacl = NULL;
    GetSecurityDescriptorSacl(sd, &present, &sacl, &defaulted);
    DWORD r = SetNamedSecurityInfoW((LPWSTR)path.c_str(), SE_FILE_OBJECT, LABEL_SECURITY_INFORMATION, NULL, NULL, NULL,
                                    sacl);
    LocalFree(sd);
    return r == ERROR_SUCCESS;
}

// ---------------------------------------------------------------- sandbox token
// How a child is started. Levels are tried strongest first because some hosts (service sessions,
// unusual parents) cannot start Low processes; run and compile are probed separately.
struct Level {
    HANDLE token = NULL;   // NULL: inherits the agent's own token (privileges already stripped)
    bool low = false;      // Low integrity: cannot write outside run\\, cannot read answers
    bool desktop = false;  // private window station and desktop
    const char *name = "job";
};
static Level g_run_level, g_compile_level;

static void strip_own_privileges() {
    HANDLE tok;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY | TOKEN_ADJUST_PRIVILEGES, &tok)) return;
    DWORD need = 0;
    GetTokenInformation(tok, TokenPrivileges, NULL, 0, &need);
    std::vector<char> buf(need);
    if (GetTokenInformation(tok, TokenPrivileges, buf.data(), need, &need)) {
        TOKEN_PRIVILEGES *tp = (TOKEN_PRIVILEGES *)buf.data();
        LUID keep;
        LookupPrivilegeValueW(NULL, SE_CHANGE_NOTIFY_NAME, &keep);
        for (DWORD i = 0; i < tp->PrivilegeCount; i++) {
            LUID_AND_ATTRIBUTES &a = tp->Privileges[i];
            bool k = a.Luid.LowPart == keep.LowPart && a.Luid.HighPart == keep.HighPart;
            a.Attributes = k ? a.Attributes : SE_PRIVILEGE_REMOVED;
        }
        AdjustTokenPrivileges(tok, FALSE, tp, need, NULL, NULL);
    }
    CloseHandle(tok);
}

static HANDLE make_token(bool low_integrity) {
    HANDLE cur = NULL, res = NULL;
    if (!OpenProcessToken(GetCurrentProcess(),
                          TOKEN_DUPLICATE | TOKEN_ASSIGN_PRIMARY | TOKEN_QUERY | TOKEN_ADJUST_DEFAULT, &cur))
        return NULL;
    BYTE admin_sid[SECURITY_MAX_SID_SIZE];
    DWORD sz = sizeof(admin_sid);
    CreateWellKnownSid(WinBuiltinAdministratorsSid, NULL, admin_sid, &sz);
    SID_AND_ATTRIBUTES disable[1];
    disable[0].Sid = admin_sid;
    disable[0].Attributes = 0;
    if (!CreateRestrictedToken(cur, DISABLE_MAX_PRIVILEGE, 1, disable, 0, NULL, 0, NULL, &res)) {
        CloseHandle(cur);
        return NULL;
    }
    CloseHandle(cur);
    if (!low_integrity) return res;
    PSID low = NULL;
    if (!ConvertStringSidToSidW(L"S-1-16-4096", &low)) {
        CloseHandle(res);
        return NULL;
    }
    TOKEN_MANDATORY_LABEL tml{};
    tml.Label.Attributes = SE_GROUP_INTEGRITY;
    tml.Label.Sid = low;
    BOOL ok = SetTokenInformation(res, TokenIntegrityLevel, &tml, sizeof(tml) + GetLengthSid(low));
    LocalFree(low);
    if (!ok) {
        CloseHandle(res);
        return NULL;
    }
    return res;
}

// A private window station and desktop, labelled Low so a Low token can connect. Without it the
// child depends on whatever station the agent inherited: from a service session (sshd) a Low process
// cannot attach and dies in DLL init with 0xC0000142. It also isolates children from the real desktop.
static wstring g_desktop;

static void make_private_desktop() {
    PSECURITY_DESCRIPTOR sd = NULL;
    if (!ConvertStringSecurityDescriptorToSecurityDescriptorW(L"D:(A;;GA;;;WD)S:(ML;;NW;;;LW)", SDDL_REVISION_1, &sd, NULL))
        return;
    SECURITY_ATTRIBUTES sa{sizeof(sa), sd, FALSE};
    HWINSTA old = GetProcessWindowStation();
    HWINSTA ws = CreateWindowStationW(NULL, 0, WINSTA_ALL_ACCESS, &sa);
    if (ws) {
        wchar_t name[256] = L"";
        DWORD need = 0;
        GetUserObjectInformationW(ws, UOI_NAME, name, sizeof(name), &need);
        if (SetProcessWindowStation(ws)) {
            HDESK d = CreateDesktopW(L"sandbox", NULL, NULL, 0, GENERIC_ALL, &sa);
            SetProcessWindowStation(old);
            if (d && name[0]) g_desktop = wstring(name) + L"\\sandbox";  // handles stay open for the agent's life
        }
    }
    LocalFree(sd);
}

// ---------------------------------------------------------------- sandboxed run
struct Program {
    string problem, source, key;
    long long memory = 0;
    int flags = 0;
};
struct Task {
    long long id = 0;
    string problem;
    long long tl_ms = 0, ml_mb = 0;
    int flags = 0;
    std::vector<int> tests;
    string source;
    std::shared_ptr<Program> program;
    std::atomic<bool> killed{false};
    std::atomic<bool> yielded{false};
    std::mutex mu;
    HANDLE job = NULL;
};

struct Limits {
    long long cpu_ms = 0, wall_ms = 0;
    unsigned long long mem = 0;
    int procs = 1;
    wstring watch;  // file whose size is capped
};

struct Res {
    bool started = false;
    DWORD err = 0, code = 0;
    long long cpu_ms = 0, wall_ms = 0;
    unsigned long long peak = 0;
    bool tle = false, ole = false, killed = false, mem_hit = false, wall_tle = false, timer_error = false;
};

static long long job_cpu_ms(HANDLE job) {
    JOBOBJECT_BASIC_ACCOUNTING_INFORMATION a{};
    if (!QueryInformationJobObject(job, JobObjectBasicAccountingInformation, &a, sizeof(a), NULL)) return -1;
    return (a.TotalUserTime.QuadPart + a.TotalKernelTime.QuadPart) / 10000;
}

// Cycle counters are not time units (and may change with CPU frequency/core type).
// Verdicts use OS CPU accounting. Wall/CPU ratios cannot detect a broken clock:
// preemption and CPU caps legitimately reduce the CPU time accumulated per wall second.
static HANDLE g_cpu_job = NULL;
static std::atomic<int> g_cpu_percent{100};

static bool set_cpu_percent(int percent) {
    if (percent < 1 || percent > 100) { SetLastError(ERROR_INVALID_PARAMETER); return false; }
    if (percent == g_cpu_percent.load()) return true;
    if (!g_cpu_job) { SetLastError(ERROR_NOT_SUPPORTED); return false; }
    JOBOBJECT_CPU_RATE_CONTROL_INFORMATION rate{};
    if (percent < 100) {
        rate.ControlFlags = JOB_OBJECT_CPU_RATE_CONTROL_ENABLE | JOB_OBJECT_CPU_RATE_CONTROL_HARD_CAP;
        rate.CpuRate = percent * 100;
    }
    if (!SetInformationJobObject(g_cpu_job, JobObjectCpuRateControlInformation, &rate, sizeof(rate))) return false;
    g_cpu_percent = percent;
    return true;
}

static long long thread_cpu_100ns() {
    FILETIME c,x,k,u;
    if (!GetThreadTimes(GetCurrentThread(),&c,&x,&k,&u)) return -1;
    ULARGE_INTEGER kernel,user;
    kernel.LowPart=k.dwLowDateTime;kernel.HighPart=k.dwHighDateTime;
    user.LowPart=u.dwLowDateTime;user.HighPart=u.dwHighDateTime;
    return (long long)(kernel.QuadPart+user.QuadPart);
}

static long long proc_cpu_ms(HANDLE p);

static string g_clock_diagnostic;
static bool validate_cpu_clock() {
    long long thread=thread_cpu_100ns(),process=proc_cpu_ms(GetCurrentProcess());
    g_clock_diagnostic="thread="+std::to_string(thread)+", process="+std::to_string(process);
    return thread>=0 && process>=0;
}

static long long proc_cpu_ms(HANDLE p) {
    FILETIME c, x, k, u;
    if (!GetProcessTimes(p, &c, &x, &k, &u)) return -1;
    ULARGE_INTEGER a, b;
    a.LowPart = k.dwLowDateTime;
    a.HighPart = k.dwHighDateTime;
    b.LowPart = u.dwLowDateTime;
    b.HighPart = u.dwHighDateTime;
    return (long long)((a.QuadPart + b.QuadPart) / 10000);
}

// Bytes the image occupies once mapped, BSS included.
static unsigned long long image_size(const wstring &exe) {
    string h;
    if (!read_file(exe, h, 4096) || h.size() < 0x40 || h[0] != 'M' || h[1] != 'Z') return 0;
    DWORD off = *(const DWORD *)(h.data() + 0x3C);
    if (off + 24 + 60 > h.size()) return 0;
    return *(const DWORD *)(h.data() + off + 24 + 56);  // OptionalHeader.SizeOfImage
}

static std::vector<wchar_t> env_block(const std::vector<wstring> &vars) {
    std::vector<wchar_t> b;
    for (auto &v : vars) {
        b.insert(b.end(), v.begin(), v.end());
        b.push_back(0);
    }
    b.push_back(0);
    return b;
}

static Res sandbox_run(const Level &lv, wstring cmd, const wstring &cwd, const wstring &log_path, const Limits &L,
                       const std::vector<wstring> &env, Task *t) {
    Res r;
    HANDLE job = CreateJobObjectW(NULL, NULL);
    if (!job) {
        r.err = GetLastError();
        return r;
    }
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION ext{};
    ext.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE |
                                           JOB_OBJECT_LIMIT_DIE_ON_UNHANDLED_EXCEPTION |
                                           JOB_OBJECT_LIMIT_ACTIVE_PROCESS | JOB_OBJECT_LIMIT_PROCESS_MEMORY;
    ext.BasicLimitInformation.ActiveProcessLimit = L.procs;
    ext.ProcessMemoryLimit = (SIZE_T)L.mem;
    SetInformationJobObject(job, JobObjectExtendedLimitInformation, &ext, sizeof(ext));
    // Failed commits against the limit arrive here; that is what separates MLE from a plain crash.
    HANDLE iocp = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 1);
    JOBOBJECT_ASSOCIATE_COMPLETION_PORT acp{};
    acp.CompletionKey = job;
    acp.CompletionPort = iocp;
    SetInformationJobObject(job, JobObjectAssociateCompletionPortInformation, &acp, sizeof(acp));

    SECURITY_ATTRIBUTES sa{sizeof(sa), NULL, TRUE};
    HANDLE nul = CreateFileW(L"NUL", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, &sa,
                             OPEN_EXISTING, 0, NULL);
    HANDLE log = nul;
    if (!log_path.empty())
        log = CreateFileW(log_path.c_str(), GENERIC_WRITE, FILE_SHARE_READ, &sa, CREATE_ALWAYS, 0, NULL);
    if (log == INVALID_HANDLE_VALUE) log = nul;

    // Only these handles reach the child: never the agent's protocol pipes.
    HANDLE list[2] = {nul, log};
    SIZE_T asz = 0;
    InitializeProcThreadAttributeList(NULL, 1, 0, &asz);
    std::vector<char> ab(asz);
    auto *attrs = (LPPROC_THREAD_ATTRIBUTE_LIST)ab.data();
    InitializeProcThreadAttributeList(attrs, 1, 0, &asz);
    UpdateProcThreadAttribute(attrs, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST, list,
                              (log == nul ? 1 : 2) * sizeof(HANDLE), NULL, NULL);

    STARTUPINFOEXW si{};
    si.StartupInfo.cb = sizeof(si);
    si.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
    si.StartupInfo.hStdInput = nul;
    si.StartupInfo.hStdOutput = log;
    si.StartupInfo.hStdError = log;
    si.lpAttributeList = attrs;
    if (lv.desktop && !g_desktop.empty()) si.StartupInfo.lpDesktop = &g_desktop[0];
    PROCESS_INFORMATION pi{};
    auto envb = env_block(env);
    DWORD cf = CREATE_SUSPENDED | DETACHED_PROCESS | EXTENDED_STARTUPINFO_PRESENT | CREATE_UNICODE_ENVIRONMENT;
    BOOL ok = lv.token ? CreateProcessAsUserW(lv.token, NULL, &cmd[0], NULL, NULL, TRUE, cf, envb.data(),
                                                 cwd.c_str(), &si.StartupInfo, &pi)
                          : CreateProcessW(NULL, &cmd[0], NULL, NULL, TRUE, cf, envb.data(), cwd.c_str(),
                                           &si.StartupInfo, &pi);
    DeleteProcThreadAttributeList(attrs);
    if (!ok) {
        r.err = GetLastError();
        if (log != nul) CloseHandle(log);
        CloseHandle(nul);
        CloseHandle(job);
        CloseHandle(iocp);
        return r;
    }
    if (log != nul) CloseHandle(log);
    CloseHandle(nul);
    if (!AssignProcessToJobObject(job, pi.hProcess)) {
        r.err = GetLastError();
        TerminateProcess(pi.hProcess, 1);
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        CloseHandle(job);
        CloseHandle(iocp);
        return r;
    }
    // Apply UI restrictions after assignment, so the per-task job can nest under the CPU job.
    JOBOBJECT_BASIC_UI_RESTRICTIONS ui{};
    ui.UIRestrictionsClass = JOB_OBJECT_UILIMIT_ALL;
    SetInformationJobObject(job, JobObjectBasicUIRestrictions, &ui, sizeof(ui));
    if (t) {
        std::lock_guard<std::mutex> lk(t->mu);
        t->job = job;
    }
    r.started = true;
    LARGE_INTEGER f, s, e;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&s);
    ResumeThread(pi.hThread);
    CloseHandle(pi.hThread);
    double charged_wall = 0;
    long long previous_wall = 0;
    for (;;) {
        DWORD w = WaitForSingleObject(pi.hProcess, 10);
        if (w != WAIT_TIMEOUT) break;
        QueryPerformanceCounter(&e);
        long long wall = (e.QuadPart - s.QuadPart) * 1000 / f.QuadPart;
        // Throttling is not contestant execution time. Also handle changes to the cap mid-run.
        charged_wall += (wall - previous_wall) * g_cpu_percent.load() / 100.0;
        previous_wall = wall;
        long long process_cpu=proc_cpu_ms(pi.hProcess),job_cpu=job_cpu_ms(job);
        if (process_cpu<0 || job_cpu<0) {
            r.timer_error=true;TerminateJobObject(job,1);break;
        }
        long long cpu = std::max(process_cpu,job_cpu);
        if (cpu > L.cpu_ms || charged_wall > L.wall_ms) {
            r.tle = true;
            r.wall_tle = cpu <= L.cpu_ms;
            TerminateJobObject(job, 1);
            break;
        }
        if (t && t->killed.load()) {
            r.killed = true;
            TerminateJobObject(job, 1);
            break;
        }
        if (!L.watch.empty()) {
            WIN32_FILE_ATTRIBUTE_DATA fa;
            if (GetFileAttributesExW(L.watch.c_str(), GetFileExInfoStandard, &fa)) {
                unsigned long long sz = ((unsigned long long)fa.nFileSizeHigh << 32) | fa.nFileSizeLow;
                if (sz > OUTPUT_LIMIT) {
                    r.ole = true;
                    TerminateJobObject(job, 1);
                    break;
                }
            }
        }
    }
    WaitForSingleObject(pi.hProcess, 5000);
    QueryPerformanceCounter(&e);
    r.wall_ms = (e.QuadPart - s.QuadPart) * 1000 / f.QuadPart;
    GetExitCodeProcess(pi.hProcess, &r.code);
    long long process_cpu=proc_cpu_ms(pi.hProcess),job_cpu=job_cpu_ms(job);
    r.timer_error |= process_cpu<0 || job_cpu<0;
    r.cpu_ms = std::max(0LL,std::max(process_cpu,job_cpu));
    if (!L.watch.empty()) {
        WIN32_FILE_ATTRIBUTE_DATA fa;
        if (GetFileAttributesExW(L.watch.c_str(), GetFileExInfoStandard, &fa) &&
            (((unsigned long long)fa.nFileSizeHigh << 32) | fa.nFileSizeLow) > OUTPUT_LIMIT)
            r.ole = true;
    }
    {
        DWORD msg;
        ULONG_PTR key;
        LPOVERLAPPED ov;
        while (GetQueuedCompletionStatus(iocp, &msg, &key, &ov, 0))
            if (msg == JOB_OBJECT_MSG_PROCESS_MEMORY_LIMIT) r.mem_hit = true;
        CloseHandle(iocp);
    }
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION q{};
    if (QueryInformationJobObject(job, JobObjectExtendedLimitInformation, &q, sizeof(q), NULL))
        r.peak = q.PeakProcessMemoryUsed;
    PROCESS_MEMORY_COUNTERS pmc{};
    pmc.cb = sizeof(pmc);
    if (GetProcessMemoryInfo(pi.hProcess, &pmc, sizeof(pmc)) && pmc.PeakPagefileUsage > r.peak)
        r.peak = pmc.PeakPagefileUsage;
    CloseHandle(pi.hProcess);
    if (t) {
        std::lock_guard<std::mutex> lk(t->mu);
        t->job = NULL;
    }
    CloseHandle(job);
    if (r.cpu_ms > L.cpu_ms) {
        r.tle = true;
        r.wall_tle = false;
    }
    return r;
}

// ---------------------------------------------------------------- checker
// Equivalent of `diff -Z -B`-style contest compare: trailing blanks per line and trailing
// empty lines are ignored.
static bool next_line(const string &s, size_t &pos, const char *&b, size_t &n) {
    if (pos >= s.size()) return false;
    size_t e = s.find('\n', pos);
    if (e == string::npos) e = s.size();
    b = s.data() + pos;
    size_t len = e - pos;
    while (len && (b[len - 1] == ' ' || b[len - 1] == '\r' || b[len - 1] == '\t')) len--;
    n = len;
    pos = e + 1;
    return true;
}

static bool compare_output(const string &out, const string &ans, string &detail) {
    size_t po = 0, pa = 0;
    long long line = 0;
    for (;;) {
        const char *bo = "", *ba = "";
        size_t no = 0, na = 0;
        bool ho = next_line(out, po, bo, no), ha = next_line(ans, pa, ba, na);
        line++;
        if (!ho && !ha) return true;
        if (!ho) no = 0;
        if (!ha) na = 0;
        if (no != na || (no && memcmp(bo, ba, no) != 0)) {
            if (!ho || !ha) {
                // only trailing blank lines left on the longer side => still equal
                const string &rest = ho ? out : ans;
                size_t p = ho ? po : pa;
                size_t cur = no + na;
                bool blank = cur == 0;
                const char *x;
                size_t m;
                while (blank && next_line(rest, p, x, m)) blank = m == 0;
                if (blank) return true;
            }
            detail = std::to_string(line) + "|" + string(ba, std::min<size_t>(na, 48)) + "|" +
                     string(bo, std::min<size_t>(no, 48));
            return false;
        }
    }
}

// ---------------------------------------------------------------- task execution
static wstring g_root;     // absolute workdir
static wstring g_run;      // absolute run\<pid>
static wstring g_gpp, g_binmode;
static wstring g_data = L"data";  // folder holding <problem><i>.in / .ans, relative to the workdir
static std::mutex g_answer_mu;
static std::set<wstring> g_protected_answers;
static std::mutex g_tasks_mu;
static std::map<long long, Task *> g_tasks;
static std::mutex g_compile_mu, g_cache_mu;
static std::condition_variable g_compile_cv;
static int g_compile_limit = 1, g_compile_active = 0, g_compile_waiting = 0;
static std::atomic<unsigned long long> g_cache_hits{0};
static wstring g_cache;
static string g_runtime_version;
static std::mutex g_key_mu;
static std::map<string, std::weak_ptr<std::timed_mutex>> g_key_locks;

static std::shared_ptr<std::timed_mutex> compile_key_lock(const string &key) {
    std::lock_guard<std::mutex> lock(g_key_mu);
    auto existing = g_key_locks[key].lock();
    if (existing) return existing;
    if (g_key_locks.size() > 2048) {
        for (auto it = g_key_locks.begin(); it != g_key_locks.end();) {
            if (it->second.expired()) it = g_key_locks.erase(it);
            else ++it;
        }
    }
    auto result = std::make_shared<std::timed_mutex>();
    g_key_locks[key] = result;
    return result;
}

static void send_stats() {
    static std::atomic<ULONGLONG> last{0};
    ULONGLONG now = GetTickCount64(), previous = last.load();
    if (now - previous < 100 || !last.compare_exchange_strong(previous, now)) return;
    int active, waiting;
    {
        std::lock_guard<std::mutex> lock(g_compile_mu);
        active = g_compile_active;
        waiting = g_compile_waiting;
    }
    send_line("STATS " + std::to_string(active) + " " + std::to_string(waiting) + " " +
              std::to_string(g_cache_hits.load()));
}

static bool acquire_compile(Task &t) {
    {
        std::lock_guard<std::mutex> lock(g_compile_mu);
        ++g_compile_waiting;
    }
    send_stats();
    std::unique_lock<std::mutex> lock(g_compile_mu);
    while (!t.killed.load() && g_compile_active >= g_compile_limit)
        g_compile_cv.wait_for(lock, std::chrono::milliseconds(50));
    --g_compile_waiting;
    bool acquired = !t.killed.load();
    if (acquired) ++g_compile_active;
    lock.unlock();
    send_stats();
    return acquired;
}

static void release_compile() {
    {
        std::lock_guard<std::mutex> lock(g_compile_mu);
        --g_compile_active;
    }
    g_compile_cv.notify_all();
    send_stats();
}

static string sha256(const string &value) {
    HCRYPTPROV provider = 0;
    HCRYPTHASH hash = 0;
    string result;
    if (CryptAcquireContextW(&provider, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
        if (CryptCreateHash(provider, CALG_SHA_256, 0, 0, &hash)) {
            if (CryptHashData(hash, (const BYTE *)value.data(), (DWORD)value.size(), 0)) {
                BYTE bytes[32];
                DWORD size = sizeof(bytes);
                if (CryptGetHashParam(hash, HP_HASHVAL, bytes, &size, 0)) {
                    const char *hex = "0123456789abcdef";
                    for (DWORD i = 0; i < size; ++i) {
                        result += hex[bytes[i] >> 4];
                        result += hex[bytes[i] & 15];
                    }
                }
            }
            CryptDestroyHash(hash);
        }
        CryptReleaseContext(provider, 0);
    }
    return result;
}

struct CachedExe {
    wstring path;
    unsigned long long size = 0, stamp = 0, image = 0, last_use = 0;
    HANDLE guard = INVALID_HANDLE_VALUE;
    ~CachedExe() { if (guard != INVALID_HANDLE_VALUE) CloseHandle(guard); }
};
static std::map<string, std::shared_ptr<CachedExe>> g_verified;
struct CacheRecord { unsigned long long size, stamp; };
static std::map<string, CacheRecord> g_cache_inventory;
static std::set<std::pair<unsigned long long, string>> g_cache_lru;
static unsigned long long g_cache_bytes = 0;
static bool g_cache_indexed = false;

static wstring cache_base(const string &key) {
#ifdef OI_SPRINT_TREE
    return g_cache + L"\\" + widen(key) + L"\\test";
#else
    return g_cache + L"\\" + widen(key);
#endif
}

// Caller holds g_cache_mu. Enumerate the on-disk cache once, not at every compilation.
static void cache_index() {
    if (g_cache_indexed) return;
    g_cache_indexed = true;
    WIN32_FIND_DATAW fd;
    HANDLE find = FindFirstFileW((g_cache +
#ifdef OI_SPRINT_TREE
                                L"\\*"
#else
                                L"\\*.exe"
#endif
                                ).c_str(), &fd);
    if (find == INVALID_HANDLE_VALUE) return;
    do {
        wstring name = fd.cFileName;
        string key(name.begin(), name.end());
#ifdef OI_SPRINT_TREE
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) || key.size() != 64) continue;
        WIN32_FILE_ATTRIBUTE_DATA info;
        if (!GetFileAttributesExW((cache_base(key)+L".exe").c_str(),GetFileExInfoStandard,&info)) continue;
#else
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY || key.size() != 68) continue;
        key.resize(64);
        const auto &info = fd;
#endif
        if (key.find_first_not_of("0123456789abcdef") != string::npos) continue;
        CacheRecord record{((unsigned long long)info.nFileSizeHigh << 32) | info.nFileSizeLow,
                           ((unsigned long long)info.ftLastWriteTime.dwHighDateTime << 32) | info.ftLastWriteTime.dwLowDateTime};
        auto verified = g_verified.find(key);
        if (verified != g_verified.end()) record.stamp = verified->second->last_use;
        g_cache_inventory[key] = record;
        g_cache_lru.insert({record.stamp,key});
        g_cache_bytes += record.size;
    } while (FindNextFileW(find,&fd));
    FindClose(find);
}

static void cache_touch(const string &key, unsigned long long stamp) {
    auto record = g_cache_inventory.find(key);
    if (record == g_cache_inventory.end()) return;
    g_cache_lru.erase({record->second.stamp,key});
    record->second.stamp = stamp;
    g_cache_lru.insert({stamp,key});
}

// Validate only new/changed artifacts; running points share the immutable cached executable.
static std::shared_ptr<CachedExe> cache_get(const string &key, bool count_hit = true) {
    if (key.empty()) return {};
    wstring base = cache_base(key);
    WIN32_FILE_ATTRIBUTE_DATA fd;
    if (!GetFileAttributesExW((base + L".exe").c_str(), GetFileExInfoStandard, &fd)) return {};
    unsigned long long stamp = ((unsigned long long)fd.ftLastWriteTime.dwHighDateTime << 32) | fd.ftLastWriteTime.dwLowDateTime;
    unsigned long long size = ((unsigned long long)fd.nFileSizeHigh << 32) | fd.nFileSizeLow;
    if (size > (256ull << 20)) return {};
    std::lock_guard<std::mutex> lock(g_cache_mu);
    auto it = g_verified.find(key);
    if (it != g_verified.end() && it->second->size == size && it->second->stamp == stamp) {
        FILETIME now; GetSystemTimeAsFileTime(&now);
        it->second->last_use = ((unsigned long long)now.dwHighDateTime << 32) | now.dwLowDateTime;
        cache_touch(key,it->second->last_use);
        if (count_hit) ++g_cache_hits;
        return it->second;
    }
    auto entry = std::make_shared<CachedExe>();
    entry->guard = CreateFileW((base + L".exe").c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (entry->guard == INVALID_HANDLE_VALUE) return {};
    string expected, contents;
    if (!read_file(base + L".sha256", expected, 128) || expected.size() != 64 ||
        !read_file(base + L".exe", contents, 256ull << 20) || sha256(contents) != expected) return {};
    unsigned long long image = image_size(base + L".exe");
    if (!image) return {};
    entry->path = base + L".exe"; entry->size = size; entry->stamp = stamp; entry->image = image;
    FILETIME now; GetSystemTimeAsFileTime(&now);
    entry->last_use = ((unsigned long long)now.dwHighDateTime << 32) | now.dwLowDateTime;
    g_verified[key] = entry;
    cache_touch(key,entry->last_use);
    if (count_hit) ++g_cache_hits;
    return entry;
}

static void cache_put(const string &key, const wstring &exe) {
    if (key.empty()) return;
    WIN32_FILE_ATTRIBUTE_DATA size_info;
    if (!GetFileAttributesExW(exe.c_str(), GetFileExInfoStandard, &size_info) ||
        (((unsigned long long)size_info.nFileSizeHigh << 32) | size_info.nFileSizeLow) > (256ull << 20)) return;
    std::lock_guard<std::mutex> lock(g_cache_mu);
    string contents;
    if (!read_file(exe, contents, 256ull << 20)) return;
    string digest = sha256(contents);
    if (digest.empty()) return;
    auto active = g_verified.find(key);
    if (active != g_verified.end()) {
        if (active->second.use_count() > 1) return;
        g_verified.erase(active); // Releases the read guard before replacing an unused cache entry.
    }
    wstring base = cache_base(key);
#ifdef OI_SPRINT_TREE
    CreateDirectoryW((g_cache + L"\\" + widen(key)).c_str(), NULL);
#endif
    if (!CopyFileW(exe.c_str(), (base + L".exe.tmp").c_str(), FALSE) ||
        !write_file(base + L".sha256.tmp", digest)) return;
    if (!MoveFileExW((base + L".exe.tmp").c_str(), (base + L".exe").c_str(), MOVEFILE_REPLACE_EXISTING) ||
        !MoveFileExW((base + L".sha256.tmp").c_str(), (base + L".sha256").c_str(), MOVEFILE_REPLACE_EXISTING)) return;
    cache_index();
    auto previous = g_cache_inventory.find(key);
    if (previous != g_cache_inventory.end()) {
        g_cache_bytes -= previous->second.size;
        g_cache_lru.erase({previous->second.stamp,key});
    }
    FILETIME now; GetSystemTimeAsFileTime(&now);
    CacheRecord current{((unsigned long long)size_info.nFileSizeHigh << 32) | size_info.nFileSizeLow,
                        ((unsigned long long)now.dwHighDateTime << 32) | now.dwLowDateTime};
    g_cache_inventory[key] = current;
    g_cache_lru.insert({current.stamp,key});
    g_cache_bytes += current.size;
    for (auto oldest = g_cache_lru.begin(); g_cache_bytes > (2ull << 30) && oldest != g_cache_lru.end();) {
        string old_key = oldest->second;
        auto found = g_verified.find(old_key);
        if (found != g_verified.end() && found->second.use_count() > 1) { ++oldest; continue; }
        g_verified.erase(old_key);
        wstring path = cache_base(old_key);
        if (DeleteFileW((path+L".exe").c_str()) || GetLastError() == ERROR_FILE_NOT_FOUND) {
            g_cache_bytes -= g_cache_inventory[old_key].size;
            g_cache_inventory.erase(old_key);
            oldest = g_cache_lru.erase(oldest);
            DeleteFileW((path+L".sha256").c_str());
#ifdef OI_SPRINT_TREE
            RemoveDirectoryW((g_cache+L"\\"+widen(old_key)).c_str());
#endif
        } else ++oldest;
    }
}

static string hex32(DWORD v) {
    char b[16];
    snprintf(b, sizeof(b), "0x%08lX", (unsigned long)v);
    return b;
}

static void emit_test(Task &t, int test, const char *st, const Res &r, const string &detail) {
    long long mem = (long long)(r.peak / 1024);
    send_line("TEST " + std::to_string(t.id) + " " + std::to_string(test) + " " + st + " " +
              std::to_string(r.cpu_ms) + " " + std::to_string(r.wall_ms) + " " + std::to_string(mem) + " " +
              b64enc(detail));
}

// Reuse a bounded number of per-concurrency working directories instead of creating/deleting one per point.
static std::mutex g_slot_mu;
static std::vector<wstring> g_free_slots;
static unsigned long long g_slot_seq = 0;
struct WorkSlot {
    wstring path;
    bool returned = false;
    bool usable = false;
    WorkSlot() {
        std::lock_guard<std::mutex> lock(g_slot_mu);
        if (!g_free_slots.empty()) { path = g_free_slots.back(); g_free_slots.pop_back(); }
        else { path = g_run + L"\\s" + std::to_wstring(++g_slot_seq); CreateDirectoryW(path.c_str(), NULL); }
        usable = directory_empty(path);
    }
    void release() {
        if (returned) return;
        clean_dir(path, KEEP_NOTHING);
        std::lock_guard<std::mutex> lock(g_slot_mu);
        if (directory_empty(path)) g_free_slots.push_back(path);
        returned = true;
    }
    ~WorkSlot() { release(); }
};

static void run_task(Task *tp) {
    Task &t = *tp;
    WorkSlot slot;
    if (!slot.usable) {
        send_line("COMPILE " + std::to_string(t.id) + " SE 0 " + b64enc("working directory is not empty or inaccessible"));
        send_line("DONE " + std::to_string(t.id));
        return;
    }
    const wstring &dir = slot.path;
    const string &source = t.program ? t.program->source : t.source;
    wstring prob = widen(t.problem);
    wstring src = dir + L"\\" + prob + L".cpp";
#ifdef OI_SPRINT_TREE
    wstring executable_name = L"test.exe";
#else
    wstring executable_name = prob + L".exe";
#endif
    wstring exe = dir + L"\\" + executable_name;
    wstring log = dir + L"\\compile.log";

    // The stack may grow as far as the memory limit, as on the official judge.
    wstring stack = std::to_wstring((unsigned long long)t.ml_mb << 20);
    wstring cmd = L"\"" + g_gpp + L"\" -std=c++14 -O2 -static -Wl,--stack=" + stack + L" ";
    cmd += L"-I\"" + g_root + L"\\compat\\poison\" ";
    if (t.flags & 1) cmd += L"-include \"" + g_root + L"\\compat\\linux_stdio.h\" ";
    if (t.flags & 2) cmd += L"-include \"" + g_root + L"\\compat\\lp64.h\" ";
    cmd += prob + L".cpp \"" + g_binmode + L"\" -o " + executable_name;
    Limits cl;
    cl.cpu_ms = 30000;
    cl.wall_ms = 60000;
    cl.mem = 3ull << 30;
    cl.procs = 8;
    std::vector<wstring> cenv = {L"PATH=" + g_root + L"\\mingw\\bin", L"SystemRoot=" + wstring(_wgetenv(L"SystemRoot")),
                                 L"TEMP=" + dir, L"TMP=" + dir, L"LC_ALL=C", L"LANG=C"};
    string key = t.program ? t.program->key : sha256(g_runtime_version + "\n" + std::to_string(t.flags) + "\n" +
                        std::to_string(t.ml_mb) + "\n" + t.problem + "\n" + source);
    auto key_mutex = compile_key_lock(key);
    std::unique_lock<std::timed_mutex> key_lock(*key_mutex, std::defer_lock);
    if (!key_lock.try_lock()) {
        {
            std::lock_guard<std::mutex> lock(g_compile_mu);
            ++g_compile_waiting;
        }
        send_stats();
        while (!t.killed.load() && !key_lock.try_lock_for(std::chrono::milliseconds(50))) {}
        {
            std::lock_guard<std::mutex> lock(g_compile_mu);
            --g_compile_waiting;
        }
        send_stats();
    }
    if (t.killed.load()) {
        slot.release();
        send_line("DONE " + std::to_string(t.id));
        return;
    }
    auto cached_exe = cache_get(key);
    bool hit = (bool)cached_exe;
    if (cached_exe) exe = cached_exe->path;
    Res cr;
    if (hit) {
        cr.started = true;
        cr.code = 0;
    } else {
        if (!acquire_compile(t)) {
            slot.release();
            send_line("DONE " + std::to_string(t.id));
            return;
        }
        // A peer may have populated the same cache while this task waited.
        cached_exe = cache_get(key);
        hit = (bool)cached_exe;
        if (hit) { exe = cached_exe->path; cr.started = true; cr.code = 0; }
        else {
            if (!write_file(src, source)) cr.err = GetLastError();
            else cr = sandbox_run(g_compile_level, cmd, dir, log, cl, cenv, &t);
        }
        release_compile();
        if (!hit && cr.started && !cr.tle && !cr.timer_error && cr.code == 0 && !t.killed.load() && image_size(exe)) {
            cache_put(key, exe);
            cached_exe = cache_get(key, false);
        }
    }
    key_lock.unlock();
    if (cached_exe) {
#ifdef OI_SPRINT_TREE
        // Read-locked artifacts are immutable for the entire task, including medium-token fallback.
        exe = cached_exe->path;
#else
        wstring private_exe = dir + L"\\" + executable_name;
        if (exe != private_exe && !CopyFileW(cached_exe->path.c_str(), private_exe.c_str(), TRUE)) {
            cr.started = false;
            cr.err = GetLastError();
        } else exe = private_exe;
#endif
    }
    string idstr = std::to_string(t.id);
    if (cr.killed || t.killed.load()) {
        slot.release();
        send_line("DONE " + idstr);
        return;
    }
    string logtext;
    if (!hit) read_file(log, logtext, 64 * 1024);
    bool ok = cr.started && !cr.tle && cr.code == 0 && (cached_exe || file_exists(exe));
    const char *cst = ok ? "OK" : "CE";
    if (cr.mem_hit) {
        logtext="compiler memory limit reached; retry required\n"+logtext;cst="SE";ok=false;
    } else if (cr.timer_error) {
        logtext="compiler CPU accounting unavailable";cst="SE";ok=false;
    } else if (!cr.started) {
        logtext = "agent: compiler failed to start, error " + std::to_string(cr.err);
        cst = "SE";
    } else if (cr.tle) {
        logtext = "compile time limit exceeded\n" + logtext;
    }
    send_line("COMPILE " + idstr + " " + cst + " " + std::to_string(cr.wall_ms) + " " + b64enc(logtext) +
              (hit ? " HIT" : " MISS"));
    if (!ok) {
        slot.release();
        send_line("DONE " + idstr);
        return;
    }

    std::vector<wstring> renv = {L"SystemRoot=" + wstring(_wgetenv(L"SystemRoot")), L"TEMP=" + dir, L"TMP=" + dir};
    wstring exe_name = executable_name;
    unsigned long long image = cached_exe ? cached_exe->image : image_size(exe);
    wstring in = dir + L"\\" + prob + L".in", out = dir + L"\\" + prob + L".out";
    for (int test : t.tests) {
        if (t.killed.load() || t.yielded.load()) break;
        wstring base = g_root + L"\\" + g_data + L"\\" + prob + std::to_wstring(test);
        {
            std::lock_guard<std::mutex> guard(g_answer_mu);
            wstring answer=base+L".ans";
            if (!g_protected_answers.count(answer)) {
                if (!set_mandatory_label(answer,L"S:(ML;;NWNRNX;;;ME)")) {
                    Res e;emit_test(t,test,"SE",e,"cannot protect newly assigned standard answer");continue;
                }
                g_protected_answers.insert(answer);
            }
        }
        clean_dir(dir, exe_name);
        // Never overwrite a surviving input: it may still be a hard link to
        // the shared dataset. A surviving output would also yield a stale verdict.
        if (file_exists(in) || file_exists(out)) {
            Res e;
            emit_test(t, test, "SE", e, "previous input/output is still in use; cannot safely prepare test");
            continue;
        }
        // Hold a deny-write/delete handle below before executing a linked input.
#ifdef OI_SPRINT_REPAIR
        // Repair inputs are private copies; never link them to the canonical data.
        bool linked = false;
#else
        bool linked = CreateHardLinkW(in.c_str(), (base + L".in").c_str(), NULL);
#endif
        if (!linked && !CopyFileW((base + L".in").c_str(), in.c_str(), TRUE)) {
            Res e;
            emit_test(t, test, "SE", e, "cannot prepare input, error " + std::to_string(GetLastError()));
            continue;
        }
        struct InputGuard {
            HANDLE h;
            explicit InputGuard(const wstring &path) : h(CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL)) {}
            ~InputGuard() { if(h!=INVALID_HANDLE_VALUE) CloseHandle(h); }
        } input_guard(in);
        if (input_guard.h == INVALID_HANDLE_VALUE) {
            Res e; emit_test(t,test,"SE",e,"cannot lock private input against modification"); continue;
        }
        Limits rl;
        rl.cpu_ms = t.tl_ms;
        rl.wall_ms = t.tl_ms * 3 + 2000;
#ifdef OI_SPRINT_REPAIR
        // Offline repairs run one point at a time. Allow startup/IO delays without
        // changing the CPU limit; hangs still have a separate bounded wall guard.
        rl.wall_ms = std::max(30000LL, t.tl_ms * 10 + 5000);
#endif
        rl.mem = (unsigned long long)t.ml_mb << 20;
        rl.procs = 1;
        rl.watch = out;
        if (image > rl.mem) {  // static arrays alone exceed the limit
            Res m;
            m.started = true;
            m.peak = image;
            emit_test(t, test, "MLE", m, "");
            continue;
        }
        Res r = sandbox_run(g_run_level, L"\"" + exe + L"\"", dir, L"", rl, renv, &t);
        r.peak = std::max(r.peak, image);
        if (r.killed || t.killed.load()) break;
        string detail;
        const char *st;
        if (!r.started) {
            st = "SE";
            detail = "start failed, error " + std::to_string(r.err);
        } else if (r.timer_error) {
            st="SE";detail="CPU accounting unavailable; result discarded";
        } else if (r.tle) {
            st = "TLE";
            if (r.wall_tle) {
                st = "SE";
                detail = "wall guard reached below CPU limit; retry required, wall=" + std::to_string(r.wall_ms) + "ms";
            } else detail = "CPU time limit exceeded";
        } else if (r.ole) {
            st = "OLE";
        } else if (r.peak > rl.mem || (r.code != 0 && r.mem_hit)) {
            st = "MLE";
        } else if (r.code != 0) {
            st = "RE";
            detail = hex32(r.code);
        } else {
            string o, a;
            if (!file_exists(out)) {
                st = "NOF";
            } else if (!read_file(base + L".ans", a)) {
                st = "SE";
                detail = "cannot read answer";
            } else if (!read_file(out, o, OUTPUT_LIMIT)) {
                st = "SE";
                detail = "cannot read complete output";
            } else {
                st = compare_output(o, a, detail) ? "AC" : "WA";
            }
        }
        emit_test(t, test, st, r, detail);
    }
    slot.release();
    send_line("DONE " + idstr);
}

// A node whose toolchain is broken must refuse work rather than report every student as CE.
static bool compile_selfcheck(const Level &lv, string &log) {
    wstring dir = g_run + L"\\compilecheck";
    CreateDirectoryW(dir.c_str(), NULL);
    write_file(dir + L"\\c.cpp",
               "#include<bits/stdc++.h>\nusing namespace std;\nint main(){cout<<(__cplusplus==201402L?0:1);}\n");
    wstring cmd = L"\"" + g_gpp + L"\" -std=c++14 -O2 -static -Wl,--stack=1073741824 c.cpp \"" + g_binmode + L"\" -o c.exe";
    Limits cl;
    cl.cpu_ms = 60000;
    cl.wall_ms = 120000;
    cl.mem = 3ull << 30;
    cl.procs = 8;
    std::vector<wstring> env = {L"PATH=" + g_root + L"\\mingw\\bin", L"SystemRoot=" + wstring(_wgetenv(L"SystemRoot")),
                                L"TEMP=" + dir, L"TMP=" + dir, L"LC_ALL=C", L"LANG=C"};
    Res r = sandbox_run(lv, cmd, dir, dir + L"\\c.log", cl, env, nullptr);
    read_file(dir + L"\\c.log", log, 8192);
    if (!r.started) log = "compiler failed to start, error " + std::to_string(r.err);
    else log = "exit " + hex32(r.code) + "\n" + log;
    bool ok = r.started && r.code == 0 && file_exists(dir + L"\\c.exe");
    remove_dir(dir);
    return ok;
}

// ---------------------------------------------------------------- self checks
// Runs inside the sandbox. Exit code 42 means: low integrity, no shutdown privilege, cannot
// spawn children, cannot write outside the run dir, cannot read answers.
static int selfcheck(const wchar_t *root) {
    HANDLE tok;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &tok)) return 1;
    DWORD need = 0;
    GetTokenInformation(tok, TokenIntegrityLevel, NULL, 0, &need);
    std::vector<char> b(need);
    if (!GetTokenInformation(tok, TokenIntegrityLevel, b.data(), need, &need)) return 2;
    auto *tml = (TOKEN_MANDATORY_LABEL *)b.data();
    DWORD il = *GetSidSubAuthority(tml->Label.Sid, *GetSidSubAuthorityCount(tml->Label.Sid) - 1);
    bool low = il == SECURITY_MANDATORY_LOW_RID;
    GetTokenInformation(tok, TokenPrivileges, NULL, 0, &need);
    std::vector<char> pb(need);
    GetTokenInformation(tok, TokenPrivileges, pb.data(), need, &need);
    auto *tp = (TOKEN_PRIVILEGES *)pb.data();
    LUID sd;
    LookupPrivilegeValueW(NULL, SE_SHUTDOWN_NAME, &sd);
    for (DWORD i = 0; i < tp->PrivilegeCount; i++)
        if (tp->Privileges[i].Luid.LowPart == sd.LowPart && tp->Privileges[i].Luid.HighPart == sd.HighPart) return 4;
    wstring r = root;
    HANDLE h = CreateFileW((r + L"\\selfcheck_probe").c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
    if (h != INVALID_HANDLE_VALUE) {
        CloseHandle(h);
        DeleteFileW((r + L"\\selfcheck_probe").c_str());
        if (low) return 5;
    }
    h = CreateFileW(L"cwd_probe", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
    if (h == INVALID_HANDLE_VALUE) return 6;
    CloseHandle(h);
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    wchar_t cmd[] = L"cmd.exe /c exit 0";
    if (CreateProcessW(NULL, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        TerminateProcess(pi.hProcess, 0);
        return 7;
    }
    return low ? 42 : 43;
}

// Measures this machine: work per CPU-millisecond of the slowest thread at rising concurrency.
// Scored on each thread's own cycles, so another process preempting a thread does not skew it,
// while slow cores, shared hyperthreads and memory contention all do show up.
struct BenchPoint { int concurrency; double speed, throughput; };

static BenchPoint bench_point(int n, int duration) {
    std::atomic<int> ready{0};
    std::atomic<bool> go{false}, stop{false};
    std::vector<double> scores(n, 0);
    std::vector<unsigned long long> work(n, 0);
    std::vector<std::thread> th;
    for (int i = 0; i < n; ++i) {
        th.emplace_back([&, i] {
            std::vector<unsigned> mem(1 << 18);
            unsigned long long x = 88172645463325252ull + i, iters = 0;
            unsigned acc = 0;
            ++ready;
            while (!go.load()) YieldProcessor();
            long long c0=thread_cpu_100ns();
            while (!stop.load()) {
                for (int k = 0; k < 8000; ++k) {
                    x ^= x << 13; x ^= x >> 7; x ^= x << 17;
                    mem[x & 0x3FFFF] += (unsigned)x;
                    acc += (unsigned)(x >> 32) * 31u + (unsigned)x % 7u;
                }
                for (int k = 0; k < 12000; ++k) acc += mem[k] ^ (acc >> 3);
                iters += 20000;
            }
            long long c1=thread_cpu_100ns();
            volatile unsigned sink = mem[x & 0x3FFFF] + acc;
            (void)sink;
            double ms = c0>=0 && c1>=c0 ? (double)(c1-c0)/10000.0 : 0;
            scores[i] = ms > 0 ? (double)iters / ms : 0;
            work[i] = iters;
        });
    }
    while (ready.load() < n) Sleep(1);
    auto start = std::chrono::steady_clock::now();
    go = true;
    Sleep(duration);
    stop = true;
    for (auto &t : th) t.join();
    double elapsed = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
    unsigned long long total = 0;
    for (auto v : work) total += v;
    return {n, *std::min_element(scores.begin(), scores.end()), elapsed > 0 ? total / elapsed : 0};
}

static string bench_curve(int logical, int memory_slots) {
    static const int levels[] = {1, 2, 3, 4, 6, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 48, 64, 96, 128, 192, 256};
    std::vector<BenchPoint> points;
    for (int n : levels) {
        if (n > std::min(logical,memory_slots)) break;
        points.push_back(bench_point(n, n==1 ? 1000 : 120));
        if (n==1 && points.back().speed<=0) {
            send_line("FATAL "+b64enc("Not enough CPU accounting data for calibration; retry when the node has capacity"));
            ExitProcess(4);
        }
    }
    std::vector<BenchPoint> ranked=points;
    std::sort(ranked.begin(),ranked.end(),[](const BenchPoint &a,const BenchPoint &b){return a.throughput>b.throughput;});
    for (size_t i=0;i<std::min<size_t>(2,ranked.size());++i) {
        BenchPoint repeated=bench_point(ranked[i].concurrency,300);
        for (auto &p:points) if (p.concurrency==repeated.concurrency)
            p.throughput=(p.throughput+repeated.throughput)/2;
    }
    string curve;
    for (const auto &p : points) {
        if (!curve.empty()) curve += ",";
        curve += std::to_string(p.concurrency) + ":" + std::to_string((long long)p.speed) + ":" +
                 std::to_string((long long)p.throughput);
    }
    return curve;
}

static void cores(int &phys, int &perf) {
    phys = 0;
    perf = 0;
    DWORD len = 0;
    GetLogicalProcessorInformationEx(RelationProcessorCore, NULL, &len);
    if (GetLastError() != ERROR_INSUFFICIENT_BUFFER) return;
    std::vector<char> b(len);
    if (!GetLogicalProcessorInformationEx(RelationProcessorCore, (PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)b.data(),
                                          &len))
        return;
    int best = -1;
    for (DWORD off = 0; off < len;) {
        auto *p = (PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)(b.data() + off);
        // PROCESSOR_RELATIONSHIP: BYTE Flags; BYTE EfficiencyClass; ...
        int cls = ((BYTE *)&p->Processor)[1];
        phys++;
        if (cls > best) {
            best = cls;
            perf = 1;
        } else if (cls == best) {
            perf++;
        }
        off += p->Size;
    }
}

// ---------------------------------------------------------------- main
static bool read_line(HANDLE in, string &buf, string &line) {
    for (;;) {
        size_t nl = buf.find('\n');
        if (nl != string::npos) {
            line.assign(buf, 0, nl);
            buf.erase(0, nl + 1);
            if (!line.empty() && line.back() == '\r') line.pop_back();
            return true;
        }
        char tmp[65536];
        DWORD r = 0;
        if (!ReadFile(in, tmp, sizeof(tmp), &r, NULL) || !r) return false;
        buf.append(tmp, r);
    }
}

static std::vector<string> split(const string &s) {
    std::vector<string> v;
    size_t i = 0;
    while (i < s.size()) {
        size_t j = s.find(' ', i);
        if (j == string::npos) j = s.size();
        v.push_back(s.substr(i, j - i));
        i = j + 1;
    }
    return v;
}

int wmain(int argc, wchar_t **argv) {
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX);
    // Heartbeats and limit polling must not starve under a full load of student programs.
    // Above-normal is not inherited: children run at normal priority.
    SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);
    if (argc >= 3 && wcscmp(argv[1], L"--selfcheck") == 0) return selfcheck(argv[2]);
    if (argc >= 2 && wcscmp(argv[1], L"--version") == 0) {
#ifdef OI_SPRINT_TREE
        printf("OI-SPRINT-TREE/1\n");
#else
        printf("OI-SPRINT-CLASSIC/1\n");
#endif
        return 0;
    }
    if (argc < 3 || wcscmp(argv[1], L"serve") != 0) {
        fprintf(stderr, "usage: oi-sprint-agent serve <workdir> [datadir]\n");
        return 2;
    }
    if (!SetCurrentDirectoryW(argv[2])) {
        fprintf(stderr, "bad workdir\n");
        return 2;
    }
    if (argc >= 4) g_data = argv[3];
    wchar_t cwdbuf[4096];
    GetCurrentDirectoryW(4096, cwdbuf);
    g_root = cwdbuf;
    g_cache = g_root + L"\\cache";
    CreateDirectoryW(g_cache.c_str(), NULL);
    read_file(g_root + L"\\VERSION", g_runtime_version, 1024);
    if (g_runtime_version.empty()) {
        // Development runs have no deployment VERSION; hash this agent and the compiler.
        wchar_t module[4096];
        GetModuleFileNameW(NULL, module, 4096);
        string bytes;
        read_file(module, bytes);
        g_runtime_version = sha256(bytes);
        read_file(g_root + L"\\mingw\\bin\\g++.exe", bytes);
        g_runtime_version += sha256(bytes);
    }
    g_stdout = GetStdHandle(STD_OUTPUT_HANDLE);
    HANDLE root_lock = CreateFileW((g_root + L"\\agent-session.lock").c_str(), GENERIC_READ | GENERIC_WRITE,
                                   0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (root_lock == INVALID_HANDLE_VALUE) {
        send_line("FATAL " + b64enc("another agent is already using this deployment directory"));
        return 4;
    }
    HANDLE in = GetStdHandle(STD_INPUT_HANDLE);
    // A child must never inherit the protocol pipes.
    SetHandleInformation(g_stdout, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(in, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(GetStdHandle(STD_ERROR_HANDLE), HANDLE_FLAG_INHERIT, 0);
#ifndef OI_SPRINT_REPAIR
    static std::atomic<unsigned long long> last_command{GetTickCount64()};
    std::thread([] {
        for (;;) {
            Sleep(5000);
            if (GetTickCount64() - last_command.load() > 70000) ExitProcess(6);
        }
    }).detach();
#endif
    g_cpu_job = CreateJobObjectW(NULL, NULL);
    if (g_cpu_job && !AssignProcessToJobObject(g_cpu_job, GetCurrentProcess())) {
        CloseHandle(g_cpu_job);
        g_cpu_job = NULL;
    }

    g_gpp = g_root + L"\\mingw\\bin\\g++.exe";
    g_binmode = g_root + L"\\mingw\\x86_64-w64-mingw32\\lib\\binmode.o";

#ifdef OI_SPRINT_REPAIR
    // Keep canonical data immutable for the entire repair process, even when
    // a machine falls back to a medium-integrity execution token.
    std::vector<HANDLE> data_guards;
    WIN32_FIND_DATAW data_fd;
    HANDLE data_find = FindFirstFileW((g_root + L"\\" + g_data + L"\\*").c_str(), &data_fd);
    if (data_find != INVALID_HANDLE_VALUE) {
        do {
            wstring name = data_fd.cFileName;
            if ((data_fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ||
                (name.size() < 3 || (name.substr(name.size()-3) != L".in" &&
                 (name.size() < 4 || name.substr(name.size()-4) != L".ans")))) continue;
            HANDLE guard = CreateFileW((g_root + L"\\" + g_data + L"\\" + name).c_str(), GENERIC_READ,
                                       FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            if (guard == INVALID_HANDLE_VALUE) {
                send_line("FATAL " + b64enc("cannot lock original repair input/answer against writes"));
                ExitProcess(4);
            }
            data_guards.push_back(guard);
        } while (FindNextFileW(data_find, &data_fd));
        FindClose(data_find);
    }
#endif

    // Layout: run\ is the only tree a sandboxed process may write to.
    wstring run_root = g_root + L"\\run";
    CreateDirectoryW(run_root.c_str(), NULL);
    bool labelled = set_mandatory_label(run_root, L"S:(ML;OICI;NW;;;LW)");
    g_run = run_root + L"\\" + std::to_wstring(GetCurrentProcessId()) + L"_" + std::to_wstring(GetTickCount64());
    CreateDirectoryW(g_run.c_str(), NULL);

    // Answers are unreadable from Low integrity.
    {
        WIN32_FIND_DATAW fd;
        HANDLE h = FindFirstFileW((g_data + L"\\*.ans").c_str(), &fd);
        if (h != INVALID_HANDLE_VALUE) {
            do {
                wstring answer=g_root+L"\\"+g_data+L"\\"+fd.cFileName;
                if (set_mandatory_label(answer,L"S:(ML;;NWNRNX;;;ME)"))g_protected_answers.insert(answer);
            } while (FindNextFileW(h, &fd));
            FindClose(h);
        }
    }

    make_private_desktop();
    strip_own_privileges();
#ifdef OI_SPRINT_REPAIR
    // Keep calibration and contestant execution on the same core type.
    DWORD_PTR allowed = 0, system_allowed = 0;
    if (GetProcessAffinityMask(GetCurrentProcess(), &allowed, &system_allowed) && allowed)
        SetProcessAffinityMask(GetCurrentProcess(), allowed & (~allowed + 1));
#endif
    if (!validate_cpu_clock()) {
        send_line("FATAL "+b64enc("CPU accounting API unavailable; judging is disabled on this node: "+g_clock_diagnostic));
        return 4;
    }
    {
        HANDLE low_tok = labelled ? make_token(true) : NULL;
        HANDLE med_tok = make_token(false);
        std::vector<Level> ladder;
        auto add = [&](HANDLE tok, bool low, bool desk, const char *name) {
            Level l;
            l.token = tok;
            l.low = low;
            l.desktop = desk;
            l.name = name;
            if (tok || !low) ladder.push_back(l);
        };
        if (low_tok) {
            if (!g_desktop.empty()) add(low_tok, true, true, "low");
            add(low_tok, true, false, "low");
        }
        if (med_tok) {
            if (!g_desktop.empty()) add(med_tok, false, true, "restricted");
            add(med_tok, false, false, "restricted");
        }
        add(NULL, false, false, "job");

        wstring dir = g_run + L"\\selfcheck";
        CreateDirectoryW(dir.c_str(), NULL);
        wchar_t self[4096];
        GetModuleFileNameW(NULL, self, 4096);
        // The probe must be readable from Low integrity: run\\ holds a private copy.
        wstring copy = dir + L"\\probe.exe";
        CopyFileW(self, copy.c_str(), FALSE);
        std::vector<wstring> env = {L"SystemRoot=" + wstring(_wgetenv(L"SystemRoot"))};
        bool found = false;
        for (auto &lv : ladder) {
            Limits l;
            l.cpu_ms = 5000;
            l.wall_ms = 10000;
            l.mem = 1ull << 30;
            l.procs = 1;
            Res r = sandbox_run(lv, L"\"" + copy + L"\" --selfcheck \"" + g_root + L"\"", dir, L"", l, env, nullptr);
            DWORD want = lv.low ? 42 : 43;
            bool jobonly = !lv.token;  // agent's own IL decides; privileges and child limits still checked
            if (r.started && (r.code == want || (jobonly && (r.code == 42 || r.code == 43)))) {
                g_run_level = lv;
                found = true;
                break;
            }
        }
        remove_dir(dir);
        if (!found) {
            send_line("FATAL " + b64enc("sandbox unavailable on this host"));
            ExitProcess(4);
        }
        string clog, all;
        found = false;
        for (auto &lv : ladder) {
            if (compile_selfcheck(lv, clog)) {
                g_compile_level = lv;
                found = true;
                break;
            }
            all += string(lv.name) + ": " + clog + "\n";
        }
        if (!found) {
            send_line("FATAL " + b64enc("compile selfcheck failed\n" + all));
            ExitProcess(4);
        }
    }
    string sandbox = string(g_run_level.name) + "," + g_compile_level.name;

    SYSTEM_INFO si;
    GetSystemInfo(&si);
    MEMORYSTATUSEX ms{};
    ms.dwLength = sizeof(ms);
    GlobalMemoryStatusEx(&ms);
    int phys = 0, perf = 0;
    cores(phys, perf);
    OSVERSIONINFOW ov{};
    ov.dwOSVersionInfoSize = sizeof(ov);
    // GetVersionEx lies without a manifest; RtlGetVersion does not.
    auto rtl = (LONG(WINAPI *)(OSVERSIONINFOW *))GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion");
    if (rtl) rtl(&ov);
#ifdef OI_SPRINT_REPAIR
    string measured_curve = bench_curve(1, 1);
#else
    string measured_curve = bench_curve((int)si.dwNumberOfProcessors, std::max(1, (int)(ms.ullTotalPhys >> 20) / 1024 - 2));
#endif
    send_line("HELLO " + std::to_string(ov.dwBuildNumber) + " " + std::to_string(si.dwNumberOfProcessors) + " " +
              std::to_string(phys) + " " + std::to_string(perf) + " " +
              std::to_string(ms.ullTotalPhys >> 20) + " " + measured_curve + " " + sandbox +
#ifdef OI_SPRINT_TREE
              " OI-SPRINT-TREE/1");
#else
              " OI-SPRINT-CLASSIC/1");
#endif

    std::map<long long, std::shared_ptr<Program>> programs;
    string buf, line;
    while (read_line(in, buf, line)) {
#ifndef OI_SPRINT_REPAIR
        last_command = GetTickCount64();
#endif
        auto a = split(line);
        if (a.empty()) continue;
        if (a[0] == "PING") {
            send_line("PONG");
            send_stats();
        } else if (a[0] == "CONFIG" && (a.size() == 2 || a.size() == 3)) {
            int percent = a.size() == 3 ? atoi(a[2].c_str()) : 100;
            if (!set_cpu_percent(percent)) {
                send_line("FATAL " + b64enc("CPU limit unavailable, Windows error " + std::to_string(GetLastError())));
                ExitProcess(5);
            }
            {
                std::lock_guard<std::mutex> lock(g_compile_mu);
                g_compile_limit = std::max(1, atoi(a[1].c_str()));
            }
            g_compile_cv.notify_all();
            send_line("CONFIG_OK " + std::to_string(g_cpu_percent.load()));
            send_stats();
        } else if (a[0] == "QUIT") {
            break;
        } else if (a[0] == "YIELD" && a.size() == 2) {
            std::lock_guard<std::mutex> lk(g_tasks_mu);
            auto it = g_tasks.find(atoll(a[1].c_str()));
            if (it != g_tasks.end()) it->second->yielded = true;
        } else if (a[0] == "KILL" && a.size() >= 2) {
            long long id = atoll(a[1].c_str());
            std::lock_guard<std::mutex> lk(g_tasks_mu);
            auto it = g_tasks.find(id);
            if (it != g_tasks.end()) {
                it->second->killed = true;
                g_compile_cv.notify_all();
                std::lock_guard<std::mutex> lk2(it->second->mu);
                if (it->second->job) TerminateJobObject(it->second->job, 1);
            }
        } else if (a[0] == "DEFINE" && a.size() == 6) {
            auto program = std::make_shared<Program>();
            program->problem = a[2]; program->memory = atoll(a[3].c_str());
            program->flags = atoi(a[4].c_str()); program->source = b64dec(a[5]);
            program->key = sha256(g_runtime_version + "\n" + std::to_string(program->flags) + "\n" +
                std::to_string(program->memory) + "\n" + program->problem + "\n" + program->source);
            programs[atoll(a[1].c_str())] = program;
        } else if ((a[0] == "TASK" && a.size() >= 8) || (a[0] == "RUN" && a.size() == 5)) {
            Task *t = new Task();
            t->id = atoll(a[1].c_str());
            if (a[0] == "RUN") {
                auto program = programs.find(atoll(a[2].c_str()));
                if (program == programs.end()) {
                    send_line("COMPILE " + a[1] + " SE 0 " + b64enc("source registration missing"));
                    send_line("DONE " + a[1]); delete t; continue;
                }
                t->program = program->second;
                t->problem = t->program->problem; t->flags = t->program->flags;
                t->ml_mb = t->program->memory; t->tl_ms = atoll(a[3].c_str());
                t->tests.push_back(atoi(a[4].c_str()));
            } else {
            t->problem = a[2];
            t->tl_ms = atoll(a[3].c_str());
            t->ml_mb = atoll(a[4].c_str());
            t->flags = atoi(a[5].c_str());
            size_t p = 0;
            while (p < a[6].size()) {
                size_t q = a[6].find(',', p);
                if (q == string::npos) q = a[6].size();
                t->tests.push_back(atoi(a[6].substr(p, q - p).c_str()));
                p = q + 1;
            }
            t->source = b64dec(a[7]);
            }
            {
                std::lock_guard<std::mutex> lk(g_tasks_mu);
                g_tasks[t->id] = t;
            }
            std::thread([t] {
                run_task(t);
                std::lock_guard<std::mutex> lk(g_tasks_mu);
                g_tasks.erase(t->id);
                delete t;
            }).detach();
        }
    }
    // Closing the process closes every job, which kills whatever is still running.
    ExitProcess(0);
}
