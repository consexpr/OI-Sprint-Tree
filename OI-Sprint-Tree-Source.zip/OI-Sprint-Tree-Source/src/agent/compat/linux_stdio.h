// glibc-only stdio names that exist on the official judge but not in msvcrt.
#pragma once
#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif
static inline int getc_unlocked(FILE *f) { return --f->_cnt >= 0 ? (unsigned char)*f->_ptr++ : _filbuf(f); }
static inline int putc_unlocked(int c, FILE *f) {
    return --f->_cnt >= 0 ? (unsigned char)(*f->_ptr++ = (char)c) : _flsbuf(c, f);
}
static inline int getchar_unlocked(void) { return getc_unlocked(stdin); }
static inline int putchar_unlocked(int c) { return putc_unlocked(c, stdout); }
static inline int fgetc_unlocked(FILE *f) { return getc_unlocked(f); }
static inline int fputc_unlocked(int c, FILE *f) { return putc_unlocked(c, f); }
static inline size_t fread_unlocked(void *p, size_t s, size_t n, FILE *f) { return fread(p, s, n, f); }
static inline size_t fwrite_unlocked(const void *p, size_t s, size_t n, FILE *f) { return fwrite(p, s, n, f); }
static inline int feof_unlocked(FILE *f) { return feof(f); }
#ifdef __cplusplus
}
#endif
