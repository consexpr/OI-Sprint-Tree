// Target of the source rewrite for plain `long` (64-bit on the official Linux judge).
#pragma once
typedef long long __lp64_long;
