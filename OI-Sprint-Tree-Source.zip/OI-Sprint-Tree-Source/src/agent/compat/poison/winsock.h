#error "winsock.h: not available on the official Linux judge"
