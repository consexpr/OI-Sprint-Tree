#error "windows.h: not available on the official Linux judge"
