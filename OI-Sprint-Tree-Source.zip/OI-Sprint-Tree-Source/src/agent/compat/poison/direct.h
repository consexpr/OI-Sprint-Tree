#error "direct.h: not available on the official Linux judge"
