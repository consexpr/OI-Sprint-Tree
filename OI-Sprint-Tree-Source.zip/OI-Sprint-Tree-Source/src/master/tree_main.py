"""Independent MinGW edition: no WSL, Linux runtime, or system component changes."""
from pathlib import Path
import sys
import judge as J
import main as console

J.PROTOCOL='OI-SPRINT-TREE/1'
J.AGENT_NAME='oi-sprint-tree-agent.exe'
J.REMOTE_SUBDIR='.oi_sprint_tree'
J.RELAY_SUBDIR='.oi_sprint_tree_relay'
J.LOCAL_SUBDIR='worker-tree'
J.AUTO_TREE=True
console.APP_TITLE='OI-Sprint Tree'


def open_master_console():
    # Keep the distribution windowless so upload/process-pool children remain
    # in the background. Only an interactive master allocates its own console.
    if not getattr(sys, 'frozen', False) or '--no-browser' in sys.argv or '--upload-worker' in sys.argv:
        return
    import ctypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetConsoleWindow.restype=ctypes.c_void_p
    kernel.SetConsoleTitleW.argtypes=[ctypes.c_wchar_p]
    if not kernel.GetConsoleWindow() and not kernel.AllocConsole():
        raise OSError(ctypes.get_last_error(), '无法打开主控启动窗口')
    kernel.SetConsoleTitleW('OI-Sprint Tree')
    kernel.SetConsoleOutputCP(65001)
    kernel.SetConsoleCP(65001)
    if sys.stdin is None:sys.stdin=open('CONIN$','r',encoding='utf8')
    if sys.stdout is None:sys.stdout=open('CONOUT$','w',encoding='utf8',buffering=1)
    if sys.stderr is None:sys.stderr=open('CONOUT$','w',encoding='utf8',buffering=1)


def main():
    if '--app-dir' not in sys.argv:
        base=Path(sys.executable).parent/'Tree' if getattr(sys,'frozen',False) else Path(__file__).resolve().parents[2]/'build'/'oi-sprint-tree'/'dev'
        sys.argv.extend(['--app-dir',str(base)])
    if '--port' not in sys.argv:sys.argv.extend(['--port','8876'])
    open_master_console()
    try:
        return console.main()
    except Exception:
        import traceback
        traceback.print_exc()
        if '--no-browser' not in sys.argv and '--upload-worker' not in sys.argv:
            try:input('\n启动失败，按回车关闭。')
            except (EOFError,OSError):pass
        raise


if __name__=='__main__':
    import multiprocessing
    multiprocessing.freeze_support()
    raise SystemExit(main())
