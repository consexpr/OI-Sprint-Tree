"""Verified, immutable test packets. Publish only after the complete packet is valid."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import tarfile
import tempfile
import threading

MANIFEST = '.oi-sprint-manifest.json'
HASH_SCRIPT = r'''
function Get-SprintHash([string]$Path) {
  $stream=[IO.File]::OpenRead($Path)
  $sha=[Security.Cryptography.SHA256]::Create()
  try { [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','').ToLowerInvariant() }
  finally { $stream.Dispose(); $sha.Dispose() }
}
'''
_guard = threading.RLock()
_hashes = {}


def signature(path):
    st = os.stat(path)
    return st.st_size, st.st_mtime_ns, st.st_ctime_ns


def digest(path):
    key = (os.path.abspath(path), signature(path))
    with _guard:
        result = _hashes.get(key)
    if result is None:
        h = hashlib.sha256()
        with open(path, 'rb') as source:
            while chunk := source.read(1 << 20):
                h.update(chunk)
        if signature(path) != key[1]:
            raise ValueError('test data changed while being read')
        result = h.hexdigest()
        with _guard:
            if len(_hashes) > 8192:
                _hashes.clear()
            _hashes[key] = result
    return result


def write_packet(destination, pairs):
    manifest = {}
    with tarfile.open(destination, 'w:gz', compresslevel=1) as archive:
        for source, name in pairs:
            before = signature(source)
            h = hashlib.sha256()
            class Reader:
                def read(self, size):
                    block = stream.read(size)
                    h.update(block)
                    return block
            with open(source, 'rb') as stream:
                entry = tarfile.TarInfo(name)
                entry.size = before[0]
                archive.addfile(entry, Reader())
            if signature(source) != before:
                raise ValueError('test data changed during packing: ' + str(source))
            if name in manifest:
                raise ValueError('duplicate test file: ' + name)
            manifest[name] = {'size': before[0], 'sha256': h.hexdigest()}
        raw = json.dumps(manifest, separators=(',', ':')).encode('ascii')
        entry = tarfile.TarInfo(MANIFEST)
        entry.size = len(raw)
        archive.addfile(entry, io.BytesIO(raw))


def install_packet(archive_path, target, data_name):
    target = Path(target)
    target.mkdir(parents=True, exist_ok=True)
    # Serialise publishers, never the judge/scheduler lock. Existing files are immutable.
    with _guard, tempfile.TemporaryDirectory(prefix='.incoming-', dir=target) as staging:
        staging = Path(staging)
        actual, manifest = {}, None
        with tarfile.open(archive_path, 'r:gz') as archive:
            for entry in archive:
                if not entry.isfile() or entry.name in actual:
                    raise ValueError('invalid/duplicate assigned file')
                if entry.name == MANIFEST:
                    if manifest is not None or entry.size > 8 << 20:
                        raise ValueError('invalid test manifest')
                    manifest = json.load(archive.extractfile(entry))
                    continue
                parts = entry.name.split('/')
                if (len(parts) != 2 or parts[0] != data_name or
                        not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*\.(?:in|ans)', parts[1])):
                    raise ValueError('invalid assigned test path')
                destination = staging / parts[1]
                h = hashlib.sha256()
                size = 0
                with archive.extractfile(entry) as source, destination.open('xb') as output:
                    while chunk := source.read(1 << 20):
                        output.write(chunk)
                        h.update(chunk)
                        size += len(chunk)
                actual[entry.name] = {'size': size, 'sha256': h.hexdigest()}
        if not actual or actual != manifest:
            raise ValueError('incomplete or corrupt assigned test packet')
        folder = target / data_name
        folder.mkdir(exist_ok=True)
        # Commit only fully verified files. Never overwrite a surviving hard link in place.
        for name, info in actual.items():
            filename = name.split('/')[1]
            destination = folder / filename
            if destination.exists() and signature(destination)[0] == info['size'] and digest(destination) == info['sha256']:
                continue
            os.replace(staging / filename, destination)
        return manifest


def install_script(directory, archive_name, packet_hash, data_name):
    """PowerShell 5 installer for execute-only Windows nodes (no Python needed)."""
    def quote(value):
        return "'" + str(value).replace("'", "''") + "'"
    script = r'''
$ErrorActionPreference='Stop'
$base=__BASE__
$packet=Join-Path $base __ARCHIVE__
$stage=Join-Path $base ('.incoming-'+[Guid]::NewGuid().ToString('N'))
try {
  if ((Get-SprintHash $packet) -ne __HASH__) { throw 'Corrupt assigned packet' }
  [IO.Directory]::CreateDirectory($stage) | Out-Null
  & tar.exe -xzf $packet -C $stage
  if ($LASTEXITCODE -ne 0) { throw 'Incomplete assigned archive' }
  $manifest=Get-Content -LiteralPath (Join-Path $stage '.oi-sprint-manifest.json') -Raw | ConvertFrom-Json
  $entries=@($manifest.PSObject.Properties)
  if ($entries.Count -eq 0) { throw 'Empty assigned manifest' }
  foreach ($entry in $entries) {
    if ($entry.Name -notmatch __PATTERN__) { throw 'Invalid assigned path' }
    $source=Join-Path $stage $entry.Name
    if ((Get-Item -LiteralPath $source).Length -ne $entry.Value.size -or
        (Get-SprintHash $source) -ne $entry.Value.sha256) { throw 'Corrupt test file' }
  }
  foreach ($entry in $entries) {
    $source=Join-Path $stage $entry.Name
    $destination=Join-Path $base $entry.Name
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destination)) | Out-Null
    if ([IO.File]::Exists($destination)) {
      if ((Get-Item -LiteralPath $destination).Length -eq $entry.Value.size -and
          (Get-SprintHash $destination) -eq $entry.Value.sha256) { continue }
      [IO.File]::Replace($source,$destination,$null)
    } else { [IO.File]::Move($source,$destination) }
  }
} finally {
  if ([IO.Directory]::Exists($stage)) { Remove-Item -LiteralPath $stage -Recurse -Force }
}
'''
    return (HASH_SCRIPT+script.replace('__BASE__', quote(directory)).replace('__ARCHIVE__', quote(archive_name))
            .replace('__HASH__', quote(packet_hash)).replace('__PATTERN__',
            quote('^' + re.escape(data_name) + r'/[A-Za-z0-9][A-Za-z0-9_-]*\.(in|ans)$')))
