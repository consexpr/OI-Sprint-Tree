"""SSH tree transport: one cached bundle per relay, original agents and scheduler."""
import base64
import json
import os
from pathlib import Path
import queue
import threading
import time
from types import SimpleNamespace
import uuid
import tarfile
import hashlib
import shutil
import tempfile

import assigned_data

import judge as J

WIRE = "OI-SPRINT-RELAY/1"
_package_guard=threading.Lock()
_package_locks={}


def data_package(judge,problem,tests):
    tests=tuple(sorted(set(tests)))
    key=(judge.state_dir,judge.data_dirname(),problem,tests)
    with _package_guard:lock=_package_locks.setdefault(key,threading.Lock())
    with lock:
        folder=Path(judge.state_dir)/'assigned-packets'/judge.data_dirname()
        folder.mkdir(parents=True,exist_ok=True)
        packet_id=hashlib.sha256(repr((problem,tests)).encode('ascii')).hexdigest()[:24]
        packet=folder/(problem[:40]+'-'+packet_id+'.tar.gz')
        if packet.is_file():return packet
        pool=Path(getattr(judge,'assigned_root',Path(judge.state_dir)/'private-data-source'))
        source=pool/judge.data_dirname()
        if not hasattr(judge,'assigned_root'):
            with _package_guard:pool_lock=_package_locks.setdefault((judge.state_dir,'source'),threading.Lock())
            with pool_lock:
                marker=pool/(judge.data_dirname()+'.ready')
                if not marker.is_file() or marker.read_text()!='atomic-source-v2':
                    pool.mkdir(parents=True,exist_ok=True)
                    with tempfile.TemporaryDirectory(prefix='.source-',dir=pool) as temporary:
                        with tarfile.open(judge.data_bundle(),'r:gz') as archive:archive.extractall(temporary,filter='data')
                        if source.exists():shutil.rmtree(source)
                        os.replace(Path(temporary)/judge.data_dirname(),source)
                    marker.write_text('atomic-source-v2')
        temporary=Path(str(packet)+'.tmp-'+uuid.uuid4().hex[:8])
        try:
            pairs=[]
            for test in tests:
                for ext in ('.in','.ans'):
                    name=problem+str(test)+ext
                    pairs.append((source/name,judge.data_dirname()+'/'+name))
            assigned_data.write_packet(temporary,pairs)
            os.replace(temporary,packet)
        finally:
            temporary.unlink(missing_ok=True)
        return packet


class Manager:
    def __init__(self, judge):
        self.judge, self.configs, self.hubs = judge, {}, {}
        self.lock = threading.RLock()
        self.excluded_self_relays = set()
        path = Path(judge.state_dir) / "relays.json"
        if path.is_file():
            for raw in json.loads(path.read_text(encoding="utf8")):
                if judge.is_master_host(raw.get('host','')):
                    self.excluded_self_relays.add(raw['id'])
                    continue
                self.configs[raw["id"]] = raw
            if self.excluded_self_relays:self.save()

    def save(self):
        path = Path(self.judge.state_dir) / "relays.json"
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(list(self.configs.values()), ensure_ascii=False), encoding="utf8")
        os.replace(temporary, path)

    def add(self, text, name=""):
        configs, errors = J.parse_nodes(text)
        if errors or len(configs) != 1:
            raise ValueError("每次填写一台副控：用户名@地址 password:密码；也支持免密 SSH")
        cfg = configs[0]
        return self.add_config(cfg,name)

    def add_config(self,cfg,name="", existing_node=None):
        cfg=dict(cfg)
        if self.judge.is_master_host(cfg.get('host','')):
            raise ValueError('主控本机不能作为副控')
        cfg.pop('relay',None)
        with self.lock:
            for existing in self.configs.values():
                if all(existing.get(k) == cfg.get(k) for k in ("host","user","port","dir")):
                    raise ValueError("这台副控已存在，请重连或修改下属节点")
            rid = uuid.uuid4().hex[:12]
            cfg.update(id=rid, name=name.strip() or cfg["host"], password_sealed=J.protect(cfg.pop("password", "")))
            self.configs[rid] = cfg
            self.save()
        # The relay's own worker is a separate leaf, so disabling it keeps routing alive.
        if existing_node is not None:
            # Promotion keeps the public node ID and per-machine settings. The
            # old direct session is closed only after its current leases drain.
            existing_node.restarting=True
            existing_node.session+=1
            existing_node._drop_connection()
            existing_node.relay_id=rid
            existing_node.relay_local=True
            existing_node.managed=True
            existing_node.routing_draining=False
            existing_node.remote_status={}
            existing_node.stage='offline'
            self.judge.save_nodes()
            existing_node.wake.set()
        self.judge.add_node({"host":cfg["host"],"user":cfg["user"],"port":cfg["port"],
                             "relay":rid,"gateway":True,"enabled":True,"slots":None})
        if existing_node is None:self.judge.add_node({"host":cfg["host"], "user":cfg["user"], "port":cfg["port"],
                             "relay":rid, "relay_local":True, "enabled":True, "slots":cfg.get('slots'),
                             "cpu_limit":cfg.get('cpu_limit')})
        return rid

    def workers(self,rid):
        return [{"id":n.id,"host":n.host,"user":n.user,"port":n.port,"password":n.password,"dir":n.dir,
                 "key":n.key,"slots":n.slots,"cpu_limit":n.cpu_limit_override,"enabled":n.enabled,
                 "relay_local":n.relay_local}
                for n in list(self.judge.nodes.values()) if n.relay_id==rid and n.managed]

    def synchronize(self):
        with self.lock:hubs=list(self.hubs.items())
        for rid,hub in hubs:
            workers=self.workers(rid)
            serialized=json.dumps(workers,sort_keys=True)
            if serialized==getattr(hub,'last_workers',None):continue
            with hub.lock:endpoints=list(hub.endpoints.values())
            for endpoint in endpoints:
                if endpoint.node.gateway:
                    try:hub.send({"op":"configure","id":endpoint.token,"workers":workers})
                    except Exception:continue
                    hub.last_workers=serialized

    def accept_status(self,rid,snapshots):
        with self.judge.lock:
            connected = False
            for snapshot in snapshots:
                node=self.judge.nodes.get(snapshot['id'])
                if node and node.managed and node.relay_id==rid:
                    node.remote_status=snapshot;node.stage=snapshot['stage'];node.info=snapshot['info']
                    if (snapshot.get('connected_once') or snapshot['stage']=='online') and not node.connected_once:
                        node.connected_once=True;connected=True
            if connected:self.judge.save_nodes()

    def mark_offline(self,rid):
        with self.judge.lock:
            for node in self.judge.nodes.values():
                if node.managed and node.relay_id==rid:
                    node.stage='offline'
                    if node.remote_status:node.remote_status={**node.remote_status,'stage':'offline','rate':0,'power':0}

    def hub(self, rid):
        old = None
        with self.lock:
            if rid not in self.configs:
                raise ValueError("副控不存在")
            signature = (self.judge.payload_version(), self.judge.data_dirname())
            hub = self.hubs.get(rid)
            if hub is None or hub.signature != signature:
                old=hub
                hub = self.hubs[rid] = Hub(self, rid, signature)
        if old:old.close()
        return hub

    def reconnect(self, rid):
        nodes=[n for n in list(self.judge.nodes.values()) if n.relay_id==rid]
        for node in nodes:node.restarting=True
        with self.lock:
            if rid not in self.configs: raise ValueError("副控不存在")
            hub = self.hubs.pop(rid, None)
        if hub: hub.close()
        for node in nodes:node.restart()

    def status(self):
        with self.lock:
            return [{"id":rid, "name":c["name"], "host":c["host"],
                     "stage":self.hubs[rid].stage if rid in self.hubs else "offline",
                     "transfer":self.hubs[rid].transfer if rid in self.hubs else None,
                     "error":self.hubs[rid].error if rid in self.hubs else ""}
                    for rid,c in self.configs.items()]

    def close(self):
        with self.lock:
            hubs = list(self.hubs.values()); self.hubs.clear()
        for hub in hubs: hub.close()


class Hub:
    def __init__(self, manager, rid, signature):
        self.manager, self.rid, self.signature = manager, rid, signature
        self.lock = threading.RLock()
        self.connect_lock = threading.Lock()
        self.endpoints = {}
        self.conn = self.channel = None
        self.outbox = None
        self.stage, self.error = "offline", ""
        self.transfer = None
        self.closed=False
        self.retry_after=0

    def upload(self, source, remote, sftp):
        size = os.path.getsize(source)
        checksum=assigned_data.digest(source)
        marker = remote + ".ready"
        try:
            with sftp.open(marker) as f:
                if f.read().decode("ascii") == checksum and sftp.stat(remote).st_size == size:
                    return
        except OSError: pass
        temporary = remote + ".tmp-" + uuid.uuid4().hex[:8]
        started=time.monotonic()
        def progress(done,total,rate=None):
            self.transfer={"file":Path(source).name,"done":done,"total":total,
                           "rate":rate if rate is not None else done/max(.001,time.monotonic()-started)}
        if size<=4<<20:
            sftp.put(str(source),temporary,callback=progress)
        else:
            self.conn._upload_bundle(str(source), temporary, progress)
        check=assigned_data.HASH_SCRIPT+"\nGet-SprintHash '"+temporary.lstrip('/').replace('/','\\').replace("'","''")+"'"
        code,out,err=self.conn.powershell(check,180)
        if code or out.decode('ascii','replace').strip().lower()!=checksum:
            try:sftp.remove(temporary)
            except OSError:pass
            detail=(err or out).decode('utf8','replace').strip()[:180]
            raise RuntimeError(f'副控载荷传输校验失败，校验命令退出 {code}：{detail}')
        try: sftp.posix_rename(temporary, remote)
        except OSError:
            try: sftp.remove(remote)
            except OSError: pass
            sftp.rename(temporary, remote)
        with sftp.open(marker, "w") as f: f.write(checksum)

    def ensure(self):
        with self.connect_lock:
            if self.closed:raise RuntimeError("副控连接代次已作废")
            if self.channel and not self.channel.closed: return
            if time.monotonic()<self.retry_after:raise RuntimeError(self.error or "副控正在重新连接")
            self.stage, self.error = "uploading", ""
            j = self.manager.judge
            cfg = dict(self.manager.configs[self.rid])
            password = J.unprotect(cfg.get("password_sealed", ""))
            if password is None: raise ValueError("副控密码需使用原 Windows 用户重新输入")
            cfg["password"] = password
            dummy = SimpleNamespace(judge=j,alive=True,enabled=True,transfer=None,
                                    set_stage=lambda stage,pct=0:setattr(self,"stage",stage))
            conn = self.conn = J.SSHConn(dummy,cfg)
            try:
                sftp = conn._connect()
                base = conn.sftp_dir.rsplit("/",1)[0] + "/" + J.RELAY_SUBDIR
                if '"' in base or '\n' in base: raise ValueError("副控目录含无效字符")
                conn.sftp_dir, conn.win_dir = base, base.lstrip("/").replace("/","\\")
                version = self.signature[0]
                if not all(c in "0123456789abcdef" for c in version): raise ValueError("副控载荷版本无效")
                payload = base + "/payload_" + version
                conn._mkdirs(sftp,payload)
                # Executable is versioned as well: reconnect never overwrites a running relay.
                for name in ("runtime.tar.gz",J.AGENT_NAME,"oi-sprint-relay.exe"):
                    source = Path(j.payload)/name
                    self.upload(source,payload+"/"+name,sftp)
                with sftp.open(payload+"/version.txt","w") as f: f.write(version)
                data_file = ""
                sftp.close()
                if self.closed:raise RuntimeError("副控连接已取消")
                channel = self.channel = conn.client.get_transport().open_session(window_size=8*1024*1024)
                channel.settimeout(75)
                exe = conn.win_dir + "\\payload_" + version + "\\oi-sprint-relay.exe"
                channel.exec_command(conn._in_dir('"'+exe+'" --relay-worker "'+conn.win_dir+'"'))
                reader = channel.makefile("rb")
                init = {"op":"init","protocol":WIRE,"version":version,"data":data_file,
                        "data_name":j.data_dirname(),"contest":bool(j.contest),"scale":j.contest.get('scale',True) if j.contest else True,
                        "agent_name":J.AGENT_NAME,"agent_protocol":J.PROTOCOL,"remote_subdir":J.REMOTE_SUBDIR,"local_subdir":J.LOCAL_SUBDIR}
                channel.sendall((json.dumps(init)+"\n").encode("ascii"))
                raw=reader.readline()
                if not raw:
                    code=channel.recv_exit_status()
                    detail=channel.makefile_stderr('rb').read(2048).decode('utf8','replace').strip()
                    raise RuntimeError(f'副控启动失败，退出 {code}：'+(detail or '未返回协议握手，请查看副控 worker-error.log'))
                reply = json.loads(raw)
                if reply != {"ready":WIRE}: raise RuntimeError("副控协议不匹配："+str(reply)[:100])
                self.outbox = queue.Queue(maxsize=2048)
                threading.Thread(target=self.writer,args=(channel,self.outbox),daemon=True).start()
                threading.Thread(target=self.reader,args=(channel,reader),daemon=True).start()
                self.stage = "online"
                self.transfer = None
            except Exception as error:
                self.error = J._describe(error,password); self.stage="error"
                self.retry_after=time.monotonic()+3
                conn.close(); self.channel=None
                raise

    def send(self, message):
        outbox = self.outbox
        if outbox is None: raise RuntimeError("副控未连接")
        outbox.put_nowait((json.dumps(message,ensure_ascii=True)+"\n").encode("ascii"))

    def writer(self, channel, outbox):
        try:
            while True:
                first = outbox.get()
                if first is None: return
                chunks=[first]
                while len(chunks)<32:
                    try: chunks.append(outbox.get_nowait())
                    except queue.Empty: break
                if None in chunks: return
                channel.sendall(b"".join(chunks))
        except Exception:
            channel.close()

    def reader(self, channel, reader):
        try:
            for raw in reader:
                message=json.loads(raw)
                with self.lock: endpoint=self.endpoints.get(message.get("id"))
                if endpoint:
                    if message.get("type")=="line": endpoint.messages.put_nowait(base64.b64decode(message["data"]))
                    elif message.get("type")=="stage":
                        endpoint.node.transfer=message.get("transfer")
                        endpoint.node.set_stage(message["stage"],message.get("pct",0))
                    elif message.get("type")=="error":
                        endpoint.fail(RuntimeError(message["error"]))
        except Exception as error:
            self.error=str(error)[:200]
        finally:
            with self.lock:
                if self.channel is channel:
                    self.stage="offline";self.channel=None
                    endpoints=list(self.endpoints.values());self.endpoints.clear()
                    self.conn.close();self.outbox=None
                else: endpoints=[]
            for endpoint in endpoints: endpoint.fail(RuntimeError("副控连接中断，未完成任务将重排"))

    def close(self):
        with self.lock:
            self.closed=True
            conn=self.conn
            outbox=self.outbox
            if conn: conn.close()
            endpoints=list(self.endpoints.values());self.endpoints.clear()
            self.channel=None;self.stage="offline";self.outbox=None
        if outbox:
            try:outbox.put_nowait(None)
            except queue.Full:pass
        for endpoint in endpoints: endpoint.fail(RuntimeError("副控已重连或树形关系已维护"))


class Connection:
    def __init__(self,node):
        self.node=node
        self.token=uuid.uuid4().hex
        self.messages=queue.Queue(maxsize=16384)
        self.hub=None
        self.timeout=75
        self.closed=False
        self.sent_packets=set()

    def prepare(self):
        self.node.set_stage("connecting")
        self.hub=self.node.judge.relays.hub(self.node.relay_id)
        self.hub.ensure()
        with self.hub.lock: self.hub.endpoints[self.token]=self

    def open(self):
        n=self.node
        self.hub.send({"op":"open","id":self.token,"cfg":{"host":n.host,"user":n.user,"port":n.port,
                       "password":n.password,"key":n.key,"dir":n.dir,"local":n.relay_local,
                       "gateway":n.gateway,"scale":n.judge.contest.get('scale',True) if n.judge.contest else True,
                       "workers":n.judge.relays.workers(n.relay_id) if n.gateway else []}})
        return self

    def readline(self):
        try: value=self.messages.get(timeout=self.timeout)
        except queue.Empty: raise TimeoutError("等待副控或下属节点超时")
        if isinstance(value,Exception): raise value
        return value

    def send(self,data):
        if self.closed: raise RuntimeError("树形连接已关闭")
        for line in data.splitlines(keepends=True):
            if self.node.gateway and line.startswith(b'TASK '):
                a=line.decode('ascii').split()
                packet=data_package(self.node.judge,a[2],[int(t) for t in a[6].split(',')])
                relative='assigned-'+packet.name
                if relative not in self.sent_packets:
                    sftp=self.hub.conn.client.open_sftp()
                    try:self.hub.upload(packet,self.hub.conn.sftp_dir+'/'+relative,sftp)
                    finally:sftp.close()
                    self.hub.send({'op':'data','id':self.token,'archive':relative})
                    self.sent_packets.add(relative)
            self.hub.send({"op":"send","id":self.token,"data":base64.b64encode(line).decode("ascii")})

    def set_timeout(self,timeout): self.timeout=timeout

    def fail(self,error):
        # Closing must never wait for a full result queue while the judge lock is held.
        while True:
            try:self.messages.get_nowait()
            except queue.Empty:break
        try:self.messages.put_nowait(error)
        except queue.Full:pass

    def close(self):
        self.closed=True
        if self.hub:
            with self.hub.lock: self.hub.endpoints.pop(self.token,None)
            try: self.hub.send({"op":"close","id":self.token})
            except Exception: pass
        self.fail(b"")
