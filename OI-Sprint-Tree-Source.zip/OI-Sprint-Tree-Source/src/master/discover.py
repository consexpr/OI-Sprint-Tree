"""Finds machines answering SSH on the local network. Reads the banner only; never logs in."""
import ipaddress
import socket
from concurrent.futures import ThreadPoolExecutor
import os
import struct
import threading
import time
from parallel_work import bounded_unordered

MAX_HOSTS = 4096
SCAN_MAX_HOSTS = 65536
DEFAULT_SCAN_RANGE = '192.168.0.0/16'
_address_lock = threading.Lock()
_address_cache = (0, frozenset())


def local_addresses():
    """All local IPv4 interfaces, including interfaces absent from hostname DNS."""
    global _address_cache
    now=time.monotonic()
    with _address_lock:
        if _address_cache[1] and now-_address_cache[0]<30:return _address_cache[1]
        addresses={'127.0.0.1','0.0.0.0'}
        if os.name=='nt':
            import ctypes
            from ctypes import wintypes
            class Row(ctypes.Structure):
                _fields_=[('address',wintypes.DWORD),('index',wintypes.DWORD),('mask',wintypes.DWORD),
                          ('broadcast',wintypes.DWORD),('reassembly',wintypes.DWORD),
                          ('unused',wintypes.WORD),('kind',wintypes.WORD)]
            try:
                fn=ctypes.WinDLL('iphlpapi').GetIpAddrTable
                fn.argtypes=[ctypes.c_void_p,ctypes.POINTER(wintypes.ULONG),wintypes.BOOL]
                fn.restype=wintypes.ULONG
                size=wintypes.ULONG(0)
                fn(None,ctypes.byref(size),False)
                if size.value>=4:
                    buffer=ctypes.create_string_buffer(size.value)
                    if fn(buffer,ctypes.byref(size),False)==0:
                        count=min(wintypes.DWORD.from_buffer(buffer).value,(len(buffer)-4)//ctypes.sizeof(Row))
                        for index in range(count):
                            row=Row.from_buffer(buffer,4+index*ctypes.sizeof(Row))
                            addresses.add(socket.inet_ntoa(struct.pack('=I',row.address)))
            except (OSError,ValueError):pass
        if len(addresses)==2:
            try:addresses.update(socket.gethostbyname_ex(socket.gethostname())[2])
            except OSError:pass
        _address_cache=(now,frozenset(addresses))
        return _address_cache[1]


def is_local_host(host, addresses=None):
    host=str(host).strip().strip('[]').rstrip('.').casefold()
    if host in ('localhost',socket.gethostname().rstrip('.').casefold()):return True
    try:
        address=ipaddress.ip_address(host)
        if address.is_loopback or address.is_unspecified:return True
        if address.version==6 and address.ipv4_mapped:host=str(address.ipv4_mapped)
    except ValueError:pass
    return host in (local_addresses() if addresses is None else addresses)


def local_ranges():
    """The /24 of each usable local address, most useful first."""
    addrs = set()
    try:
        addrs.update(socket.gethostbyname_ex(socket.gethostname())[2])
    except OSError:
        pass
    try:
        # Connecting a UDP socket sends nothing; it only reveals the address of the default route.
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            primary = s.getsockname()[0]
            addrs.add(primary)
    except OSError:
        primary = None
    out = []
    for a in sorted(addrs, key=lambda x: x != primary):
        ip = ipaddress.ip_address(a)
        # 198.18.0.0/15 is what proxy tools use for their virtual adapters.
        if ip.is_loopback or ip.is_link_local or ip in ipaddress.ip_network("198.18.0.0/15"):
            continue
        net = str(ipaddress.ip_network(a + "/24", strict=False))
        if net not in out:
            out.append(net)
    return out


def expand(text, max_hosts=MAX_HOSTS):
    """192.168.11.0/24, 192.168.11.10-50, 192.168.11.7 or several separated by spaces or commas."""
    hosts = []
    for part in text.replace(",", " ").split():
        try:
            if "/" in part:
                net = ipaddress.ip_network(part, strict=False)
                if net.version != 4 or net.num_addresses > max_hosts + 2:
                    raise ValueError("范围过大或不是 IPv4 地址")
                hosts += [str(h) for h in (net.hosts() if net.num_addresses > 2 else net)]
            elif "-" in part:
                first, last = part.split("-", 1)
                start = ipaddress.ip_address(first)
                end = ipaddress.ip_address(last) if "." in last else ipaddress.ip_address(first.rsplit(".", 1)[0] + "." + last)
                if start.version != 4 or end.version != 4 or not 0 <= int(end) - int(start) < max_hosts:
                    raise ValueError("地址范围倒序或过大")
                hosts += [str(ipaddress.ip_address(int(start) + i)) for i in range(int(end) - int(start) + 1)]
            else:
                address = ipaddress.ip_address(part)
                if address.version != 4:
                    raise ValueError("只支持 IPv4 地址")
                hosts.append(str(address))
        except ValueError:
            raise ValueError("无法识别范围：" + part)
        if len(hosts) > max_hosts:
            raise ValueError(f"范围过大，最多 {max_hosts} 个地址")
    return list(dict.fromkeys(hosts))


def _probe(host, port):
    try:
        with socket.create_connection((host, port), timeout=0.6) as s:
            s.settimeout(1.5)
            banner = s.recv(128).decode("ascii", "replace").strip()
    except OSError:
        return None
    if not banner.startswith("SSH-"):
        return None
    return {"host": host, "port": port, "banner": banner[:60], "windows": "windows" in banner.lower()}


def scan(text, port=22):
    text=text.strip() or DEFAULT_SCAN_RANGE
    if text.casefold() in ('192.168.x.0','192.168.*.0','192.168.*.*'):text=DEFAULT_SCAN_RANGE
    addresses=local_addresses()
    hosts = [host for host in expand(text,max_hosts=SCAN_MAX_HOSTS) if not is_local_host(host,addresses)]
    if not hosts:
        return {'scanned':0,'found':[]}
    with ThreadPoolExecutor(max_workers=256) as ex:
        found = [r for r in bounded_unordered(lambda h: _probe(h,port),hosts,workers=256,executor=ex) if r]
    found.sort(key=lambda r:ipaddress.ip_address(r['host']))
    return {"scanned": len(hosts), "found": found}
