"""Static checks and Linux-compat source rewriting for submissions."""
import re
import base64
from bisect import bisect_left

_TYPE_WORD = r'\b(?:unsigned|signed|long|int|short|char|double)\b'
_TYPE_SPEC = _TYPE_WORD + r'(?:\s+' + _TYPE_WORD + r')*'
# One whitespace character per separator alternative: (?:\s+)+ admits
# exponentially many partitions of aligned spaces before a non-type identifier.
_TYPE_WITH_COMMENTS = _TYPE_WORD + r'(?:(?:\s|/\*.*?\*/|//[^\n]*\n|\\\r?\n)+' + _TYPE_WORD + r')*'
# Keep scanning's comment tokens separate; only the type rewriter groups comments as whitespace.
_TOKEN_PATTERN = r"""
    (?P<raw>(?:u8|u|U|L)?R"(?P<delimiter>[^\s()\\]{0,16})\(.*?\)(?P=delimiter)")
  | (?P<comment>//[^\n]*|/\*.*?\*/)
  | (?P<string>"(?:\\.|[^"\\\n])*")
  | (?P<char>'(?:\\.|[^'\\\n])*')
  | (?P<spec>TYPE_SPEC)
  | (?P<num>(?<![\w.])(?:0[xX][0-9a-fA-F]+|\d+)(?:[uU]?[lL]|[lL][uU])(?![\w.]))
  | (?P<id>\b[A-Za-z_]\w*\b)
    """
_TOKEN = re.compile(_TOKEN_PATTERN.replace('TYPE_SPEC', _TYPE_SPEC), re.S | re.X)
_REWRITE_TOKEN = re.compile(_TOKEN_PATTERN.replace('TYPE_SPEC', _TYPE_WITH_COMMENTS), re.S | re.X)

# `long` is 32-bit on Windows and 64-bit on the official Linux judge: these names change with it.
_LONG_FUNCS = {
    "stol": "stoll", "stoul": "stoull", "atol": "atoll", "strtol": "strtoll", "strtoul": "strtoull", "labs": "llabs",
    "__builtin_popcountl": "__builtin_popcountll", "__builtin_clzl": "__builtin_clzll",
    "__builtin_ctzl": "__builtin_ctzll", "__builtin_ffsl": "__builtin_ffsll",
    "__builtin_parityl": "__builtin_parityll", "__builtin_labs": "__builtin_llabs",
}
_FORMAT_LONG = re.compile(r"%%|%((?:\d+\$)?[-+ #0']*(?:\*(?:\d+\$)?|\d*)(?:\.(?:\*(?:\d+\$)?|\d+))?)l([dioxXun])")
_FORMAT_ARG = {'printf': 0, 'scanf': 0, 'vprintf': 0, 'vscanf': 0,
               'fprintf': 1, 'fscanf': 1, 'sprintf': 1, 'sscanf': 1,
               'vfprintf': 1, 'vfscanf': 1, 'vsprintf': 1, 'vsscanf': 1,
               'snprintf': 2, 'vsnprintf': 2}
_FORMAT_CALL = re.compile(r'\b(' + '|'.join(_FORMAT_ARG) + r')\s*\(')
_CALL_OPEN = re.compile(r'\s*\(')


def _convert_format(text):
    return _FORMAT_LONG.sub(lambda f: f.group() if f.group() == '%%' else '%' + f[1] + 'll' + f[2], text)


def _format_spans(code):
    tokens = list(_TOKEN.finditer(code))
    starts = [t.start() for t in tokens]
    masked = list(code)
    for token in tokens:
        if token.lastgroup in ('raw', 'comment', 'string', 'char'):
            masked[token.start():token.end()] = ' ' * len(token.group())
    masked = ''.join(masked)
    spans, unsafe = set(), False
    for token in tokens:
        if (token.lastgroup == 'id' and token.group() in _FORMAT_ARG and
                not _CALL_OPEN.match(masked,token.end())):
            unsafe = True  # A function pointer/alias or preprocessor substitution.
    for call in _FORMAT_CALL.finditer(masked):
        wanted = _FORMAT_ARG[call[1]]
        depth, arg, start, end = 1, 0, call.end(), None
        for pos in range(start, len(masked)):
            char = masked[pos]
            if char in '([{': depth += 1
            elif char in ')]}':
                depth -= 1
                if depth == 0:
                    if arg == wanted: end = pos
                    break
            elif char == ',' and depth == 1:
                if arg == wanted:
                    end = pos
                    break
                arg += 1;start = pos + 1
        if end is None: continue
        literals = [t for t in tokens[bisect_left(starts,start):bisect_left(starts,end)]
                    if t.end() <= end and t.lastgroup in ('raw', 'string')]
        if masked[start:end].strip() or not literals:
            unsafe = True  # A variable/macro/computed format cannot be safely rewritten lexically.
            continue
        payloads = [t.group().split('(', 1)[1].rsplit(')', 1)[0] if t.lastgroup == 'raw' else t.group()[1:-1] for t in literals]
        if _convert_format(''.join(payloads)) != ''.join(_convert_format(p) for p in payloads):
            unsafe = True  # A conversion split across adjacent literals needs a full preprocessor.
            continue
        spans.update(t.start() for t in literals)
    return spans, unsafe


def lp64_risks(code):
    return ['LP64 动态格式串无法安全自动转换，需复核'] if _format_spans(code)[1] else []


def rewrite_long(code):
    """Returns (code, changed). Comments, line numbers and everything else stay intact."""
    changed = False

    def sub(m):
        nonlocal changed
        kind = m.lastgroup
        text = m.group()
        if kind == "spec":
            plain = re.sub(r'/\*.*?\*/|//[^\n]*\n|\\\r?\n', ' ', text, flags=re.S)
            words = plain.split()
            if words.count("long") != 1 or "double" in words:
                return text
            changed = True
            replacement = 'long long' if any(w in words for w in ('unsigned', 'signed', 'int')) else '__lp64_long'
            return re.sub(r'/\*.*?\*/|//[^\n]*\n|\\\r?\n|\blong\b',
                          lambda t: replacement if t.group() == 'long' else t.group(), text, flags=re.S)
        if kind == "num":
            changed = True
            digits = text.rstrip("uUlL")
            suffix = text[len(digits):].upper().replace("L", "")
            return digits + suffix + "LL"
        if kind == "id" and text in _LONG_FUNCS:
            changed = True
            return _LONG_FUNCS[text]
        return text

    out = _REWRITE_TOKEN.sub(sub, code)
    if not changed:
        return code, False

    format_spans, _ = _format_spans(out)
    def fmt(m):
        return _convert_format(m.group()) if m.start() in format_spans else m.group()

    return _TOKEN.sub(fmt, out), True


_HARMLESS_SYSTEM = re.compile(r'\bsystem\s*\(\s*"\s*(?:pause|cls|clear|color\s*\w*|title[^"]*)\s*"\s*\)')
_DANGEROUS_CALLS = re.compile(
    r"\b(WinExec|ShellExecute\w*|CreateProcess\w*|ExitWindows\w*|InitiateSystemShutdown\w*|InitiateShutdown\w*"
    r"|NtShutdownSystem|ZwShutdownSystem|RtlAdjustPrivilege|NtRaiseHardError|TerminateProcess|LoadLibrary\w*"
    r"|GetProcAddress|DeleteFile\w*|RemoveDirectory\w*|WSAStartup|fork|vfork|execl|execlp|execle|execv|execvp|execve"
    r"|popen|_popen|_spawn\w*|spawn[lv]\w*|socket|unlink|_unlink|rmdir|_rmdir|rename|remove|reboot)\s*\("
)
_ASM = re.compile(r"\b(?:__asm__|__asm|asm)\b")
_INCLUDE_PATH = re.compile(r'#\s*include\s*["<](?:[A-Za-z]:|/|[^">]*\.\.)')
_STRING_DANGER = re.compile(
    r"shutdown|poweroff|reboot|logoff|taskkill|tskill|regedit|\bformat\s+[a-z]:|\bdel\s|\berase\s|\brd\s|\brmdir\s"
    r"|\brm\s+-|\bmkfs\b|\bwmic\b|\bpowershell\b|\bcmd\b|\bnet\s+user\b|\breg\s+(?:add|delete)\b|\.\.[\\/]"
    r"|^[A-Za-z]:[\\/]|^/(?:home|etc|usr|tmp|dev|proc|root|var|boot|sys)\b",
    re.I,
)


def _unescape_hex(s):
    return re.sub(r"\\x([0-9a-fA-F]{2})", lambda m: chr(int(m.group(1), 16)), s)


def scan(code):
    """Reasons to quarantine a submission; empty means it may run. The sandbox still applies either way."""
    reasons = []
    no_comments = _TOKEN.sub(lambda m: " " if m.lastgroup == "comment" else m.group(), code)
    # Calls inside string literals are data, not executed code.
    calls = _TOKEN.sub(lambda m: " " * len(m.group()) if m.lastgroup in ("string", "char", "raw") else m.group(), no_comments)
    harmless = list(_HARMLESS_SYSTEM.finditer(no_comments))
    for m in harmless:
        calls = calls[:m.start()] + " " * (m.end()-m.start()) + calls[m.end():]
    without_harmless = calls
    if re.search(r"\bsystem\s*\(", without_harmless):
        reasons.append("system()")
    for m in _DANGEROUS_CALLS.finditer(calls):
        name = m.group(1)
        # A contestant's own function named remove/rename, e.g. `void remove(int x)`.
        if name in ("remove", "rename", "socket", "fork") and re.search(
                r"\b(?:void|int|bool|long|char|auto|double|float|ll|LL)\s*[*&]?\s*" + name + r"\s*\(", no_comments):
            continue
        reasons.append(name + "()")
    if _ASM.search(calls):
        reasons.append("asm")
    if _INCLUDE_PATH.search(no_comments):
        reasons.append("#include path")
    for m in _TOKEN.finditer(no_comments):
        if m.lastgroup not in ("string", "raw"):
            continue
        text = m.group().split("(",1)[1].rsplit(")",1)[0] if m.lastgroup == "raw" else _unescape_hex(m.group()[1:-1])
        hit = _STRING_DANGER.search(text)
        if hit:
            reasons.append('"' + text[:40] + '"')
    seen = []
    for r in reasons:
        if r not in seen:
            seen.append(r)
    return seen


def decode_source(raw):
    for enc in ("utf-8-sig", "gb18030"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            pass
    return raw.decode("utf-8", "replace")


def analyze_source(code, raw=None, linux=False):
    reasons = scan(code)
    rewritten, changed = (code, False) if linux else rewrite_long(code)
    if changed: reasons.extend(lp64_risks(code))
    flags = (1 if '_unlocked' in code else 0) | (2 if changed else 0)
    source = raw if linux and raw is not None else rewritten.encode('utf8')
    return code, reasons, changed, flags, base64.b64encode(source).decode() or '-'


def prepare_source(raw, linux=False):
    return analyze_source(decode_source(raw), raw, linux)
