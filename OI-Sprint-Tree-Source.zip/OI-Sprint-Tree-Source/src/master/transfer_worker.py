"""Isolated SFTP upload. Credentials arrive through stdin, never command-line arguments."""
import json
import os
import socket
import sys
import time

import paramiko


def main():
    if sys.stdin is None or sys.stdout is None:
        import ctypes
        import io
        import msvcrt
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.GetStdHandle.argtypes=[ctypes.c_ulong];kernel.GetStdHandle.restype=ctypes.c_void_p
        for name,handle,mode,flags in (('stdin',-10,'rb',os.O_RDONLY),('stdout',-11,'wb',os.O_WRONLY)):
            if getattr(sys,name) is not None:continue
            raw=kernel.GetStdHandle(handle & 0xffffffff)
            if not raw or raw==ctypes.c_void_p(-1).value:raise RuntimeError('传输进程缺少通信管道')
            stream=os.fdopen(msvcrt.open_osfhandle(raw,flags|os.O_BINARY),mode,buffering=0)
            setattr(sys,name,io.TextIOWrapper(stream,encoding='utf8',write_through=True))
    cfg = {}
    client = paramiko.SSHClient()
    try:
        cfg = json.loads(sys.stdin.readline())
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(cfg["host"], port=cfg.get("port") or 22, username=cfg["user"],
                       password=cfg.get("password") or "", key_filename=cfg.get("key") or None,
                       timeout=10, banner_timeout=15, auth_timeout=15,
                       allow_agent=not cfg.get('password') and not cfg.get('key'),
                       look_for_keys=not cfg.get("password") and not cfg.get("key"))
        transport = client.get_transport()
        transport.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        transport.set_keepalive(15)
        transport.default_window_size = 8 * 1024 * 1024
        size = os.path.getsize(cfg["source"])
        last_time, last_done = time.monotonic(), 0

        def progress(done, total):
            nonlocal last_time, last_done
            now = time.monotonic()
            elapsed = now - last_time
            if elapsed < .25 and done != total:
                return
            print(json.dumps({"done": done, "total": total,
                              "rate": (done - last_done) / max(elapsed, .001)}), flush=True)
            last_time, last_done = now, done

        with client.open_sftp() as sftp:
            sftp.get_channel().settimeout(60)
            sftp.put(cfg["source"], cfg["destination"], callback=progress)
        print(json.dumps({"ok": True, "done": size, "total": size}), flush=True)
        return 0
    except Exception as error:
        message = str(error)[:300] or error.__class__.__name__
        if cfg.get("password"):
            message = message.replace(cfg["password"], "***")
        print(json.dumps({"error": message}), flush=True)
        return 1
    finally:
        client.close()


if __name__ == "__main__":
    sys.exit(main())
