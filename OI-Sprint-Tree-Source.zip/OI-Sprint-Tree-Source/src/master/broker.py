"""A relay owns a private queue and schedules its own machines."""
import base64
import collections
import os
from pathlib import Path
import tarfile
import threading
import time
from types import SimpleNamespace

import judge as J
import assigned_data


class Broker(J.Judge):
    # Root owns the retry budget; do not turn five failures into 5 x 5 attempts.
    failure_limit=1
    def __init__(self,root,settings,emit):
        self.lock=threading.RLock();self.cv=threading.Condition(self.lock)
        self.app_dir=str(root);self.state_dir=str(root/'branch');os.makedirs(self.state_dir,exist_ok=True)
        self.payload=str(root/('payload_'+settings['version']))
        self.version=settings['version'];self.assigned_root=str(root/'assigned')
        self.contest={'id':settings['data_name'][5:],'scale':settings.get('scale',True)}
        self.emit=emit;self.jobs={};self.stopping=False;self.installed_packets={}
        self.no_capacity_since=time.monotonic()
        self.nodes={};self.node_seq=0;self.task_seq=0;self.rev=1;self.epoch=1
        self.cpu_limit=100;self.resetting=False;self.preparing=None
        self._reset([]);self.running=True
        self.store=SimpleNamespace(put=lambda *a:None,flush=lambda:None)
        self.deploy_slots=threading.BoundedSemaphore(4)
        self.empty_bundle=str(root/'empty-data.tar.gz')
        with tarfile.open(self.empty_bundle,'w:gz') as archive:
            entry=tarfile.TarInfo(settings['data_name']);entry.type=tarfile.DIRTYPE;archive.addfile(entry)
        threading.Thread(target=self.pulse,daemon=True).start()

    def payload_version(self):return self.version
    def data_bundle(self):return self.empty_bundle
    def save_nodes(self):pass

    def configure_workers(self,configs):
        wanted={c['id']:c for c in configs}
        with self.lock:
            for nid in list(self.nodes):
                if nid not in wanted:self.nodes.pop(nid).shutdown()
            for nid,cfg in wanted.items():
                existing=self.nodes.get(nid)
                cfg={**cfg,'local':bool(cfg.get('relay_local')),'relay':None,'managed':False}
                if existing:
                    existing.enabled=cfg.get('enabled',True)
                    existing.slots=cfg.get('slots') if cfg.get('slots') is not None else existing.slots
                    existing.cpu_limit_override=cfg.get('cpu_limit')
                    if not existing.enabled:existing.kill_all()
                    if existing.stage=='online':existing._send_config()
                    existing.wake.set()
                else:
                    node=self.nodes[nid]=J.Node(self,nid,cfg)
                    node.ensure_started()
            self.cv.notify_all()

    def install(self,archive):
        stamp=assigned_data.signature(archive)
        if self.installed_packets.get(str(archive))==stamp:return
        assigned_data.install_packet(archive,self.assigned_root,self.data_dirname())
        self.installed_packets[str(archive)]=stamp

    def submit(self,a):
        tid=int(a[1]);pid=a[2];tests=[int(t) for t in a[6].split(',')]
        with self.lock:
            if tid in self.jobs:raise ValueError('duplicate branch lease')
            count=max(tests)
            p=self.problem_by_id.get(pid)
            if p is None:
                p={'id':pid,'name':pid,'tl':int(a[3]),'ml':int(a[4]),'tests':count,'full':0,'points':[0]*count,'on':True}
                self.problem_by_id[pid]=p;self.problems.append(p);self.queues[pid]=[]
                self.sum_wall[pid]=self.count_wall[pid]=self.done_tests[pid]=self.total_tests[pid]=0
            elif count>p['tests']:
                p['tests']=count;p['points']=[0]*count
            p={**p,'tl':int(a[3]),'ml':int(a[4])}
            source=base64.b64decode(a[7]).decode('utf8') if a[7]!='-' else ''
            sub=J.Sub(str(tid),p,source,prepared=(a[7],int(a[5])))
            sub.allowed_tests=tests
            self.subs[(sub.sid,pid)]=sub
            self.jobs[tid]={'sub':sub,'sent':set(),'compiled':False,'yield':False}
            self.enqueue(sub)

    def enqueue(self,s,front=False):
        job=self.jobs.get(int(s.sid))
        if job and job['yield']:return
        super().enqueue(s,front)

    def on_compile(self,task,status,ms,log,node_name,cached=False):
        with self.lock:
            super().on_compile(task,status,ms,log,node_name,cached)
            job=self.jobs.get(int(task.sub.sid))
            if job and task.sub.compile and not job['compiled']:
                result=task.sub.compile
                self.emit(f'COMPILE {task.sub.sid} {result[0]} {result[1]} '+(base64.b64encode(result[2].encode()).decode() or '-'))
                job['compiled']=True

    def forward(self,sub,job):
        for test,result in sub.tests.items():
            if test in job['sent']:continue
            st,cpu,wall,mem,detail,node=result
            self.emit(f'TEST {sub.sid} {test} {st} {cpu} {wall} {mem} '+
                      (base64.b64encode(detail.encode()).decode() or '-')+' '+base64.b64encode(node.encode()).decode())
            job['sent'].add(test)

    def on_test(self,task,*args):
        with self.lock:
            accepted=super().on_test(task,*args)
            job=self.jobs.get(int(task.sub.sid))
            if accepted and job:self.forward(task.sub,job)
            return accepted

    def on_done(self,task,failed=False):
        with self.lock:
            super().on_done(task,failed)
            sub=task.sub;job=self.jobs.get(int(sub.sid))
            if not job:return
            self.forward(sub,job)
            if not sub.tasks and (not sub.remaining() or job['yield']):
                if job['yield']:self.emit('YIELDED '+sub.sid)
                self.emit('DONE '+sub.sid)
                if sub.queued:sub.queued=False;self.ready_count-=1
                self.jobs.pop(int(sub.sid),None);self.subs.pop((sub.sid,sub.prob),None)

    def control(self,line):
        a=line.split()
        if not a:return
        if a[0]=='TASK':self.submit(a)
        elif a[0]=='PING':self.emit('PONG')
        elif a[0]=='CONFIG':
            self.cpu_limit=int(a[2])
            for node in list(self.nodes.values()):
                if node.stage=='online':node._send_config()
            self.emit('CONFIG_OK '+a[2])
        elif a[0] in ('KILL','YIELD'):
            with self.lock:
                job=self.jobs.get(int(a[1]))
                if job:
                    sub=job['sub'];job['yield']=True
                    if sub.queued:sub.queued=False;self.ready_count-=1
                    for task in list(sub.tasks.values()):
                        if not task.sent:
                            task.cancelled=True;task.yielded=True
                            process=getattr(task.node.conn,'upload_proc',None)
                            if process and process.poll() is None:process.terminate()
                        elif a[0]=='KILL':task.node.kill(task.id)
                        else:task.yielded=True;task.node._send('YIELD '+str(task.id)+'\n')
                    if not sub.tasks:
                        self.emit('YIELDED '+sub.sid);self.emit('DONE '+sub.sid)
                        self.jobs.pop(int(sub.sid),None);self.subs.pop((sub.sid,sub.prob),None)

    def prepare_task(self,node,task):
        import relay
        conn=node.conn
        known=getattr(conn,'assigned_cases',set())
        missing=[test for test in task.tests if (task.sub.prob,test) not in known]
        if not missing:return
        archive=relay.data_package(self,task.sub.prob,missing)
        if node.local:
            assigned_data.install_packet(archive,conn.workdir,self.data_dirname())
        else:
            sftp=conn.client.open_sftp()
            try:conn._deploy(sftp,str(archive),assigned=True)
            finally:sftp.close()
        conn.assigned_cases=known|{(task.sub.prob,test) for test in missing}
        if node.conn is conn:node.set_stage('online')

    def pulse(self):
        while not self.stopping:
            try:
                with self.lock:
                    snapshots=[node.status() for node in self.nodes.values()]
                    capacity=sum(n['slots'] for n in snapshots if n['enabled'] and n['stage']=='online')
                    if capacity:self.no_capacity_since=time.monotonic()
                    elif time.monotonic()-self.no_capacity_since>10:
                        for tid in list(self.jobs):self.control('YIELD '+str(tid))
                self.emit('PONG')
                self.emit('CAPACITY '+str(min(1024,capacity*2)))
                import json
                self.emit('TREE '+base64.b64encode(json.dumps(snapshots).encode()).decode())
            except Exception:pass
            time.sleep(2)

    def close(self):
        self.stopping=True
        for node in list(self.nodes.values()):node.shutdown()
