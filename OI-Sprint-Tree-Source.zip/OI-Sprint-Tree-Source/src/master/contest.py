"""Finds problems in user-supplied data and answers folders and packs them for the nodes."""
import hashlib
import os
import re
import tarfile
import zipfile
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from functools import partial
from itertools import islice
from parallel_work import bounded_map, bounded_unordered

SOURCE_EXT = (".cpp", ".cc", ".cxx")
ANSWER_EXT = (".ans", ".out", ".a")
_VALID_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]*$")
_TRAILING_NUM = re.compile(r"^(.*?)[-_.]?(\d+)$")


def points_for(full, tests):
    """Full marks split evenly; any remainder goes to the last tests."""
    base, extra = divmod(int(full), tests)
    return [base + (1 if i >= tests - extra else 0) for i in range(tests)]


def _scan_student(candidate):
    sid, sdir = candidate.name, candidate.path
    if not candidate.is_dir(): return sid, None
    found = []
    with os.scandir(sdir) as entries:
        files = sorted(entries, key=lambda e: e.name)
    for item in files:
        entry, full = item.name, item.path
        path, prob = None, None
        if item.is_dir():
            prob = entry
            sources = [f for f in sorted(os.listdir(full)) if f.lower().endswith(SOURCE_EXT)]
            named = [f for f in sources if os.path.splitext(f)[0].lower() == entry.lower()]
            if named: path = os.path.join(full, named[0])
            elif len(sources) == 1: path = os.path.join(full, sources[0])
        elif entry.lower().endswith(SOURCE_EXT):
            prob, path = os.path.splitext(entry)[0], full
        if path and prob and _VALID_ID.match(prob): found.append((prob, path))
    return sid, found


def scan_answers(root, progress=None):
    """Accepts <root>/<student>/<problem>/<problem>.cpp and <root>/<student>/<problem>.cpp.
    Returns {problem: {student: path}} and the sorted student list."""
    found, students = {}, set()
    with os.scandir(root) as entries:
        candidates = sorted(entries, key=lambda e: e.name)
    for index, (sid, sources) in enumerate(bounded_map(_scan_student, candidates)):
        if progress:
            progress(index, len(candidates), sid)
        if sources is None: continue
        students.add(sid)
        for prob, path in sources: found.setdefault(prob, {})[sid] = path
    if progress:
        progress(len(candidates), len(candidates), "")
    return found, sorted(students)


def scan_data(root, known=()):
    """Accepts name1.in, name_01.in and name/1.in, with .ans, .out or .a answers.
    `known` problem ids are matched first so a problem called p1 keeps file p12.in together.
    Returns {problem: [(input path, answer path), ...]} in numeric test order."""
    known = sorted(known, key=len, reverse=True)
    groups = {}
    for dirpath, _, files in os.walk(root):
        rel = os.path.relpath(dirpath, root)
        top = None if rel == "." else rel.split(os.sep)[0]
        present = {f.lower(): f for f in files}
        for f in sorted(files):
            if not f.lower().endswith(".in"):
                continue
            stem = f[:-3]
            answer = next((present[stem.lower() + e] for e in ANSWER_EXT if stem.lower() + e in present), None)
            if not answer:
                continue
            prob, num = None, None
            # A named problem directory takes precedence over incidental numeric source names.
            if top in known and stem.isdigit():
                prob, num = top, int(stem)
            for k in known:
                if prob is not None:
                    break
                if stem.lower().startswith(k.lower()):
                    m = re.match(r"^[-_.]?(\d+)$", stem[len(k):])
                    if m:
                        prob, num = k, int(m.group(1))
                        break
            if prob is None:
                m = _TRAILING_NUM.match(stem)
                if not m:
                    continue
                if m.group(1):
                    prob, num = m.group(1), int(m.group(2))
                elif top:
                    prob, num = top, int(m.group(2))
                else:
                    continue
            if top and top in known and prob not in known:
                prob = top
            groups.setdefault(prob, []).append((num, stem, os.path.join(dirpath, f), os.path.join(dirpath, answer)))
    return {p: [(x[2], x[3]) for x in sorted(v, key=lambda x: (x[0], x[1]))] for p, v in groups.items()}


def scan(data_dir, answers_dir, progress=None):
    """Problems present in both folders, plus what could not be paired."""
    if not os.path.isdir(data_dir):
        raise ValueError("数据文件夹不存在")
    if not os.path.isdir(answers_dir):
        raise ValueError("答案文件夹不存在")
    answers, students = scan_answers(answers_dir, progress)
    data = scan_data(data_dir, answers.keys())
    ids = sorted(set(answers) & set(data))
    return {
        "problems": [{"id": p, "tests": len(data[p]), "subs": len(answers[p])} for p in ids],
        "students": len(students),
        "no_data": sorted(set(answers) - set(data)),
        "no_answers": sorted(set(data) - set(answers)),
    }, answers, data, students


def _file_stamp(path):
    st = os.stat(path)
    return f"{path}|{st.st_size}|{st.st_mtime_ns}\n".encode('utf8', 'replace')


def fingerprint(answers, data, progress=None):
    """Identifies a contest by its files, so reopening the same folders restores its results."""
    h = hashlib.sha256()
    entries = []
    for prob, subs in answers.items():
        if prob in data:
            entries += list(subs.values())
    for prob, files in data.items():
        if prob in answers:
            for a, b in files:
                entries += [a, b]
    entries.sort()
    for index, stamp in enumerate(bounded_map(_file_stamp, entries)):
        if progress:
            progress(index, len(entries), os.path.basename(entries[index]))
        h.update(stamp)
    if progress:
        progress(len(entries), len(entries), "")
    return h.hexdigest()[:16]


def pack_data(data, ids, dest, arc_root, progress=None):
    """Writes normalised names: <arc_root>/<problem><i>.in and .ans with i counted from 1."""
    pairs = []
    seen = set()
    for p in ids:
        for i, (inp, ans) in enumerate(data[p], 1):
            for source, extension in ((inp, ".in"), (ans, ".ans")):
                name = f"{arc_root}/{p}{i}{extension}"
                if name.casefold() in seen:
                    raise ValueError("题目测点文件名冲突，不能打包：" + name)
                seen.add(name.casefold())
                pairs.append((source, name))
    total = sum(os.path.getsize(a) for a, _ in pairs) or 1
    done = 0
    tmp = dest + ".tmp"
    with tarfile.open(tmp, "w:gz", compresslevel=1) as tf:
        for src, arc in pairs:
            tf.add(src, arcname=arc)
            done += os.path.getsize(src)
            if progress:
                progress(done * 100 // total)
    os.replace(tmp, dest)


def _source_batch(batch, from_files, analyzer):
    result = []
    for p, sid, source in batch:
        if from_files:
            try:
                with open(source, 'rb') as stream: raw = stream.read()
            except OSError as error: raise OSError(f'读取 {sid}/{p} 失败：{error}') from error
        else: raw = source
        result.append((p, sid, raw, analyzer(raw) if analyzer else None))
    return result


def source_pipeline(entries, total, analyzer=None, from_files=True):
    """I/O threads for small batches; CPU processes for substantial source analysis."""
    processes = analyzer is not None and total >= 2048 and (os.cpu_count() or 1) > 1
    workers = min(8, max(1, (os.cpu_count() or 2) - 1) if processes else 8, max(1, total))
    iterator = iter(entries)
    def batches():
        while batch := list(islice(iterator, 32 if processes else 1)): yield batch
    kind = ProcessPoolExecutor if processes else ThreadPoolExecutor
    with kind(max_workers=workers) as pool:
        function = partial(_source_batch, from_files=from_files, analyzer=analyzer)
        for batch in bounded_unordered(function, batches(), workers=workers, executor=pool):
            yield from batch


def pack_answers(answers, ids, dest, progress=None, analyzer=None, consume=None):
    tmp = dest + ".tmp"
    total = sum(len(answers[p]) for p in ids)
    done = 0
    entries = ((p, sid, path) for p in ids for sid, path in answers[p].items())
    try:
        # Source is persisted locally, not broadcast as a ZIP. Storing it avoids
        # per-file deflate work and lets a restart read the snapshot directly.
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as z:
            for p, sid, raw, analysis in source_pipeline(entries, total, analyzer):
                if progress:
                    progress(done, total)
                z.writestr(f"{sid}/{p}/{p}.cpp", raw)
                if consume: consume(p, sid, raw, analysis)
                done += 1
        if progress: progress(done, total)
        os.replace(tmp, dest)
    finally:
        if os.path.exists(tmp): os.remove(tmp)
