"""Pinned TLS transport for the persistent Linux execution service."""
import base64
import hashlib
import json
import os
from pathlib import Path
import queue
import socket
import ssl
import threading
import time
import uuid

from linux_agent import wire


class Connection:
    def __init__(self, node):
        self.node = node
        self.socket = None
        self.closed = False
        self.lines = queue.Queue()
        self.send_lock = threading.Lock()
        self.condition = threading.Condition()
        self.responses = {}
        self.installed = set()
        self.received_error = None
        self.timeout = 60

    def prepare(self):
        self.node.set_stage("checking")
        # Deployment writes the pinned identity only after the background service is ready.
        profile_path = Path(self.node.judge.state_dir) / "linux-connections" / f"{self.node.id}.json"
        if not profile_path.is_file():
            from linux_deploy import prepare
            profile = prepare(self.node)
        else:
            profile = json.loads(profile_path.read_text(encoding="utf8"))
        import judge
        secret = judge.unprotect(profile["token_sealed"])
        if secret is None:
            raise RuntimeError("Linux 节点接入凭据无法解密，请重新部署该节点")
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE  # The SSH-established certificate pin is verified below.
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        raw = socket.create_connection((profile["host"], profile["port"]), timeout=15)
        try:
            secure = context.wrap_socket(raw, server_hostname=profile["host"])
            self.socket = secure
            if hashlib.sha256(secure.getpeercert(binary_form=True)).hexdigest() != profile["fingerprint"]:
                raise ssl.SSLError("Linux 节点证书与部署时不一致，拒绝连接")
            self.send({"op": "authenticate", "token": secret})
            threading.Thread(target=self.read_loop, daemon=True, name=f"linux-rx-{self.node.id}").start()
        except BaseException:
            if self.socket:self.socket.close()
            raw.close()
            raise

    def read_loop(self):
        try:
            while not self.closed:
                header, payload = wire.receive(self.socket)
                if payload:
                    raise ValueError("节点不应向上级发送文件载荷")
                if header.get("op") == "event":
                    line = header["line"]
                    if not isinstance(line,str) or "\n" in line or "\r" in line:
                        raise ValueError("无效的节点事件")
                    self.lines.put((line+"\n").encode("ascii"))
                elif header.get("op") in ("offered", "committed", "reset_done"):
                    with self.condition:
                        self.responses[(header["request"], header["op"])] = header
                        self.condition.notify_all()
                else:
                    raise ValueError("未知节点消息")
        except Exception as error:
            self.received_error = error
        finally:
            self.lines.put(b"")
            with self.condition:self.condition.notify_all()

    def open(self):
        return self

    def readline(self):
        try:
            return self.lines.get(timeout=self.timeout)
        except queue.Empty:
            raise TimeoutError("Linux 节点长时间未回报") from None

    def send(self, message, payload=b""):
        if isinstance(message, bytes):
            for line in message.decode("ascii").splitlines():
                parts = line.split()
                if not parts:continue
                op = parts[0]
                if op == "PING":request={"op":"ping"}
                elif op == "CONFIG":request={"op":"configure","compile_limit":int(parts[1]),"cpu_limit":int(parts[2])}
                elif op in ("KILL","YIELD"):request={"op":op.lower(),"id":int(parts[1])}
                elif op == "TASK":
                    problem=self.node.judge.problem_by_id[parts[2]]
                    request={"op":"task","task":{"id":int(parts[1]),"problem":parts[2],"cpu_ms":int(parts[3]),
                             "memory_mb":int(parts[4]),"tests":list(map(int,parts[6].split(','))),
                             "source":parts[7] if parts[7]!='-' else '',
                             "data_version":self.node.judge.data_dirname(),"io":problem.get('io','file'),
                             "input_name":problem.get('input_name',parts[2]+'.in'),
                             "output_name":problem.get('output_name',parts[2]+'.out')}}
                else:raise ValueError("Linux 节点不支持该命令："+op)
                self.send(request)
            return
        with self.send_lock:
            if self.closed or self.socket is None:raise ConnectionError("Linux 连接已关闭")
            wire.send(self.socket, message, payload)

    def wait(self, rid, operation):
        deadline=time.monotonic()+60
        with self.condition:
            while (rid,operation) not in self.responses:
                if self.closed or self.received_error:
                    raise ConnectionError("Linux 数据传输中断")
                left=deadline-time.monotonic()
                if left<=0:raise TimeoutError("Linux 数据传输未确认")
                self.condition.wait(min(1,left))
            return self.responses.pop((rid,operation))

    def install_file(self, path, version):
        path=Path(path)
        info=path.stat()
        signature=(str(path),info.st_size,info.st_mtime_ns)
        judge=self.node.judge
        guard=getattr(judge,'linux_digest_lock',None)
        if guard is None:
            raise RuntimeError("Linux 主控尚未初始化数据版本管理")
        with guard:
            digest=judge.linux_digests.get(signature)
        if digest is None:
            h=hashlib.sha256()
            with path.open('rb') as source:
                while chunk:=source.read(1<<20):h.update(chunk)
            digest=h.hexdigest()
            with guard:judge.linux_digests[signature]=digest
        if (version,path.name,digest) in self.installed:return
        rid=uuid.uuid4().hex
        self.send({'op':'offer','request':rid,'version':version,'name':path.name,'size':info.st_size,'sha256':digest})
        if self.wait(rid,'offered')['needed']:
            started=time.monotonic();done=0
            with path.open('rb') as source:
                while chunk:=source.read(wire.CHUNK_LIMIT):
                    self.send({'op':'chunk','request':rid},chunk);done+=len(chunk)
                    self.node.transfer={'file':path.name,'done':done,'total':info.st_size,
                                        'rate':done/max(.001,time.monotonic()-started)}
            self.send({'op':'commit','request':rid})
            self.wait(rid,'committed')
        self.installed.add((version,path.name,digest))

    def set_timeout(self,seconds):
        self.timeout=seconds
        if self.socket:self.socket.settimeout(seconds)

    def reset_data(self):
        rid=uuid.uuid4().hex
        self.send({'op':'reset','request':rid})
        self.wait(rid,'reset_done')
        self.installed.clear()

    def close(self):
        self.closed=True
        if self.socket:
            try:self.socket.shutdown(socket.SHUT_RDWR)
            except OSError:pass
            self.socket.close()
        self.lines.put(b'')
        with self.condition:self.condition.notify_all()
