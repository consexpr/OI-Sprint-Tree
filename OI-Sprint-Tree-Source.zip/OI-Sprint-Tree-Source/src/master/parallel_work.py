"""Bounded parallel work: large inputs never enqueue one Future per file."""
from collections import deque
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED


def bounded_map(function, values, workers=8, executor=None):
    owned = executor is None
    pool = executor or ThreadPoolExecutor(max_workers=workers)
    pending = deque()
    iterator = iter(values)
    try:
        for _ in range(workers * 2):
            try: value = next(iterator)
            except StopIteration: break
            pending.append(pool.submit(function, value))
        while pending:
            result = pending.popleft().result()
            yield result
            try: value = next(iterator)
            except StopIteration: continue
            pending.append(pool.submit(function, value))
    finally:
        for future in pending: future.cancel()
        if owned: pool.shutdown(wait=True, cancel_futures=True)


def bounded_unordered(function, values, workers, executor):
    """Consume completed independent jobs without waiting for an earlier slow job."""
    iterator = iter(values)
    pending = set()
    try:
        for _ in range(workers * 2):
            try: value = next(iterator)
            except StopIteration: break
            pending.add(executor.submit(function, value))
        while pending:
            complete, _ = wait(pending, return_when=FIRST_COMPLETED)
            for future in complete:
                pending.remove(future)
                yield future.result()
                try: value = next(iterator)
                except StopIteration: continue
                pending.add(executor.submit(function, value))
    finally:
        for future in pending: future.cancel()
