"""Automatic placement for the current root / relay / worker transport.

Topology changes drain leases before changing their owner. Normal scheduling
continues on every other branch while the affected session drains.
"""
import math
import threading
import time


class Controller:
    MIN_RELAY_MACHINES = 8
    def __init__(self, judge):
        self.judge = judge
        self.pending = {}
        self.good_since = {}
        self.bad_since = {}
        self.changed = {}
        self.message = '电脑连接后自动组网；副控同时参与评测'
        self.error = ''

    def start(self):
        threading.Thread(target=self.run, daemon=True, name='auto-topology').start()

    def status(self):
        return {'automatic': True, 'message': self.message, 'error': self.error,
                'pending': len(self.pending)}

    def run(self):
        while True:
            try:
                self.tick()
                self.error = ''
            except Exception as error:
                # Surface failures in the console instead of silently disabling
                # automatic placement or abandoning the maintenance thread.
                self.error = '自动组网暂未完成：' + type(error).__name__
            time.sleep(2)

    @staticmethod
    def capacity(node):
        info = node.info
        cores = max(1, info.get('logical', 1))
        memory = max(1, info.get('mem', 4096) / 4096)
        return max(1, min(16, cores, memory))

    @staticmethod
    def subnet(host):
        return host.rsplit('.', 1)[0] if host.count('.') == 3 else host

    def gateway(self, rid):
        return next((n for n in self.judge.nodes.values() if n.gateway and n.relay_id == rid), None)

    def drain(self, node):
        if not node: return
        node.routing_draining = True
        for task in list(node.inflight.values()):
            if task.cancelled or task.yielded: continue
            task.yielded = True
            # YIELD completes the point already running, then returns the rest
            # of the lease. It never terminates the running submission process.
            if task.sent: node._send(f'YIELD {task.id}\n')

    def relay_capacity(self, rid, gateway):
        local = next((n for n in self.judge.nodes.values() if n.relay_id == rid and n.relay_local), None)
        return self.capacity(local or gateway)

    def initial_parent(self, host):
        """Place a new machine before it starts uploading anything directly."""
        now = time.monotonic()
        choices = [n for n in self.judge.nodes.values() if n.gateway and n.enabled and n.stage == 'online'
                   and now - self.good_since.get(n.id, now) >= 10 and not n.routing_draining and not self.judge.is_master_host(n.host)]
        return min(choices, key=lambda g: (
            sum(n.relay_id == g.relay_id and not n.gateway and not n.relay_local for n in self.judge.nodes.values())
            / self.relay_capacity(g.relay_id, g) + (0 if self.subnet(host) == self.subnet(g.host) else .15),
            g.id)).relay_id if choices else None

    def tick(self, now=None):
        now = time.monotonic() if now is None else now
        j = self.judge
        with j.lock:
            if j.resetting:
                self.pending.clear()
                return
            for n in list(j.nodes.values()):
                if (not n.local and not n.gateway and not n.relay_local and
                        not n.connected_once and n.stage == 'error' and not n.inflight):
                    self.pending.pop(n.id, None)
                    self.good_since.pop(n.id, None)
                    self.bad_since.pop(n.id, None)
                    j.remove_node(n.id)
            nodes = [n for n in j.nodes.values() if not n.local and not n.gateway and n.enabled and not j.is_master_host(n.host)]
            gateways = {n.relay_id: n for n in j.nodes.values() if n.gateway and not j.is_master_host(n.host)}
            for n in nodes + list(gateways.values()):
                if n.stage == 'online':
                    self.good_since.setdefault(n.id, now)
                    self.bad_since.pop(n.id, None)
                else:
                    self.good_since.pop(n.id, None)
                    self.bad_since.setdefault(n.id, now)

            # Use only relays that have recovered stably; do not bounce a branch
            # back onto a flapping SSH session as soon as it answers once.
            healthy = {rid: g for rid, g in gateways.items() if g.enabled and g.stage == 'online'
                       and now - self.good_since.get(g.id, now) >= 10}

            for nid, action in list(self.pending.items()):
                n = j.nodes.get(nid)
                if not n or not n.enabled or n.local or j.is_master_host(n.host):
                    self.pending.pop(nid, None)
                    if n: n.routing_draining = False
                    continue
                kind, destination = action
                source = gateways.get(n.relay_id) if n.managed else n
                # Waiting for the gateway drains all leases owned by that broker.
                # This also fences its queued data preparations, not just the
                # leaf's last reported inflight count.
                failed = source and source.stage in ('error', 'offline') and now - self.bad_since.get(source.id, now) >= 20
                if source and source.inflight:
                    continue
                if n.managed and source and source.stage != 'online' and not failed:
                    continue
                if kind == 'promote':
                    if n.managed:
                        # A growing fleet may already have all its machines
                        # under the first vice. Bring the candidate back first;
                        # never run two owners for the same leaf concurrently.
                        n.move_to(None)
                        self.drain(n)
                        continue
                    if n.stage != 'online':
                        if n.stage == 'error' and now - self.bad_since.get(n.id, now) > 30:
                            n.routing_draining = False
                            self.pending.pop(nid, None)
                        continue
                    cfg = dict(host=n.host, user=n.user, port=n.port, password=n.password,
                               key=n.key, dir=n.dir, slots=n.slots, cpu_limit=n.cpu_limit_override,
                               automatic=True, auto_route=True)
                    j.relays.add_config(cfg, existing_node=n)
                    self.message = '已自动选择副控 ' + n.host + '，同时参与评测'
                else:
                    if destination and destination not in healthy:
                        self.pending.pop(nid, None)
                        n.routing_draining = False
                        continue
                    n.move_to(destination)
                    self.message = '已自动调整 ' + n.host + ' 的连接'
                self.changed[nid] = now
                self.pending.pop(nid, None)
                n.routing_draining = False

            # Promotion adds a gateway during this pass. Count it immediately
            # so the same pass cannot accidentally elect a second vice.
            gateways = {n.relay_id: n for n in j.nodes.values() if n.gateway and not j.is_master_host(n.host)}
            # Release a drained branch only when no outstanding move still
            # depends on it. Waiting never cancels a healthy running test.
            blocked = {j.nodes[nid].relay_id for nid in self.pending if nid in j.nodes and j.nodes[nid].managed}
            for rid, g in gateways.items():
                g.routing_draining = rid in blocked

            eligible = [n for n in nodes if n.auto_route and not n.relay_local]
            # Up to sixteen children per relay; avoid adding a relay hop to a
            # handful of machines. Candidates must first finish their benchmark.
            desired = math.ceil(len(nodes) / 16) if len(nodes) >= self.MIN_RELAY_MACHINES else 0
            starting = sum(rid not in healthy and (g.stage not in ('error', 'offline') or
                           now - self.bad_since.get(g.id, now) < 20) for rid, g in gateways.items())
            promoting = any(action[0] == 'promote' for action in self.pending.values())
            if len(healthy) + starting < desired and not promoting:
                candidates = [n for n in eligible if n.stage == 'online'
                              and n.id not in self.pending and now - self.good_since.get(n.id, now) >= 10]
                if candidates:
                    used = {self.subnet(g.host) for g in healthy.values()}
                    n = max(candidates, key=lambda n: (self.subnet(n.host) not in used,
                            self.capacity(n), n.info.get('perf', 0), -n.id))
                    self.drain(gateways.get(n.relay_id) if n.managed else n)
                    self.pending[n.id] = ('promote', None)

            loads = {rid: sum(n.relay_id == rid and not n.relay_local for n in nodes) for rid in healthy}
            # Reserve planned destinations so a whole batch does not all pick
            # the same idle relay before its first status update arrives.
            for nid, (kind, target) in self.pending.items():
                if kind == 'move' and target in loads: loads[target] += 1
            for n in eligible:
                if n.id in self.pending: continue
                failed_parent = n.relay_id and n.relay_id not in healthy
                old = gateways.get(n.relay_id)
                failed_parent = failed_parent and (old is None or
                    old.stage in ('error', 'offline') and now - self.bad_since.get(old.id, now) >= 20)
                failed_path = n.managed and n.stage == 'error' and now - self.bad_since.get(n.id, now) >= 20
                if not failed_parent and now - self.changed.get(n.id, -1e9) < 120: continue
                choices = [rid for rid in healthy if not failed_path or rid != n.relay_id]
                target = min(choices, key=lambda rid: (
                    loads[rid] / self.relay_capacity(rid, healthy[rid]) +
                    (0 if self.subnet(n.host) == self.subnet(healthy[rid].host) else .15), rid), default=None)
                if target == n.relay_id: continue
                if not target and not failed_parent and not failed_path: continue
                if n.relay_id in healthy and target and not failed_path:
                    src = n.relay_id
                    # Hysteresis keeps caches hot; minor differences do not
                    # trigger an expensive redeploy or whole-branch drain.
                    if loads[src] < loads[target] + 3: continue
                    loads[src] -= 1
                if target: loads[target] += 1
                self.pending[n.id] = ('move', target)
                self.drain(old or n)
                if len(self.pending) >= 4: break
            if self.pending:
                self.message = '正在自动组网：等待当前任务结束后调整 ' + str(len(self.pending)) + ' 台电脑'
            elif healthy:
                self.message = f'自动组网：{len(healthy)} 台副控，{len(nodes)} 台电脑；副控同时参与评测'
            elif not nodes:
                self.message = '电脑连接后自动组网；副控同时参与评测'
            j.cv.notify_all()
