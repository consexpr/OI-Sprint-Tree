"""SSH bootstraps a windowless supervisor; runtime traffic uses pinned TLS."""
import json
import os
from pathlib import Path
import subprocess
import time
import uuid


def prepare(node):
    import judge as J
    payload=Path(node.judge.payload)
    required=('oi-sprint-linux-host.exe','linux-agent.tar.gz','linux-image.json','linux-rootfs.tar.gz')
    missing=[name for name in required if not (payload/name).is_file()]
    if missing:
        raise RuntimeError('Linux 部署载荷尚未完整构建：'+', '.join(missing))
    if node.gateway or node.managed:
        raise RuntimeError('Linux 多层副控接入尚未完成，当前不能将 Windows 副控程序用于 Linux 节点')
    image=json.loads((payload/'linux-image.json').read_text(encoding='utf8'))
    runtime_version=node.judge.payload_version()
    request={'image_version':image['version'],'runtime_version':runtime_version}
    token=uuid.uuid4().hex
    profile_folder=Path(node.judge.state_dir)/'linux-connections';profile_folder.mkdir(parents=True,exist_ok=True)
    if node.local:
        folder=Path(node.judge.state_dir)/'linux-host';folder.mkdir(parents=True,exist_ok=True)
        import shutil
        for name in required:
            source=payload/name;target=folder/name
            if not target.is_file() or target.stat().st_size!=source.stat().st_size:shutil.copyfile(source,target)
        request_path=folder/(token+'.request.json');result_path=folder/(token+'.result.json')
        request_path.write_text(json.dumps(request),encoding='utf8')
        node.set_stage('starting')
        process=subprocess.Popen([str(folder/'oi-sprint-linux-host.exe'),'--prepare','--folder',str(folder),
                                  '--request',str(request_path),'--result',str(result_path)],
                                  stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                                  creationflags=0x08000000)
        while process.poll() is None:
            if not node.alive:process.terminate();raise RuntimeError('本机 Linux 部署已取消')
            time.sleep(.5)
        result=json.loads(result_path.read_text(encoding='utf8'))
        result_path.unlink();request_path.unlink()
    else:
        conn=J.SSHConn(node,{'host':node.host,'user':node.user,'port':node.port,
                            'password':node.password,'key':node.key,'dir':node.dir})
        try:
            sftp=conn._connect()
            base=conn.sftp_dir.rsplit('/',1)[0]+'/.oi_sprint_linux'
            conn.sftp_dir=base;conn.win_dir=base.lstrip('/').replace('/','\\')
            if any(c in conn.win_dir for c in '"\r\n'):
                raise ValueError('Linux 部署目录包含无效字符')
            conn._mkdirs(sftp,base)
            for name in required:
                source=payload/name;remote=base+'/'+name
                try:
                    valid=sftp.stat(remote).st_size==source.stat().st_size
                    expected=image['version'] if name=='linux-rootfs.tar.gz' else runtime_version
                    with sftp.open(remote+'.version') as marker:valid &= marker.read().decode()==expected
                except OSError:valid=False
                if valid:continue
                node.set_stage('uploading')
                started=time.monotonic()
                def progress(done,total,rate=None):
                    node.pct=done*100//max(1,total)
                    node.transfer={'file':name,'done':done,'total':total,'rate':rate or done/max(.001,time.monotonic()-started)}
                conn._upload_bundle(str(source),remote+'.tmp',progress)
                try:sftp.posix_rename(remote+'.tmp',remote)
                except OSError:
                    try:sftp.remove(remote)
                    except OSError:pass
                    sftp.rename(remote+'.tmp',remote)
                with sftp.open(remote+'.version','w') as marker:marker.write(image['version'] if name=='linux-rootfs.tar.gz' else runtime_version)
            request_name=token+'.request.json';result_name=token+'.result.json'
            with sftp.open(base+'/'+request_name,'w') as output:output.write(json.dumps(request))
            node.set_stage('starting')
            command=subprocess.list2cmdline([conn.win_dir+'\\oi-sprint-linux-host.exe','--prepare','--folder',conn.win_dir,
                                             '--request',conn.win_dir+'\\'+request_name,'--result',conn.win_dir+'\\'+result_name])
            code,_,_=conn._exec(command,timeout=2100)
            with sftp.open(base+'/'+result_name) as result_file:result=json.loads(result_file.read())
            sftp.remove(base+'/'+request_name);sftp.remove(base+'/'+result_name)
        finally:conn.close()
    if not result.get('ok'):raise RuntimeError(result.get('error','Linux 节点部署失败'))
    profile={'host':'127.0.0.1' if node.local else node.host,'port':result['port'],
             'fingerprint':result['fingerprint'],'token_sealed':J.protect(result['token']),
             'image_version':result['image_version']}
    path=profile_folder/f'{node.id}.json';temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(profile),encoding='utf8');os.replace(temporary,path)
    return profile
