"""Entry point: loads the judge and serves the local web console."""
import ctypes
import ctypes.wintypes
import json
import os
import sys
import threading
import time
import traceback
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import discover
import judge as J
import provisioning
APP_TITLE="OI-Sprint Classic"


def app_dir():
    if "--app-dir" in sys.argv:
        return os.path.abspath(sys.argv[sys.argv.index("--app-dir") + 1])
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def web_file():
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, "web", "index.html")


def payload_version(self):
    if not hasattr(self, "_payload_version"):
        path = os.path.join(self.payload, "version.txt")
        self._payload_version = open(path).read().strip() if os.path.exists(path) else "dev"
    return self._payload_version


J.Judge.payload_version = payload_version
J.Judge.deploy_slots = threading.BoundedSemaphore(4)


def pick_folder(title):
    """Native folder dialog, on the machine this console runs on."""
    class BrowseInfo(ctypes.Structure):
        _fields_ = [("hwndOwner", ctypes.wintypes.HWND), ("pidlRoot", ctypes.c_void_p),
                    ("pszDisplayName", ctypes.c_wchar_p), ("lpszTitle", ctypes.c_wchar_p),
                    ("ulFlags", ctypes.c_uint), ("lpfn", ctypes.c_void_p), ("lParam", ctypes.c_ssize_t),
                    ("iImage", ctypes.c_int)]

    shell = ctypes.windll.shell32
    ctypes.windll.ole32.CoInitialize(None)
    shell.SHBrowseForFolderW.restype = ctypes.c_void_p
    shell.SHBrowseForFolderW.argtypes = [ctypes.POINTER(BrowseInfo)]
    shell.SHGetPathFromIDListW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
    display = ctypes.create_unicode_buffer(260)
    info = BrowseInfo(ctypes.windll.user32.GetForegroundWindow(), None, ctypes.cast(display, ctypes.c_wchar_p), title,
                      0x0041, None, 0, 0)  # BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE
    pidl = shell.SHBrowseForFolderW(ctypes.byref(info))
    if not pidl:
        return ""
    out = ctypes.create_unicode_buffer(1024)
    shell.SHGetPathFromIDListW(pidl, out)
    ctypes.windll.ole32.CoTaskMemFree(ctypes.c_void_p(pidl))
    return out.value


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    judge = None
    allowed_hosts = set()
    index_html = None

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8", headers=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf8")
        elif isinstance(body, str):
            body = body.encode("utf8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _host_ok(self):
        return self.headers.get("Host", "") in self.allowed_hosts

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, {"error": "forbidden"})
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        try:
            if u.path == "/":
                return self._send(200, self.index_html, "text/html; charset=utf-8")
            if u.path == "/api/contests":
                return self._send(200, {"contests": self.judge.list_contests()})
            if u.path == "/api/ranges":
                return self._send(200, {"ranges": discover.local_ranges()})
            if u.path == "/api/state":
                return self._send(200, self.judge.state_json(int(q.get("since", ["0"])[0])))
            if u.path == "/api/preparation":
                # Independent of the master lock, including while the new queue is committed.
                return self._send(200, {"preparing": self.judge.preparing})
            if u.path == "/api/sub":
                data = self.judge.sub_json(q["sid"][0], q["prob"][0])
                return self._send(200 if data else 404, data or {"error": "not found"})
            if u.path == "/api/export":
                path, name = self.judge.export_html(self.index_html)
                with open(path, "rb") as f:
                    body = f.read()
                encoded = urllib.parse.quote(name)
                return self._send(200, body, "text/html; charset=utf-8",
                                  {"Content-Disposition": f"attachment; filename*=UTF-8''{encoded}"})
        except Exception:
            traceback.print_exc()
            return self._send(500, {"error": "server error"})
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        # The custom header forces a CORS preflight, so other sites cannot drive this console.
        if not self._host_ok() or self.headers.get("X-Judge") != "1":
            return self._send(403, {"error": "forbidden"})
        try:
            n = int(self.headers.get("Content-Length", 0))
            if not 0 <= n <= 2 * 1024 * 1024:
                self.close_connection = True
                raise ValueError("请求内容过大或长度无效")
            data = json.loads(self.rfile.read(n) or b"{}")
            path = urllib.parse.urlparse(self.path).path
            j = self.judge
            if j.resetting:
                return self._send(409, {"error": "正在恢复出厂设置，请稍后操作"})
            if path == "/api/factory-reset":
                if data.get("confirm") is not True:
                    raise ValueError("请确认恢复出厂设置")
                return self._send(200, j.factory_reset())
            if path == "/api/control":
                {"start": j.start, "pause": j.pause, "stop": j.stop_now}[data["op"]]()
                return self._send(200, {"ok": True})
            if path == "/api/settings":
                return self._send(200, j.set_cpu_limit(data["cpu_limit"]))
            if path == "/api/problem":
                j.set_problem(data["id"], data["on"])
                return self._send(200, {"ok": True})
            if path == "/api/problems/reorder":
                return self._send(200, j.reorder_problems(data["order"]))
            if path == "/api/act":
                n = j.act(data["op"], data.get("problems"), data.get("students"), data.get("statuses"))
                return self._send(200, {"ok": True, "affected": n})
            if path == "/api/contest/scan":
                return self._send(200, j.scan_folders(data["data"].strip(), data["answers"].strip()))
            if path == "/api/contest/open":
                return self._send(200, j.open_contest(str(data["id"])))
            if path == "/api/contest/apply":
                return self._send(200, j.configure(data))
            if path == "/api/pick":
                return self._send(200, {"path": pick_folder(data.get("title", ""))})
            if path == "/api/nodes/discover":
                port = int(data.get("port") or 22)
                result = discover.scan(data.get("range", ""), port)
                known = {(n.host, n.port) for n in j.nodes.values()}
                for r in result["found"]:
                    r["added"] = (r["host"], r["port"]) in known
                return self._send(200, result)
            if path == "/api/nodes/preview":
                return self._send(200, provisioning.preview(data,j))
            if path == "/api/nodes/batch":
                return self._send(200, provisioning.add(data,j))
            if path == "/api/nodes/reconnect":
                node=j.nodes.get(int(data['id']))
                if not node:return self._send(404,{'error':'节点不存在'})
                node.restart()
                return self._send(200,{'ok':True})
            if path == "/api/nodes/add":
                items, errors = J.parse_nodes(data.get("text", ""), data.get("slots"))
                for it in data.get("items", []):
                    items.append({"user": it["user"].strip(), "host": it["host"], "port": int(it.get("port") or 22),
                                  "password": it.get("password", ""), "slots": data.get("slots"), "dir": "",
                                  "key": "", "enabled": True})
                for it in items:
                    it["relay"] = data.get("relay") or None
                    it["auto_route"] = bool(getattr(j, 'topology', None)) and "relay" not in data
                    j.add_node(it)
                return self._send(200, {"ok": not errors, "added": len(items), "errors": errors})
            if path == "/api/nodes/update":
                node = j.nodes.get(int(data["id"]))
                if not node:
                    return self._send(404, {"error": "not found"})
                if "relay" in data:
                    node.move_to(data["relay"])
                if "slots" in data:
                    node.set_slots(data["slots"])
                if "cpu_limit" in data:
                    node.set_cpu_limit(data["cpu_limit"])
                if "enabled" in data:
                    node.set_enabled(data["enabled"])
                return self._send(200, {"ok": True})
            if path == "/api/nodes/remove":
                j.remove_node(int(data["id"]))
                return self._send(200, {"ok": True})
            if path == "/api/relays/add":
                rid = j.relays.add(data["text"], data.get("name", ""))
                return self._send(200, {"ok":True, "id":rid})
            if path == "/api/relays/reconnect":
                j.relays.reconnect(data["id"])
                return self._send(200, {"ok":True})
        except ValueError as e:  # bad input: the message is for the form
            return self._send(400, {"error": str(e)[:200]})
        except Exception as e:
            traceback.print_exc()
            return self._send(500, {"error": str(e)[:200]})
        return self._send(404, {"error": "not found"})


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 64


def main():
    if "--upload-worker" in sys.argv:
        import transfer_worker
        return transfer_worker.main()
    port = 8987
    args = sys.argv[1:]
    no_browser = "--no-browser" in args
    if "--port" in args:
        port = int(args[args.index("--port") + 1])
    base = app_dir()
    print(APP_TITLE+" 加载中…")
    judge = J.Judge(base)
    if getattr(sys, 'frozen', False):
        for bundled_payload in (os.path.join(getattr(sys, '_MEIPASS', ''), 'payload'),
                                os.path.join(os.path.dirname(sys.executable), 'payload')):
            if os.path.isfile(os.path.join(bundled_payload, 'version.txt')):
                judge.payload = bundled_payload
                break
    Handler.judge = judge
    with open(web_file(), encoding="utf8") as f:
        Handler.index_html = f.read().replace("OI-Sprint Classic",APP_TITLE)
        if J.LINUX_MODE:
            Handler.index_html=Handler.index_html.replace('id="c-scale" checked','id="c-scale"')
    for attempt in range(20):
        try:
            server = Server(("127.0.0.1", port + attempt), Handler)
            port += attempt
            break
        except OSError:
            continue
    else:
        print("没有可用端口")
        return 1
    Handler.allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
    judge.load_nodes()
    url = f"http://127.0.0.1:{port}/"
    print(f"{APP_TITLE} 已启动: {url}")
    print("关闭此窗口即停止评测，进度已保存。")
    if not no_browser:
        def open_browser():
            try:
                if not webbrowser.open(url):print('浏览器未打开，请打开上面的地址。')
            except Exception as error:
                print('浏览器打开失败：'+str(error)+'\n请打开上面的地址。')
        threading.Timer(0.5, open_browser).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    if judge.store:
        judge.store.flush()
    return 0


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    sys.exit(main())
