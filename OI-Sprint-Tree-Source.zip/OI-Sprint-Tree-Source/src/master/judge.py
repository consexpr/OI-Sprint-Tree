"""Scheduling, persistence, node management and result aggregation."""
import base64
import collections
import heapq
import math
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import partial
import ctypes
import ctypes.wintypes
import json
import os
import queue
import re
import shutil
import socket
import sqlite3
import subprocess
import sys
import tarfile
import threading
import time
import zipfile

import paramiko

import contest as C
import scan
import discover

# Time limits are stated for the reference machine (i9-13900KF, one program running alone).
# Every node's real limit is scaled by its measured speed relative to this figure, which comes from
# the agent's bench at concurrency 1 on that machine.
REFERENCE_SPEED = 925919.0
STATUS_CHAR = {"AC": "A", "WA": "W", "TLE": "T", "MLE": "M", "RE": "R", "NOF": "N", "OLE": "O", "SE": "S"}
AGENT_NAME = "oi-sprint-classic-agent.exe"
PROTOCOL = "OI-SPRINT-CLASSIC/1"
LINUX_MODE = False
REMOTE_SUBDIR = ".oi_sprint_classic"
RELAY_SUBDIR = ".oi_sprint_relay"
LOCAL_SUBDIR = "worker-classic"


def remove_managed_tree(base, target):
    """Only delete descendants of a known managed root; never follow directory links."""
    base = os.path.normcase(os.path.realpath(base))
    target = os.path.abspath(target)
    resolved = os.path.normcase(os.path.realpath(target))
    if resolved == base or os.path.commonpath([base, resolved]) != base:
        raise ValueError("拒绝清理评测器目录以外的路径")
    if not os.path.exists(target):
        return
    for root, dirs, _ in os.walk(target, followlinks=False):
        for path in [root] + [os.path.join(root, d) for d in dirs]:
            if os.path.islink(path) or os.path.isjunction(path):
                raise ValueError("清理目录含链接，请先移除链接后重试")
    shutil.rmtree(target)


# ------------------------------------------------------------------ credentials
class _Blob(ctypes.Structure):
    _fields_ = [("cbData", ctypes.wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _dpapi(data, encrypt):
    crypt = ctypes.windll.crypt32
    src = _Blob(len(data), ctypes.cast(ctypes.create_string_buffer(data, len(data)), ctypes.POINTER(ctypes.c_char)))
    dst = _Blob()
    fn = crypt.CryptProtectData if encrypt else crypt.CryptUnprotectData
    if not fn(ctypes.byref(src), None, None, None, None, 0, ctypes.byref(dst)):
        raise OSError("dpapi failed")
    out = ctypes.string_at(dst.pbData, dst.cbData)
    ctypes.windll.kernel32.LocalFree(dst.pbData)
    return out


def protect(text):
    return base64.b64encode(_dpapi(text.encode("utf8"), True)).decode() if text else ""


def unprotect(blob):
    if not blob:
        return ""
    try:
        return _dpapi(base64.b64decode(blob), False).decode("utf8")
    except OSError:
        return None  # sealed on another machine or by another user


# ------------------------------------------------------------------ submissions
class Sub:
    __slots__ = ("sid", "prob", "problem", "code", "tests", "compile", "state", "gen", "tasks", "reasons", "flags",
                 "wire", "rewritten", "attempts", "skipped", "queue_version", "prioritized", "queued", "allowed_tests")

    def __init__(self, sid, problem, code, raw_source=None, prepared=None, source_analysis=None):
        self.sid = sid
        self.prob = problem["id"]
        self.problem = problem
        self.code = code
        self.tests = {}  # test -> (status, cpu, wall, mem, detail, node)
        self.compile = None  # (status, ms, log)
        self.state = "queued"  # queued | running | done | held | skipped
        self.gen = 0
        self.tasks = {}
        if prepared is not None:
            # A branch receives source already checked/rewritten by its authenticated parent.
            self.wire,self.flags=prepared
            self.reasons=[];self.rewritten=bool(self.flags & 2)
        else:
            analysis = source_analysis if source_analysis is not None else scan.analyze_source(code, raw_source, LINUX_MODE)
            if analysis[0] != code: raise ValueError('源码检查结果与原文不一致')
            self.reasons = list(analysis[1])
            self.rewritten, self.flags, self.wire = analysis[2:]
        self.attempts = {}
        self.skipped = False
        self.queue_version = 0
        self.prioritized = False
        self.queued = False
        self.allowed_tests = None

    def remaining(self):
        if self.compile and self.compile[0] == "CE":
            return []
        return [t for t in (self.allowed_tests if self.allowed_tests is not None else range(1,self.problem["tests"]+1)) if t not in self.tests]

    def available(self):
        assigned = {test for task in self.tasks.values() if not task.cancelled for test in task.tests}
        return [test for test in self.remaining() if test not in assigned]

    def score(self):
        if self.compile and self.compile[0] == "CE":
            return 0
        pts = self.problem["points"]
        return sum(pts[t - 1] for t, r in self.tests.items() if r[0] == "AC")

    def strip(self):
        n = self.problem["tests"]
        if self.state == "held" and not self.tests:
            return "H" * n
        if self.compile and self.compile[0] == "CE":
            return "C" * n
        fill = "K" if self.state == "skipped" else "."
        return "".join(STATUS_CHAR[self.tests[t][0]] if t in self.tests else fill for t in range(1, n + 1))


class Store:
    """Single writer thread; results survive a master crash at the cost of about a second of work."""

    def __init__(self, path):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.executescript(
            """
            PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;
            CREATE TABLE IF NOT EXISTS tests(sid TEXT, prob TEXT, test INT, status TEXT, cpu INT, wall INT, mem INT,
                detail TEXT, node TEXT, PRIMARY KEY(sid, prob, test));
            CREATE TABLE IF NOT EXISTS compiles(sid TEXT, prob TEXT, status TEXT, ms INT, log TEXT,
                PRIMARY KEY(sid, prob));
            CREATE TABLE IF NOT EXISTS flags(sid TEXT, prob TEXT, kind TEXT, PRIMARY KEY(sid, prob, kind));
            CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT);
            """
        )
        self.q = queue.Queue()
        self.error = None
        self.closing = False
        self.thread = threading.Thread(target=self._loop, daemon=True, name="store")
        self.thread.start()

    def put(self, sql, args=()):
        if self.error or self.closing:
            raise RuntimeError("成绩保存不可用：" + str(self.error or "数据库正在关闭"))
        self.q.put((sql, args))

    def _loop(self):
        try:
            self._write_loop()
        except Exception as error:
            self.error = error
            try:
                self.db.close()
            except Exception:
                pass

    def _write_loop(self):
        while True:
            items = [self.q.get()]
            if items[0] is None:
                self.db.close()
                return
            time.sleep(0.5)
            try:
                while True:
                    items.append(self.q.get_nowait())
            except queue.Empty:
                pass
            flush, stop = [], False
            with self.db:
                for it in items:
                    if it is None:
                        stop = True
                    elif isinstance(it, threading.Event):
                        flush.append(it)
                    else:
                        self.db.execute(*it)
            for e in flush:
                e.set()
            if stop:
                self.db.close()
                return

    def flush(self):
        if self.error:
            raise RuntimeError("成绩保存失败：" + str(self.error))
        e = threading.Event()
        self.q.put(e)
        deadline = time.monotonic() + 10
        while not e.wait(.1):
            if self.error:
                raise RuntimeError("成绩保存失败：" + str(self.error))
            if time.monotonic() >= deadline:
                raise RuntimeError("成绩保存超时，不能确认已写入数据库")

    def close(self):
        self.closing = True
        self.q.put(None)
        self.thread.join(10)
        if self.thread.is_alive():
            raise RuntimeError("成绩保存线程尚未停止，请稍后重试")
        if self.error:
            raise RuntimeError("成绩保存失败：" + str(self.error))


class Task:
    __slots__ = ("id", "sub", "gen", "node", "tests", "factor", "epoch", "error", "cancelled", "yielded", "sent")

    def __init__(self, tid, sub, gen, node, tests):
        self.id = tid
        self.sub = sub
        self.gen = gen
        self.node = node
        self.tests = tests
        self.factor = node.factor()
        self.epoch = node.judge.epoch
        self.error = ""
        self.cancelled = False
        self.yielded = False
        self.sent = False


class Judge:
    failure_limit=5
    def __init__(self, app_dir):
        self.app_dir = app_dir
        self.runtime = "linux" if LINUX_MODE else "windows"
        self.payload = os.path.join(app_dir, "payload")
        self.state_dir = os.path.join(app_dir, "state")
        self.export_dir = os.path.join(app_dir, "exports")
        self.contests_dir = os.path.join(self.state_dir, "contests")
        os.makedirs(self.contests_dir, exist_ok=True)
        self.cpu_limit = 100
        try:
            with open(os.path.join(self.state_dir, "settings.json"), encoding="utf8") as f:
                value = json.load(f).get("cpu_limit", 100)
            if type(value) is int and 1 <= value <= 100:
                self.cpu_limit = value
        except (OSError, ValueError, AttributeError):
            pass
        self.lock = threading.RLock()
        self.cv = threading.Condition(self.lock)
        self.nodes = {}
        import relay
        self.relays = relay.Manager(self)
        self.topology = None
        self.node_seq = 0
        self.task_seq = int(time.time() * 10) % 10 ** 9  # never reuse ids across restarts
        self.rev = 1
        self.epoch = 0
        self.store = None
        self.contest = None  # name, id, data, answers, scale, problems
        self.preparing = None  # {"stage", "pct", "error"} while a contest is being packed
        self.prepare_thread = None
        self.prepare_cancel = threading.Event()
        self.resetting = False
        self._reset([])
        self._open_saved()
        threading.Thread(target=self._sampler, daemon=True, name="sampler").start()

    def _reset(self, problems):
        self.problems = problems
        self.problem_by_id = {p["id"]: p for p in problems}
        self.subs = {}
        self.students = []
        self.student_rev = {}
        self.queues = {p["id"]: [] for p in problems}
        self.ready_count = 0
        self.priority = collections.deque()
        self.running = False
        self.started_once = False
        self._eta_cache = None
        self.sum_wall = {p["id"]: 0 for p in problems}
        self.count_wall = {p["id"]: 0 for p in problems}
        self.compile_sum = 0
        self.compile_count = 0
        self.work_log = collections.deque()  # (t, wall seconds of slot time spent)
        self.test_log = collections.deque()  # Only completed test points count toward displayed throughput.
        self.slot_samples = collections.deque()  # (t, busy slots)
        self.status_counts = collections.Counter()
        self.done_tests = {p["id"]: 0 for p in problems}
        self.total_tests = {p["id"]: 0 for p in problems}

    # -------------------------------------------------------------- contest configuration
    def contest_dir(self, cid):
        return os.path.join(self.contests_dir, cid)

    def data_bundle(self):
        return os.path.join(self.contest_dir(self.contest["id"]), "data.tar.gz") if self.contest else None

    def data_dirname(self):
        return "data_" + self.contest["id"] if self.contest else "data_none"

    def _open_saved(self):
        cur = os.path.join(self.state_dir, "current.txt")
        if not os.path.exists(cur):
            return
        with open(cur, encoding="utf8") as f:
            cid = f.read().strip()
        path = os.path.join(self.contest_dir(cid), "contest.json")
        if os.path.exists(path):
            with open(path, encoding="utf8") as f:
                self._activate(json.load(f))

    def _save_contest(self):
        c = self.contest
        with open(os.path.join(self.contest_dir(c["id"]), "contest.json"), "w", encoding="utf8") as f:
            json.dump(c, f, ensure_ascii=False, indent=1)
        with open(os.path.join(self.state_dir, "current.txt"), "w", encoding="utf8") as f:
            f.write(c["id"])

    def _activate(self, cfg, loaded_subs=None):
        """Switches the judge to a packed contest. Caller holds the lock or is still in __init__."""
        with self.lock:
            for n in self.nodes.values():
                n.inflight.clear()
            if self.store:
                self.store.close()
            for p in cfg["problems"]:
                p["points"] = C.points_for(p["full"], p["tests"])
            self.contest = cfg
            self._reset(cfg["problems"])
            self.store = Store(os.path.join(self.contest_dir(cfg["id"]), "results.db"))
            self._load(loaded_subs)
            self.epoch += 1
            self.rev += 1
            self._save_contest()
            self.cv.notify_all()
        for n in list(self.nodes.values()):
            n.restart()
        self._prune_history()

    def _prune_history(self):
        current = self.contest["id"] if self.contest else None
        for name in os.listdir(self.contests_dir):
            if re.fullmatch(r"[0-9a-f]{16}", name) and name != current:
                remove_managed_tree(self.contests_dir, os.path.join(self.contests_dir, name))

    def list_contests(self):
        """Every saved contest, most recently used first."""
        out = []
        for cid in os.listdir(self.contests_dir):
            if not self.contest or cid != self.contest["id"]:
                continue
            path = os.path.join(self.contest_dir(cid), "contest.json")
            try:
                with open(path, encoding="utf8") as f:
                    c = json.load(f)
                out.append({"id": cid, "name": c.get("name", ""), "data": c.get("data", ""),
                            "answers": c.get("answers", ""), "problems": [p["name"] for p in c["problems"]],
                            "t": os.path.getmtime(path),
                            "current": bool(self.contest and self.contest["id"] == cid)})
            except (OSError, ValueError, KeyError):
                continue  # half-written folder from an interrupted packing
        return sorted(out, key=lambda x: -x["t"])

    def open_contest(self, cid):
        """Switches to an already packed contest; the running one keeps its saved results."""
        path = os.path.join(self.contest_dir(cid), "contest.json")
        if os.path.basename(cid) != cid or not os.path.exists(path):
            raise ValueError("考试不存在")
        with self.lock:
            if self.preparing and self.preparing.get("stage") != "error":
                raise ValueError("正在准备比赛")
            if self.contest and self.contest["id"] == cid:
                return {"switching": False}
            self.running = False
        with open(path, encoding="utf8") as f:
            self._activate(json.load(f))
        return {"switching": False}

    def scan_folders(self, data_dir, answers_dir):
        report = C.scan(data_dir, answers_dir)[0]
        known = {p["id"]: p for p in self.contest["problems"]} if self.contest else {}
        for p in report["problems"]:
            k = known.get(p["id"])
            p.update({"name": k["name"], "tl": k["tl"], "ml": k["ml"], "full": k["full"]} if k else
                     {"name": p["id"], "tl": 1000, "ml": 1024, "full": 100})
        order = {pid: i for i, pid in enumerate(known)}
        report["problems"].sort(key=lambda p: (order.get(p["id"], len(order)), p["id"]))
        return report

    def configure(self, cfg):
        """Applies the contest form. Same files: limits update in place, and results that depended on a
        changed limit are cleared. Different files: packed in the background, then switched to."""
        with self.lock:
            if self.resetting:
                raise ValueError("正在恢复出厂设置")
            if self.preparing and self.preparing.get("stage") != "error":
                raise ValueError("正在准备比赛")
            expected_epoch = self.epoch
            cancel = self.prepare_cancel = threading.Event()
            self.preparing = {"stage": "scan", "pct": 0}
        try:
            return self._configure(cfg, expected_epoch, cancel)
        except Exception as e:
            if not cancel.is_set():
                self.preparing = {"stage": "error", "pct": 0, "error": str(e)[:300]}
            raise

    def _configure(self, cfg, expected_epoch, cancel):
        def progress(stage):
            def report(done, total, current):
                if cancel.is_set():
                    raise RuntimeError("比赛准备已取消")
                self.preparing = {"stage": stage, "pct": done * 100 // max(1, total),
                                  "done": done, "total": total, "current": current}
            return report
        data_dir, answers_dir = cfg["data"].strip(), cfg["answers"].strip()
        report, answers, data, _ = C.scan(data_dir, answers_dir, progress("scan"))
        ids = [p["id"] for p in report["problems"]]
        if not ids:
            raise ValueError("没有找到同时具备数据和答案的题目")
        wanted = {p["id"]: p for p in cfg.get("problems", [])}
        order = {pid: i for i, pid in enumerate(wanted)}
        report["problems"].sort(key=lambda p: (order.get(p["id"], len(order)), p["id"]))
        problems = []
        for r in report["problems"]:
            w = wanted.get(r["id"], {})
            tl, ml, full = int(w.get("tl", 1000)), int(w.get("ml", 1024)), int(w.get("full", 100))
            if tl <= 0 or ml <= 0 or full < 0:
                raise ValueError(f"{r['id']}: 时限、内存必须大于 0")
            problems.append({"id": r["id"], "name": (w.get("name") or r["id"]).strip(), "tl": tl, "ml": ml,
                             "full": full, "tests": r["tests"], "on": True})
        cid = C.fingerprint(answers, data, progress("fingerprint"))
        new = {"id": cid, "name": cfg.get("name", "").strip() or "比赛", "data": data_dir, "answers": answers_dir,
               "scale": bool(cfg.get("scale", True)), "problems": problems}
        with self.lock:
            if self.resetting or self.epoch != expected_epoch:
                raise ValueError("比赛状态已改变，请重新配置")
            if self.contest and self.contest["id"] == cid:
                result = self._update_in_place(new)
                self.preparing = None
                return result
            self.running = False
            self.preparing = {"stage": "data", "pct": 0}
            self.cv.notify_all()
        self.prepare_thread = threading.Thread(target=self._prepare, args=(new, answers, data, ids, cancel),
                                               daemon=True, name="prepare")
        self.prepare_thread.start()
        return {"switching": True}

    def _update_in_place(self, new):
        cur = self.contest
        scale_changed = cur["scale"] != new["scale"]
        changed = []
        by_id = {p["id"]: p for p in cur["problems"]}
        for n in new["problems"]:
            p = by_id[n["id"]]
            if scale_changed or p["tl"] != n["tl"] or p["ml"] != n["ml"]:
                changed.append(p["id"])
            full_changed = p["full"] != n["full"]
            p.update(name=n["name"], tl=n["tl"], ml=n["ml"], full=n["full"])
            if full_changed:
                p["points"] = C.points_for(p["full"], p["tests"])
        cur["name"] = new["name"]
        cur["scale"] = new["scale"]
        cur["problems"][:] = [by_id[p["id"]] for p in new["problems"]]
        for s in self.subs.values():
            if s.prob in changed:
                self._rejudge(s, set())
        for sid in self.students:
            self._touch(sid)
        self._recount()
        self._save_contest()
        self._eta_cache = None
        if scale_changed:
            for node in self.nodes.values():
                if node.gateway:node.restart()
        self.cv.notify_all()
        return {"switching": False, "cleared": changed}

    def _prepare(self, new, answers, data, ids, cancel):
        stopping = threading.Event()
        progress_lock = threading.Lock()
        parts = {'data': 0, 'answers': 0}
        source_counts = {'done': 0, 'total': sum(len(answers[p]) for p in ids)}
        source_started = time.monotonic()
        def report(stage, pct, done=None, total=None):
            if cancel.is_set() or stopping.is_set(): raise RuntimeError('比赛准备已取消')
            with progress_lock:
                parts[stage] = pct
                if stage == 'answers':source_counts.update(done=done, total=total)
                rate = source_counts['done'] / max(.001, time.monotonic() - source_started)
                self.preparing = {'stage': 'bundle', 'pct': sum(parts.values()) // 2,
                                  'current': f"数据 {parts['data']}%，代码 {parts['answers']}%，{rate:.1f} 份/秒",
                                  **source_counts}
        def progress(pct):
            report('data', pct)
        def source_progress(done, total):
            report('answers', done * 100 // max(1, total), done, total)
        try:
            d = self.contest_dir(new["id"])
            os.makedirs(d, exist_ok=True)
            bundle = os.path.join(d, "data.tar.gz")
            sources = os.path.join(d, "submissions.zip")
            loaded_subs = {}
            problems = {p['id']: p for p in new['problems']}
            def consume(p, sid, raw, analysis):
                loaded_subs[(sid, p)] = Sub(sid, problems[p], analysis[0], raw, source_analysis=analysis)
            def prepare_data():
                if not os.path.exists(bundle): C.pack_data(data, ids, bundle, 'data_' + new['id'], progress)
                progress(100)
            def prepare_sources():
                if not os.path.exists(sources):
                    C.pack_answers(answers, ids, sources, source_progress,
                                   analyzer=partial(scan.prepare_source, linux=LINUX_MODE), consume=consume)
                else:
                    loaded_subs.update(self._read_submissions(new, cancel, report_progress=False))
                count = sum(len(answers[p]) for p in ids)
                source_progress(count, count)
            with ThreadPoolExecutor(max_workers=2) as pool:
                futures = [pool.submit(prepare_data), pool.submit(prepare_sources)]
                try:
                    for future in as_completed(futures): future.result()
                except Exception:
                    stopping.set()
                    raise
            if cancel.is_set():
                return
            # Reopening known folders keeps per-problem switches.
            old = os.path.join(d, "contest.json")
            if os.path.exists(old):
                with open(old, encoding="utf8") as f:
                    saved = {p["id"]: p for p in json.load(f)["problems"]}
                for p in new["problems"]:
                    p["on"] = saved.get(p["id"], p).get("on", True)
            # The packer already decoded and checked these exact persisted bytes.
            self.preparing = {"stage": "activate", "pct": 0}
            with self.lock:
                if cancel.is_set() or self.resetting:
                    return
                self._activate(new, loaded_subs)
                self.preparing = None
        except Exception as e:  # unreadable folder, full disk: shown on the contest page
            if not cancel.is_set():
                self.preparing = {"stage": "error", "pct": 0, "error": str(e)[:300]}

    # -------------------------------------------------------------- load
    def _read_submissions(self, cfg, cancel=None, report_progress=True):
        problems = {p["id"]: p for p in cfg["problems"]}
        subs = {}
        with zipfile.ZipFile(os.path.join(self.contest_dir(cfg["id"]), "submissions.zip")) as zf:
            entries = zf.infolist()
            total = len(entries)
            def sources():
                seen = set()
                for info in entries:
                    if cancel is not None and cancel.is_set(): raise RuntimeError('比赛准备已取消')
                    parts = info.filename.split('/')
                    if len(parts) == 3 and parts[1] in problems:
                        key = (parts[0], parts[1])
                        if key in seen:raise RuntimeError('源码归档中存在重复提交：' + info.filename)
                        seen.add(key)
                        yield parts[1], parts[0], zf.read(info)
            pipeline = C.source_pipeline(sources(), total, partial(scan.prepare_source, linux=LINUX_MODE), from_files=False)
            for index, (p, sid, raw, analysis) in enumerate(pipeline):
                if cancel is not None:
                    if cancel.is_set():
                        raise RuntimeError("比赛准备已取消")
                    if report_progress:
                        self.preparing = {"stage": "load", "pct": index * 100 // max(1, total),
                                          "done": index, "total": total, "current": sid + '/' + p}
                try:
                    subs[(sid, p)] = Sub(sid, problems[p], analysis[0], raw, source_analysis=analysis)
                except Exception as e:
                    raise RuntimeError(f"加载 {sid}/{p} 失败：{e}") from e
        return subs

    def _load(self, loaded_subs=None):
        self.subs = self._read_submissions(self.contest) if loaded_subs is None else loaded_subs
        self.students = sorted({sid for sid, _ in self.subs})
        db = self.store.db
        report_progress = bool(self.preparing and self.preparing.get("stage") == "activate")
        restored = 0
        total = len(self.students) + len(self.subs)
        if report_progress:
            total += sum(db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                         for table in ("tests", "compiles", "flags"))

        def progress(current):
            nonlocal restored
            restored += 1
            if report_progress and (restored % 512 == 0 or restored == total):
                self.preparing = {"stage": "activate", "pct": restored * 100 // max(1, total),
                                  "done": restored, "total": total, "current": current}

        for sid, prob, test, st, cpu, wall, mem, detail, node in db.execute(
                "SELECT sid, prob, test, status, cpu, wall, mem, detail, node FROM tests"):
            s = self.subs.get((sid, prob))
            if s:
                s.tests[test] = (st, cpu, wall, mem, detail, node)
                self.sum_wall[prob] += wall
                self.count_wall[prob] += 1
            progress("恢复测点成绩")
        for sid, prob, st, ms, log in db.execute("SELECT sid, prob, status, ms, log FROM compiles"):
            s = self.subs.get((sid, prob))
            if s:
                s.compile = (st, ms, log)
                if st == "CE":
                    for result in s.tests.values():
                        self.sum_wall[s.prob] -= result[2]
                        self.count_wall[s.prob] -= 1
                    s.tests.clear()
                self.compile_sum += ms
                self.compile_count += 1
            progress("恢复编译结果")
        released, skipped = set(), set()
        for sid, prob, kind in db.execute("SELECT sid, prob, kind FROM flags"):
            (released if kind == "released" else skipped).add((sid, prob))
            progress("恢复隔离与跳过设置")
        for sid in self.students:
            self.rev += 1
            self.student_rev[sid] = self.rev
            progress("建立考生索引")
        for key in sorted(self.subs):
            s = self.subs[key]
            s.skipped = key in skipped
            if s.skipped:
                s.state = "skipped"
            elif s.reasons and (key not in released or any(r.startswith('LP64 ') for r in s.reasons)):
                s.state = "held"
            elif not s.remaining():
                s.state = "done"
            else:
                self.enqueue(s)
            progress("建立评测队列")
        self._recount()

    def _recount(self):
        self.status_counts = collections.Counter()
        for p in self.problems:
            self.done_tests[p["id"]] = 0
            self.total_tests[p["id"]] = 0
        for s in self.subs.values():
            n = s.problem["tests"]
            if s.state in ("held", "skipped"):
                continue
            self.total_tests[s.prob] += n
            if s.compile and s.compile[0] == "CE":
                self.done_tests[s.prob] += n
                self.status_counts["CE"] += n
            else:
                self.done_tests[s.prob] += len(s.tests)
                for r in s.tests.values():
                    self.status_counts[r[0]] += 1

    def _touch(self, sid):
        self.rev += 1
        self.student_rev[sid] = self.rev

    # -------------------------------------------------------------- scheduling
    def take(self, node=None):
        """LPT across ready submissions; cache affinity is a soft, bounded tie-break."""
        def valid(entry):
            sub, gen, version = entry
            return sub.queued and sub.gen == gen and sub.queue_version == version and bool(sub.available())
        def claim(sub):
            sub.queued = False
            self.ready_count -= 1
            return sub
        for _ in range(len(self.priority)):
            entry = self.priority.popleft()
            if valid(entry):
                if self.problem_by_id[entry[0].prob]["on"]:return claim(entry[0])
                self.priority.append(entry)
        best = None
        for pid, q in self.queues.items():
            if not self.problem_by_id[pid]["on"]:
                continue
            while q and not valid((q[0][-1], q[0][3], q[0][4])):
                stale=heapq.heappop(q); sub=stale[-1]
                if sub.queued and sub.gen==stale[3] and sub.queue_version==stale[4]:
                    sub.queued=False;self.ready_count-=1
            if q and (best is None or q[0][:3] < best[0][:3]):
                best = q
        if best is None:return None
        if node:
            for pid,q in self.queues.items():
                if not q or not self.problem_by_id[pid]["on"]:continue
                s=q[0][-1]
                if q[0][0] <= best[0][0]*.97 and (s.prob,s.wire) in node.cached_programs:
                    best=q
                    break
        return claim(heapq.heappop(best)[-1])

    def point_cost(self, s):
        count=self.count_wall[s.prob]
        return max(1,self.sum_wall[s.prob]/count if count else s.problem["tl"]*.25)

    def idle_slots(self):
        return sum(max(0,(n.slots or 0)-len(n.inflight)) for n in self.nodes.values()
                   if n.stage=="online" and n.enabled and not n.managed and not n.routing_draining)

    def rebalance_tail(self):
        if self.ready_count or self.idle_slots()<2:return
        largest=None
        for node in self.nodes.values():
            for task in node.inflight.values():
                if task.cancelled or task.yielded:continue
                left=sum(test not in task.sub.tests for test in task.tests)
                cost=left*self.point_cost(task.sub)*task.factor
                if left>1 and cost>2000 and (largest is None or cost>largest[0]):largest=(cost,task)
        if largest:
            task=largest[1];task.yielded=True
            task.node._send(f"YIELD {task.id}\n")

    def start_task(self, node):
        if getattr(self.store, "error", None):
            self.running = False
            return None
        s = self.take(node)
        if s is None:
            return None
        self.task_seq += 1
        s.state = "running"
        available=s.available()
        tests=available
        if self.idle_slots()>=2 and self.ready_count < max(1,self.idle_slots()//2):
            compile_ms=self.compile_sum/self.compile_count if self.compile_count else 500
            budget=max(500,min(2000,compile_ms*4))
            size=max(1,math.ceil(budget/(self.point_cost(s)*node.factor())))
            tests=available[:size]
        t = Task(self.task_seq, s, s.gen, node, tests)
        s.tasks[t.id] = t
        if s.available():self.enqueue(s)
        return t

    def enqueue(self, s, front=False):
        if not s.available():
            s.state = "running" if s.tasks else s.state
            return
        s.state = "running" if s.tasks else "queued"
        if not s.queued:self.ready_count+=1
        s.queued=True
        s.queue_version += 1
        entry = (s, s.gen, s.queue_version)
        cost=len(s.available())*self.point_cost(s)+(self.compile_sum/self.compile_count if self.compile_count else 500)
        heapq.heappush(self.queues[s.prob],(-cost,s.sid,s.prob,s.gen,s.queue_version,s))
        if s.prioritized:self.priority.append(entry)
        self.cv.notify_all()

    def _current_task(self, task):
        s = task.sub
        return (task.epoch == self.epoch and self.subs.get((s.sid, s.prob)) is s
                and task.gen == s.gen and s.tasks.get(task.id) is task)

    def on_compile(self, task, status, ms, log, node_name, cached=False):
        with self.lock:
            s = task.sub
            if not self._current_task(task) or task.cancelled or (s.compile and s.compile[0] == "CE"):
                return
            if status not in ("OK", "CE", "SE") or ms < 0:
                task.error = "节点返回了无效的编译结果"
                return
            if status == "SE":
                task.error = log or "编译基础设施错误"
                return  # requeued at DONE; a broken node must not leave a CE behind
            if status == "CE" and s.compile and s.compile[0] == "OK":
                task.error = "节点编译结果不一致"
                return
            if status == "OK":
                if cached and s.compile and s.compile[0] == "OK":
                    return
            ms = round(ms / task.factor)
            s.compile = (status, ms, log)
            if not cached:
                self.compile_sum += ms
                self.compile_count += 1
            self.work_log.append((time.time(), ms / 1000.0))
            self.store.put("INSERT OR REPLACE INTO compiles VALUES(?,?,?,?,?)", (s.sid, s.prob, status, ms, log))
            if status == "CE":
                if s.queued:s.queued=False;self.ready_count-=1
                for other in list(s.tasks.values()):
                    if other is not task:
                        other.node.kill(other.id)
                # Only this submission changed. Recounting everything holds the scheduler
                # lock and consumes Python CPU that SSH uploads also need.
                if s.state not in ("held", "skipped"):
                    count = s.problem["tests"]
                    self.done_tests[s.prob] += count - len(s.tests)
                    for result in s.tests.values():
                        self.status_counts[result[0]] -= 1
                        if not self.status_counts[result[0]]:
                            del self.status_counts[result[0]]
                    self.status_counts["CE"] += count
                for result in s.tests.values():
                    self.sum_wall[s.prob] -= result[2]
                    self.count_wall[s.prob] -= 1
                s.tests.clear()
                self.store.put("DELETE FROM tests WHERE sid=? AND prob=?", (s.sid, s.prob))
                self._touch(s.sid)

    def on_test(self, task, test, status, cpu, wall, mem, detail, node_name):
        with self.lock:
            s = task.sub
            if (not self._current_task(task) or task.cancelled or test in s.tests
                    or test not in task.tests or (s.compile and s.compile[0] == "CE")):
                return False
            if status not in STATUS_CHAR or min(cpu, wall, mem) < 0:
                task.error = "节点返回了无效的测点结果"
                return False
            if status == "SE":
                task.error = detail or "评测基础设施错误"
                return False
            requested_limit=max(1,round(s.problem['tl']*task.factor))
            # Allow one millisecond for normalisation/rounding through a relay.
            # A low-CPU wall-guard failure must never become a final TLE.
            if status=='TLE' and cpu+1<requested_limit:
                task.error='节点返回 TLE，但 CPU 时间明显低于时限，需重试'
                return False
            if status in ('AC','WA','NOF') and cpu>requested_limit+1:
                task.error='节点返回的状态与 CPU 超时记录不一致，需重试'
                return False
            cpu = round(cpu / task.factor)
            wall = round(wall / task.factor)
            s.tests[test] = (status, cpu, wall, mem, detail, node_name)
            self.sum_wall[s.prob] += wall
            self.count_wall[s.prob] += 1
            self.work_log.append((time.time(), wall / 1000.0))
            self.test_log.append(time.time())
            self.status_counts[status] += 1
            self.done_tests[s.prob] += 1
            self.store.put("INSERT OR REPLACE INTO tests VALUES(?,?,?,?,?,?,?,?,?)",
                           (s.sid, s.prob, test, status, cpu, wall, mem, detail, node_name))
            self._touch(s.sid)
            return True

    def on_done(self, task, failed=False):
        with self.lock:
            s = task.sub
            if not self._current_task(task):
                return
            del s.tasks[task.id]
            for test in task.tests:
                if test in s.tests or (s.compile and s.compile[0] == "CE") or task.cancelled or (task.yielded and not failed and not task.error):
                    continue
                s.attempts[test] = s.attempts.get(test, 0) + 1
                if s.attempts[test] >= self.failure_limit:
                    detail = f"连续 {self.failure_limit} 次评测失败：" + (task.error or ("节点连接中断" if failed else "测点结果缺失"))
                    s.tests[test] = ("SE", 0, 0, 0, detail, task.node.name())
                    self.status_counts["SE"] += 1
                    self.done_tests[s.prob] += 1
                    self.store.put("INSERT OR REPLACE INTO tests VALUES(?,?,?,?,?,?,?,?,?)",
                                   (s.sid, s.prob, test, "SE", 0, 0, 0, detail, task.node.name()))
                    self._touch(s.sid)
            if s.remaining():
                self.enqueue(s, front=True)
            else:
                s.state = "done"
                if s.queued:s.queued=False;self.ready_count-=1
                s.attempts.clear()
                s.prioritized = False
            self.cv.notify_all()

    # -------------------------------------------------------------- control
    def start(self):
        with self.lock:
            if self.store and getattr(self.store, "error", None):
                raise ValueError("成绩保存失败，不能继续评测：" + str(self.store.error))
            self.running = True
            self.started_once = True
            self.cv.notify_all()

    def pause(self):
        with self.lock:
            self.running = False
            self.cv.notify_all()

    def stop_now(self):
        with self.lock:
            self.running = False
            for n in self.nodes.values():
                n.kill_all()
            self.cv.notify_all()

    def set_problem(self, pid, on):
        with self.lock:
            self.problem_by_id[pid]["on"] = bool(on)
            self._save_contest()
            self._eta_cache = None
            self.cv.notify_all()

    def set_cpu_limit(self, percent):
        if type(percent) is not int or not 1 <= percent <= 100:
            raise ValueError("最大算力必须是 1 到 100 的整数百分比")
        with self.lock:
            if self.resetting:
                raise ValueError("正在恢复出厂设置")
            path = os.path.join(self.state_dir, "settings.json")
            with open(path + ".tmp", "w", encoding="utf8") as f:
                json.dump({"cpu_limit": percent}, f)
            os.replace(path + ".tmp", path)
            self.cpu_limit = percent
            self._eta_cache = None
            for node in self.nodes.values():
                if node.stage == "online" and node.cpu_limit_override is None:
                    node._send_config()
        return {"ok": True, "cpu_limit": percent}

    def factory_reset(self):
        with self.lock:
            if self.resetting:
                raise ValueError("正在恢复出厂设置")
            self.resetting = True
            self.running = False
            self.epoch += 1
            self.prepare_cancel.set()
            nodes = list(self.nodes.values())
        warnings = []
        try:
            if self.prepare_thread and self.prepare_thread.is_alive():
                self.prepare_thread.join(10)
                if self.prepare_thread.is_alive():
                    raise ValueError("正在停止数据打包，请稍后再次恢复出厂设置")
            for node in nodes:
                node.shutdown()
            for node in nodes:
                if node.thread:
                    node.thread.join(10)
                    if node.thread.is_alive():
                        raise ValueError(f"正在停止节点 {node.name()}，请稍后重试")
            self.relays.close()
            def clean_remote(node):
                if node.local:
                    return None
                conn = SSHConn(node, {"host": node.host, "port": node.port, "user": node.user,
                                     "password": node.password, "dir": node.dir, "key": node.key})
                try:
                    conn.clean_data()
                except Exception as e:
                    return f"{node.name()}：远端数据未清理（{str(e)[:200]}）"
                finally:
                    conn.close()
            with ThreadPoolExecutor(max_workers=4) as pool:
                warnings = [message for message in pool.map(clean_remote, nodes) if message]
            with self.lock:
                if self.store:
                    self.store.close()
                self.store = None
                self.contest = None
                self.preparing = None
                self.nodes.clear()
                self.node_seq = 0
                self._reset([])
                self.rev += 1
            for path in (self.state_dir, self.export_dir):
                remove_managed_tree(self.app_dir, path)
            os.makedirs(self.contests_dir, exist_ok=True)
            import relay
            self.relays=relay.Manager(self)
            self.cpu_limit = 100
            self.load_nodes()
            return {"ok": True, "warnings": warnings}
        finally:
            with self.lock:
                self.resetting = False
                self.cv.notify_all()

    def reorder_problems(self, ids):
        with self.lock:
            if not isinstance(ids, list) or not all(isinstance(p, str) for p in ids):
                raise ValueError("题目顺序必须是题目 ID 列表")
            if len(ids) != len(self.problems) or set(ids) != set(self.problem_by_id):
                raise ValueError("题目顺序必须包含全部题目，且不能重复")
            self.problems[:] = [self.problem_by_id[pid] for pid in ids]
            for sid in self.students:
                self._touch(sid)
            self._eta_cache = None
            self._save_contest()
        return {"ok": True, "order": ids}

    def _select(self, problems, students):
        pset = set(problems) if problems else set(self.problem_by_id)
        sset = set(students) if students else None
        return [s for (sid, prob), s in self.subs.items() if prob in pset and (sset is None or sid in sset)]

    def act(self, op, problems=None, students=None, statuses=None):
        statuses = set(statuses or [])
        affected = 0
        with self.lock:
            selected=self._select(problems,students)
            if op=='release' and any(s.state=='held' and any(r.startswith('LP64 ') for r in s.reasons) for s in selected):
                raise ValueError('包含无法安全转换的 LP64 格式串，需先解决兼容性，不能直接放行计分')
            for s in selected:
                if op == "rejudge":
                    affected += self._rejudge(s, statuses)
                elif op == "skip" and s.state in ("queued", "running"):
                    self._invalidate(s)
                    s.state = "skipped"
                    s.skipped = True
                    self.store.put("INSERT OR REPLACE INTO flags VALUES(?,?,?)", (s.sid, s.prob, "skipped"))
                    self._touch(s.sid)
                    affected += 1
                elif op == "unskip" and s.state == "skipped":
                    s.skipped = False
                    self.store.put("DELETE FROM flags WHERE sid=? AND prob=? AND kind='skipped'", (s.sid, s.prob))
                    if s.reasons and not self._is_released(s):
                        s.state = "held"
                    elif s.remaining():
                        self.enqueue(s)
                    else:
                        s.state = "done"
                    self._touch(s.sid)
                    affected += 1
                elif op == "release" and s.state == "held":
                    self.store.put("INSERT OR REPLACE INTO flags VALUES(?,?,?)", (s.sid, s.prob, "released"))
                    self.enqueue(s, front=True)
                    self._touch(s.sid)
                    affected += 1
                elif op == "hold" and s.reasons and s.state != "held":
                    self.store.put("DELETE FROM flags WHERE sid=? AND prob=? AND kind='released'", (s.sid, s.prob))
                    self._invalidate(s)
                    s.state = "held"
                    self._touch(s.sid)
                    affected += 1
                elif op == "prioritize" and s.state in ("queued", "running") and s.available():
                    s.prioritized = True
                    self.priority.append((s, s.gen, s.queue_version))
                    affected += 1
            self._recount()
            self.cv.notify_all()
        return affected

    def _is_released(self, s):
        self.store.flush()
        cur = self.store.db.execute("SELECT 1 FROM flags WHERE sid=? AND prob=? AND kind='released'", (s.sid, s.prob))
        return cur.fetchone() is not None

    def _invalidate(self, s):
        if s.queued:self.ready_count-=1;s.queued=False
        s.gen += 1
        for task in list(s.tasks.values()):
            task.node.kill(task.id)
        s.tasks.clear()

    def _rejudge(self, s, statuses):
        if s.state == "held":
            return 0
        drop_compile = False
        drop = []
        if statuses:
            drop = [t for t, r in s.tests.items() if r[0] in statuses]
            if s.compile and s.compile[0] in statuses:
                drop_compile = True
            if not drop and not drop_compile:
                return 0
        else:
            drop = list(s.tests)
            drop_compile = s.compile is not None
            if not drop and not drop_compile and s.state != "running":
                return 0
        self._invalidate(s)
        s.attempts.clear()
        for t in drop:
            r = s.tests.pop(t)
            self.sum_wall[s.prob] -= r[2]
            self.count_wall[s.prob] -= 1
            self.store.put("DELETE FROM tests WHERE sid=? AND prob=? AND test=?", (s.sid, s.prob, t))
        if drop_compile:
            s.compile = None
            self.store.put("DELETE FROM compiles WHERE sid=? AND prob=?", (s.sid, s.prob))
        if s.skipped:
            s.state = "skipped"
        elif s.remaining():
            self.enqueue(s, front=True)
        else:
            s.state = "done"
        self._touch(s.sid)
        return 1

    # -------------------------------------------------------------- nodes
    def is_master_host(self, host):
        return discover.is_local_host(host)

    def add_node(self, cfg):
        """cfg: user, host, port, password, slots, dir, enabled, local."""
        with self.lock:
            if cfg.get('local'):
                cfg={**cfg,'relay':None,'gateway':False,'relay_local':False}
            elif self.is_master_host(cfg.get('host','')):
                raise ValueError('主控本机不能作为远端节点或副控添加')
            topology = getattr(self, 'topology', None)
            if topology and cfg.get('auto_route') and not cfg.get('relay') and not any(cfg.get(k) for k in ('local', 'gateway', 'relay_local')):
                cfg = {**cfg, 'relay': topology.initial_parent(cfg['host'])}
            if cfg.get("relay") and cfg["relay"] not in self.relays.configs:
                raise ValueError("选择的副控不存在")
            for n in self.nodes.values():
                if n.same_target(cfg):
                    n.update_credentials(cfg)
                    self.save_nodes()
                    return n
            self.node_seq += 1
            node = Node(self, self.node_seq, cfg)
            self.nodes[node.id] = node
            self.save_nodes()
        node.ensure_started()
        return node

    def remove_node(self, nid):
        with self.lock:
            n = self.nodes.pop(nid, None)
            self.save_nodes()
        if n:
            n.shutdown()

    def save_nodes(self):
        data = [n.to_config() for n in self.nodes.values()]
        path = os.path.join(self.state_dir, "nodes.json")
        with open(path + ".tmp", "w", encoding="utf8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(path + ".tmp", path)
        self.relays.synchronize()

    def load_nodes(self):
        path = os.path.join(self.state_dir, "nodes.json")
        items = []
        if os.path.exists(path):
            with open(path, encoding="utf8") as f:
                items = json.load(f)
        if not any(i.get("local") for i in items):
            items.insert(0, {"local": True, "enabled": False})
        for c in items:
            if not c.get('local') and self.is_master_host(c.get('host','')):continue
            if not c.get('local') and c.get('relay') in self.relays.excluded_self_relays:
                if c.get('gateway') or c.get('relay_local'):continue
                c={**c,'relay':None}
            # Configurations from before connection tracking belong to an
            # established fleet; do not discard them on a transient outage.
            c.setdefault('connected_once', True)
            if not c.get("local"):
                pw = unprotect(c.get("password_sealed", ""))
                c["password"] = pw if pw is not None else ""
                c["password_lost"] = pw is None
            self.add_node(c)
        if globals().get('AUTO_TREE', False) and self.topology is None:
            from topology import Controller
            self.topology = Controller(self)
            self.topology.start()

    # -------------------------------------------------------------- status
    def _sampler(self):
        while True:
            time.sleep(2)
            now = time.time()
            with self.lock:
                busy = sum(len(n.inflight) / n.factor() for n in self.nodes.values())
                self.slot_samples.append((now, busy))
                while self.slot_samples and now - self.slot_samples[0][0] > 90:
                    self.slot_samples.popleft()
                while self.work_log and now - self.work_log[0][0] > 90:
                    self.work_log.popleft()
                while self.test_log and now - self.test_log[0] > 90:
                    self.test_log.popleft()

    def avg_wall_ms(self, pid):
        c = self.count_wall[pid]
        if c >= 30:
            return max(self.sum_wall[pid] / c, 5) + 25  # file setup and cleanup around each run
        return self.problem_by_id[pid]["tl"] * 0.35

    def eta(self):
        """Seconds of remaining work at the current capacity, or None when nothing can run."""
        remaining = 0.0
        comp = (self.compile_sum / self.compile_count) if self.compile_count >= 20 else 1100.0
        for s in self.subs.values():
            if s.state not in ("queued", "running") or not s.problem["on"]:
                continue
            r = s.remaining()
            remaining += len(r) * self.avg_wall_ms(s.prob) / 1000.0
            if s.compile is None:
                remaining += comp / 1000.0
        # All figures are in reference-machine seconds: a slot on a slower node counts for less.
        capacity = sum(n.power() for n in self.nodes.values())
        if remaining <= 0:
            return 0.0, 0.0, capacity
        if capacity <= 0 or not self.running:
            return None, remaining, capacity
        # Busy-slot utilisation seen recently corrects for scheduling and contention overheads.
        util = 0.9
        if len(self.slot_samples) >= 10 and self.work_log:
            span = self.slot_samples[-1][0] - self.slot_samples[0][0]
            avg_busy = sum(b for _, b in self.slot_samples) / len(self.slot_samples)
            done = sum(w for _, w in self.work_log)
            if span > 15 and avg_busy > 0:
                util = max(0.2, min(1.0, done / span / avg_busy))
        return remaining / (capacity * util), remaining, capacity

    def state_json(self, since):
        with self.lock:
            now = time.time()
            cache = self._eta_cache
            if cache is None or now - cache[0] > 2:
                cache = self._eta_cache = (now, self.eta(), {
                    p["id"]: (sum(1 for s in self.subs.values() if s.prob == p["id"]),
                              sum(1 for s in self.subs.values() if s.prob == p["id"] and s.state == "done"))
                    for p in self.problems})
            eta, work, capacity = cache[1]
            recent = [t for t in self.test_log if now - t <= 30]
            rate = len(recent) / 30.0
            rows = []
            if since < self.rev:
                for sid in self.students:
                    if self.student_rev[sid] > since:
                        rows.append(self.row(sid))
            held = [{"sid": s.sid, "prob": s.prob, "reasons": s.reasons} for s in self.subs.values()
                    if s.state == "held"]
            c = self.contest
            return {
                "epoch": self.epoch,
                "runtime": self.runtime,
                "contest": {"id": c["id"], "name": c["name"], "data": c["data"], "answers": c["answers"],
                            "scale": c["scale"]} if c else None,
                "preparing": self.preparing,
                "resetting": self.resetting,
                "rev": self.rev,
                "running": self.running,
                "storage_error": str(self.store.error) if self.store and getattr(self.store, "error", None) else None,
                "started": self.started_once,
                "problems": [
                    {"id": p["id"], "name": p["name"], "tl": p["tl"], "ml": p["ml"], "tests": p["tests"], "full": p["full"],
                     "done": self.done_tests[p["id"]], "total": self.total_tests[p["id"]], "on": p["on"],
                     "avg": round(self.sum_wall[p["id"]] / self.count_wall[p["id"]]) if self.count_wall[p["id"]] else None,
                     "subs": cache[2][p["id"]][0],
                     "subs_done": cache[2][p["id"]][1],
                     } for p in self.problems],
                "status": dict(self.status_counts),
                "eta": eta,
                "capacity": round(capacity, 1),
                "cpu_limit": self.cpu_limit,
                "rate": rate,
                "now": now,
                "nodes": [n.status() for n in self.nodes.values()],
                "relays": self.relays.status(),
                "topology": self.topology.status() if getattr(self, 'topology', None) else None,
                "rows": rows,
                "held": held,
                "students": len(self.students),
            }

    def row(self, sid):
        scores, strips = [], []
        total = 0
        for p in self.problems:
            s = self.subs.get((sid, p["id"]))
            if s is None:
                scores.append(None)
                strips.append("")
            else:
                v = s.score()
                total += v
                scores.append(v)
                strips.append(s.strip())
        return [sid, total, scores, strips]

    def sub_json(self, sid, prob):
        with self.lock:
            s = self.subs.get((sid, prob))
            if s is None:
                return None
            return self._sub_payload(s)

    def _sub_payload(self, s):
        pts = s.problem["points"]
        tests = []
        running = []
        for task in s.tasks.values():
            if not task.cancelled:
                test = next((t for t in task.tests if t not in s.tests), None)
                if test is not None:
                    running.append({"test": test, "node": task.node.name()})
        for t in range(1, s.problem["tests"] + 1):
            r = s.tests.get(t)
            if r:
                tests.append([t, r[0], r[1], r[2], r[3], r[4], r[5], pts[t - 1] if r[0] == "AC" else 0])
            else:
                tests.append([t, None, 0, 0, 0, "", "", 0])
        return {
            "sid": s.sid, "prob": s.prob, "state": s.state, "score": s.score(), "code": s.code, "tests": tests,
            "compile": list(s.compile) if s.compile else None, "reasons": s.reasons, "rewritten": s.rewritten,
            "running_tests": running,
        }

    # -------------------------------------------------------------- export
    def export_html(self, template):
        with self.lock:
            self.store.flush()
            data = {
                "export": True,
                "generated": time.time(),
                "name": self.contest["name"],
                "contest": {"id": self.contest["id"], "scale": self.contest["scale"]},
                "problems": [{k: p[k] for k in ("id", "name", "tl", "ml", "tests", "full")} for p in self.problems],
                "rows": [self.row(sid) for sid in self.students],
                "status": dict(self.status_counts),
                "subs": {f"{s.sid}/{s.prob}": self._sub_payload(s) for s in self.subs.values()},
            }
        blob = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/").replace("<!--", "\\u003c!--")
        html = template.replace("/*__EXPORT_DATA__*/null", blob)
        os.makedirs(self.export_dir, exist_ok=True)
        safe = re.sub(r'[\\/:*?"<>|\s]+', "_", self.contest["name"])[:60] or "result"
        name = safe + time.strftime("_%Y%m%d_%H%M%S.html")
        path = os.path.join(self.export_dir, name)
        with open(path, "w", encoding="utf8") as f:
            f.write(html)
        return path, name


# ------------------------------------------------------------------ connections
class LocalConn:
    """Runs the agent as a child process on the master machine."""

    def __init__(self, node, workdir):
        self.node = node
        self.workdir = workdir
        self.proc = None
        self.data_name = "data_none"

    def prepare(self):
        judge = self.node.judge
        os.makedirs(self.workdir, exist_ok=True)
        version_file = os.path.join(self.workdir, "VERSION")
        version = judge.payload_version()
        if not (os.path.exists(version_file) and open(version_file).read().strip() == version):
            self.node.set_stage("extracting", 0)
            with tarfile.open(os.path.join(judge.payload, "runtime.tar.gz")) as tf:
                tf.extractall(self.workdir, filter="data")
            shutil.copy2(os.path.join(judge.payload, AGENT_NAME), os.path.join(self.workdir, AGENT_NAME))
            with open(version_file, "w") as f:
                f.write(version)
        self.data_name = judge.data_dirname()
        if judge.contest:
            target = os.path.join(self.workdir, self.data_name)
            marker = os.path.join(target, ".ok")
            try:
                valid_data = open(marker, encoding="ascii").read().strip() == version
            except OSError:
                valid_data = False
            if not valid_data:
                self.node.set_stage("extracting", 0)
                with tarfile.open(judge.data_bundle()) as tf:
                    tf.extractall(self.workdir, filter="data")
                with open(marker, "w", encoding="ascii") as f:
                    f.write(version)
        for entry in os.listdir(self.workdir):
            if entry.startswith("data_") and entry != self.data_name:
                remove_managed_tree(self.workdir, os.path.join(self.workdir, entry))

    def open(self):
        self.proc = subprocess.Popen([os.path.join(self.workdir, AGENT_NAME), "serve", self.workdir, self.data_name],
                                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                     creationflags=0x08000000)
        return self.proc.stdout

    def send(self, data):
        self.proc.stdin.write(data)
        self.proc.stdin.flush()

    def set_timeout(self, seconds):
        pass

    def close(self):
        if self.proc:
            try:
                self.proc.stdin.close()
            except OSError:
                pass
            try:
                self.proc.kill()
            except OSError:
                pass
            self.proc = None


class SSHConn:
    """Deploys to and drives a Windows machine over SSH/SFTP."""

    def __init__(self, node, cfg):
        self.node = node
        self.cfg = cfg
        self.client = None
        self.chan = None
        self.shell = "cmd"
        self.sftp_dir = None
        self.win_dir = None
        self.data_name = "data_none"
        self.upload_proc = None
        self.closed = False

    def _exec(self, cmd, timeout=600):
        chan = self.client.get_transport().open_session()
        chan.settimeout(timeout)
        chan.exec_command(cmd)
        out = chan.makefile("rb").read()
        err = chan.makefile_stderr("rb").read()
        return chan.recv_exit_status(), out, err

    def _in_dir(self, cmd):
        return f'cd /d "{self.win_dir}" && {cmd}' if self.shell == "cmd" else f'cd "{self.win_dir}"; {cmd}'

    def powershell(self, script, timeout=600):
        # Win32-OpenSSH service PATH need not contain WindowsPowerShell.
        executable=('& "$env:SystemRoot\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"'
                    if self.shell=='powershell' else 'call "%SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"')
        encoded=base64.b64encode(script.encode('utf-16le')).decode('ascii')
        return self._exec(executable+' -NoProfile -NonInteractive -EncodedCommand '+encoded,timeout)

    def _connect(self):
        c = self.cfg
        self.node.set_stage("connecting", 0)
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # With no password: this machine's SSH keys first, then an empty password.
        self.client.connect(c["host"], port=c.get("port") or 22, username=c["user"], password=c.get("password") or "",
                            key_filename=c.get("key") or None, timeout=10, banner_timeout=15, auth_timeout=15,
                            allow_agent=not c.get("password") and not c.get("key"), look_for_keys=not c.get("password") and not c.get("key"))
        tr = self.client.get_transport()
        tr.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        tr.set_keepalive(15)
        tr.default_window_size = 8 * 1024 * 1024
        code, out, _ = self._exec("echo %OS%", 30)
        marker = out.decode("utf8", "replace").strip()
        if marker == "Windows_NT":
            self.shell = "cmd"
        else:
            code, out, _ = self._exec("$PSVersionTable.PSVersion.Major", 30)
            if code == 0 and out.strip().isdigit():
                self.shell = "powershell"
            else:
                raise RuntimeError("仅支持 Windows 节点")
        sftp = self.client.open_sftp()
        sftp.get_channel().settimeout(60)
        home = sftp.normalize(".")
        custom = (c.get("dir") or "").replace("\\", "/").rstrip("/")
        if custom:
            self.sftp_dir = (custom if custom.startswith("/") else "/" + custom) + "/" + REMOTE_SUBDIR
        else:
            self.sftp_dir = home.rstrip("/") + "/" + REMOTE_SUBDIR
        self.win_dir = self.sftp_dir.lstrip("/").replace("/", "\\")
        self.legacy_dirs = [home.rstrip("/") + "/.oi_judge", home.rstrip("/") + "/.oi_sprint"]
        if custom:
            legacy = custom if custom.startswith("/") else "/" + custom
            self.legacy_dirs.extend([legacy, legacy + "/.oi_sprint", legacy + "/.oi_judge"])
        if REMOTE_SUBDIR != '.oi_sprint_classic':self.legacy_dirs=[]
        return sftp

    def prepare(self):
        sftp = self._connect()
        self._mkdirs(sftp, self.sftp_dir)
        judge = self.node.judge
        version = judge.payload_version()
        current = None
        try:
            with sftp.open(self.sftp_dir + "/VERSION") as f:
                current = f.read().decode().strip()
        except OSError:
            pass
        if current != version:
            self._deploy(sftp, os.path.join(judge.payload, "runtime.tar.gz"))
            sftp.put(os.path.join(judge.payload, AGENT_NAME), self.sftp_dir + "/" + AGENT_NAME)
            with sftp.open(self.sftp_dir + "/VERSION", "w") as f:
                f.write(version)
        self.data_name = judge.data_dirname()
        if judge.contest:
            try:
                with sftp.open(f"{self.sftp_dir}/{self.data_name}/.ok") as f:
                    valid_data = f.read().decode("ascii").strip() == version
            except OSError:
                valid_data = False
            if not valid_data:
                self._deploy(sftp, judge.data_bundle())
                with sftp.open(f"{self.sftp_dir}/{self.data_name}/.ok", "w") as f:
                    f.write(version)
        self._cleanup_remote(self.data_name)
        sftp.close()

    def _cleanup_remote(self, keep=None, clear_cache=False):
        def quote(value):
            return "'" + value.replace("'", "''") + "'"
        roots = [self.sftp_dir] + self.legacy_dirs
        paths = ",".join(quote(path.lstrip("/").replace("/", "\\")) for path in roots)
        current = quote(self.win_dir)
        keep_literal = quote(keep or "")
        cache = "$true" if clear_cache else "$false"
        script = r"""
$ErrorActionPreference = 'Stop'
function Assert-NoLinks([string]$path) {
  $stack = New-Object 'System.Collections.Generic.Stack[string]'
  $stack.Push($path)
  while ($stack.Count -gt 0) {
    $next = $stack.Pop()
    $item = Get-Item -LiteralPath $next -Force
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Refusing linked directory' }
    foreach ($child in Get-ChildItem -LiteralPath $next -Force) {
      if (($child.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Refusing linked path' }
      if ($child.PSIsContainer) { $stack.Push($child.FullName) }
    }
  }
}
foreach ($raw in @(__ROOTS__)) {
  $base = [IO.Path]::GetFullPath($raw).TrimEnd('\')
  if (!(Test-Path -LiteralPath $base -PathType Container)) { continue }
  if ($base -eq [IO.Path]::GetPathRoot($base).TrimEnd('\')) { throw 'Refusing drive root' }
  if (((Get-Item -LiteralPath $base -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Refusing linked deployment root' }
  $marker = Test-Path -LiteralPath (Join-Path $base 'VERSION')
  $agent = (Test-Path -LiteralPath (Join-Path $base __AGENT__)) -or (Test-Path -LiteralPath (Join-Path $base 'oi-sprint-classic-agent.exe')) -or (Test-Path -LiteralPath (Join-Path $base 'oi-sprint-agent.exe')) -or (Test-Path -LiteralPath (Join-Path $base 'agent.exe'))
  $compiler = Test-Path -LiteralPath (Join-Path $base 'mingw\bin\g++.exe')
  if (!$marker -or !$agent -or !$compiler) { continue }
  foreach ($entry in Get-ChildItem -LiteralPath $base -Directory -Force) {
    $isData = ($entry.Name -match '^data_[0-9a-f]{16}$') -or ($entry.Name -eq 'data_none') -or ($entry.Name -eq 'data')
    $isCache = __CACHE__ -and ($base -eq __CURRENT__) -and ($entry.Name -in @('run','cache'))
    if (!$isData -and !$isCache) { continue }
    if (($base -eq __CURRENT__) -and ($entry.Name -eq __KEEP__)) { continue }
    $target = [IO.Path]::GetFullPath($entry.FullName)
    if (!$target.StartsWith($base + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Path outside deployment' }
    Assert-NoLinks $target
    Remove-Item -LiteralPath $target -Recurse -Force
  }
}
""".replace("__ROOTS__", paths).replace("__CURRENT__", current).replace("__KEEP__", keep_literal).replace("__CACHE__", cache).replace('__AGENT__',quote(AGENT_NAME))
        code, out, err = self.powershell(script,120)
        if code:
            raise RuntimeError("旧比赛数据清理失败：" + (err or out).decode("utf8", "replace")[:250])

    def clean_data(self):
        sftp = self._connect()
        sftp.close()
        self._cleanup_remote(clear_cache=True)

    def _deploy(self, sftp, bundle, assigned=False):
        size = os.path.getsize(bundle)
        if assigned:
            import assigned_data
            checksum=assigned_data.digest(bundle)
            remote=self.sftp_dir+'/assigned-'+checksum[:24]+'.tar.gz'
        else:
            remote = self.sftp_dir + "/bundle.tar.gz"
        self.node.transfer = {"file": os.path.basename(bundle), "done": 0, "total": size, "rate": 0}
        self.node.set_stage("waiting_upload", 0)
        last_time, last_done = time.monotonic(), 0

        def progress(done, _total, worker_rate=None):
            nonlocal last_time, last_done
            now = time.monotonic()
            elapsed = now - last_time
            if elapsed < 0.25 and done != size:
                return
            self.node.transfer = {"file": os.path.basename(bundle), "done": done, "total": size,
                                  "rate": worker_rate if worker_rate is not None else
                                          (done - last_done) / max(elapsed, 0.001)}
            self.node.set_stage("uploading", done * 100 // max(size, 1))
            last_time, last_done = now, done

        slots = self.node.judge.deploy_slots
        while not slots.acquire(timeout=.25):
            if self.closed or not self.node.alive or not self.node.enabled:
                raise RuntimeError("上传已取消")
        try:
            if self.closed or not self.node.alive or not self.node.enabled:
                raise RuntimeError("上传已取消")
            last_time = time.monotonic()
            self.node.set_stage("uploading", 0)
            if assigned and size<=4<<20:
                sftp.put(bundle,remote,callback=progress)
            else:
                self._upload_bundle(bundle, remote, progress)
        finally:
            slots.release()
        self.node.set_stage("extracting", 0)
        if assigned:
            script=assigned_data.install_script(self.win_dir,remote.rsplit('/',1)[1],checksum,self.node.judge.data_dirname())
            code,out,err=self.powershell(script,1800)
        else:
            command=self._in_dir("tar -xzf bundle.tar.gz")
            code, out, err = self._exec(command, 1800)
        if code != 0:
            raise RuntimeError("解压失败: " + (err or out).decode("utf8", "replace")[:300])
        sftp.remove(remote)

    def _upload_bundle(self, source, destination, progress):
        if getattr(sys, "frozen", False):
            command = [sys.executable, "--upload-worker"]
        else:
            command = [sys.executable, os.path.join(os.path.dirname(__file__), "transfer_worker.py")]
        cfg = {key: self.cfg.get(key) for key in ("host", "port", "user", "password", "key")}
        cfg.update(source=os.path.abspath(source), destination=destination)
        proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                creationflags=subprocess.CREATE_NO_WINDOW)
        self.upload_proc = proc
        try:
            if self.closed:
                raise RuntimeError("上传已取消")
            proc.stdin.write((json.dumps(cfg) + "\n").encode("utf8"))
            proc.stdin.close()
            complete, error = False, ""
            for line in proc.stdout:
                message = json.loads(line)
                if message.get("ok"):
                    complete = True
                elif "error" in message:
                    error = message["error"]
                elif "done" in message:
                    progress(message["done"], message["total"], message.get("rate"))
            code = proc.wait(5)
            if self.closed:
                raise RuntimeError("上传已取消")
            if code or not complete:
                raise RuntimeError("上传失败：" + (error or f"传输进程退出 {code}"))
        finally:
            if proc.poll() is None:
                proc.terminate()
            proc.wait(5)
            for pipe in (proc.stdin, proc.stdout):
                pipe.close()
            if self.upload_proc is proc:
                self.upload_proc = None

    @staticmethod
    def _mkdirs(sftp, path):
        parts = path.strip("/").split("/")
        cur = ""
        for i, part in enumerate(parts):
            cur += "/" + part
            if i == 0 and part.endswith(":"):
                continue
            try:
                sftp.stat(cur)
            except OSError:
                sftp.mkdir(cur)

    def open(self):
        exe = f".\\{AGENT_NAME} serve . {self.data_name}"
        self.chan = self.client.get_transport().open_session(window_size=8 * 1024 * 1024)
        self.chan.settimeout(300)  # self-checks and speed measurement come first on slow machines
        self.chan.exec_command(self._in_dir(exe))
        return self.chan.makefile("rb")

    def send(self, data):
        self.chan.sendall(data)

    def set_timeout(self, seconds):
        self.chan.settimeout(seconds)

    def close(self):
        self.closed = True
        worker = self.upload_proc
        if worker and worker.poll() is None:
            try:
                worker.terminate()
            except OSError:
                pass
        for x in (self.chan, self.client):
            try:
                if x:
                    x.close()
            except Exception:
                pass
        self.chan = None
        self.client = None


# ------------------------------------------------------------------ node
HEARTBEAT_EVERY = 10  # seconds between pings
HEARTBEAT_DEAD = 40  # silence after which a node's work goes back in the queue


class Node:
    def __init__(self, judge, nid, cfg):
        self.judge = judge
        self.id = nid
        self.local = bool(cfg.get("local"))
        self.relay_id = cfg.get("relay") or None
        self.relay_local = bool(cfg.get("relay_local"))
        self.gateway = bool(cfg.get("gateway"))
        self.auto_route = bool(cfg.get("auto_route", globals().get('AUTO_TREE', False)))
        self.connected_once = bool(cfg.get('connected_once', False))
        self.routing_draining = False
        self.managed = bool(self.relay_id and not self.gateway)
        self.remote_status = {}
        self.user = cfg.get("user", "")
        self.host = cfg.get("host", "本机" if self.local else "")
        self.port = cfg.get("port") or 22
        self.password = cfg.get("password", "")
        self.password_lost = cfg.get("password_lost", False)
        self.dir = cfg.get("dir", "")
        self.key = cfg.get("key", "")
        self.slots = cfg.get("slots")  # None until the machine has reported its cores
        override = cfg.get("cpu_limit")
        self.cpu_limit_override = override if type(override) is int and 1 <= override <= 100 else None
        self.enabled = cfg.get("enabled", True)
        self.stage = "offline"
        self.pct = 0
        self.transfer = None
        self.error = ""
        self.info = {}
        self.inflight = {}
        self.done = 0
        self.tests_recent = collections.deque()
        self.cached_programs = set()
        self.curve = []  # (concurrency, per-slot speed) as measured on this machine
        self.throughput = {}
        self.compile_active = self.compile_waiting = self.cache_hits = 0
        self.cache_hit_events = 0
        self.cpu_limit_applied = None
        self.conn = None
        self.outbox = queue.Queue()
        self.alive = True
        self.restarting = False
        self.thread = None
        self.last_rx = 0
        self.session = 0
        self.wake = threading.Event()

    def same_target(self, cfg):
        if self.relay_id != (cfg.get("relay") or None) or self.relay_local != bool(cfg.get("relay_local")) or self.gateway!=bool(cfg.get("gateway")):
            return False
        if self.local or cfg.get("local"):
            return self.local and bool(cfg.get("local"))
        return self.host == cfg.get("host") and self.user == cfg.get("user") and self.port == (cfg.get("port") or 22)

    def update_credentials(self, cfg):
        if cfg.get("password"):
            self.password = cfg["password"]
            self.password_lost = False
        if cfg.get("slots") is not None:
            self.slots = cfg["slots"]
        if cfg.get("dir"):
            self.dir = cfg["dir"]
        if "cpu_limit" in cfg:
            self._validate_cpu_limit(cfg["cpu_limit"])
            self.cpu_limit_override = cfg["cpu_limit"]
        if self.stage == "online":
            self._send_config()
        self.error = ""
        self.wake.set()

    def to_config(self):
        if self.local:
            return {"local": True, "enabled": self.enabled, "slots": self.slots,
                    "cpu_limit": self.cpu_limit_override}
        return {"user": self.user, "host": self.host, "port": self.port, "slots": None if self.gateway else self.slots, "dir": self.dir,
                "key": self.key, "enabled": self.enabled, "password_sealed": protect(self.password),
                "cpu_limit": self.cpu_limit_override, "relay":self.relay_id, "relay_local":self.relay_local,"gateway":self.gateway,
                "auto_route":self.auto_route, "connected_once":self.connected_once}

    def set_stage(self, stage, pct=0):
        self.stage = stage
        self.pct = pct
        if stage == 'online' and not self.connected_once:
            with self.judge.lock:
                self.connected_once = True
                save = getattr(self.judge, 'save_nodes', None)
                if save and self.judge.nodes.get(self.id) is self: save()

    def ensure_started(self):
        if self.managed:return
        if self.thread is None:
            self.thread = threading.Thread(target=self._run, daemon=True, name=f"node{self.id}")
            self.thread.start()

    def recommended_slots(self):
        """Highest measured throughput on this machine, subject to memory for 1 GB programs. Limits are
        scaled by the same measured speed, so running slots slower does not produce false TLEs."""
        if self.gateway:return 1
        if getattr(self.judge,'runtime','windows')=='linux' and not any(self.throughput.values()):
            return min(self.info.get('logical',1),max(1,(self.info.get('mem',4096)-2048)//1024))
        if not self.curve:
            return 1
        by_memory = max(1, (self.info.get("mem", 4096) - 2048) // 1024)
        options = [c for c in self.curve if c[0] <= by_memory] or self.curve[:1]
        measured=[(c[0],self.throughput.get(c[0],c[0]*c[1])) for c in options]
        peak=max(speed for _,speed in measured)
        return min(slots for slots,speed in measured if speed>=peak*.97)

    def compile_limit(self):
        if PROTOCOL=="OI-SPRINT-TREE/1" or getattr(self.judge,'runtime','windows')=="linux":
            slots=max(1,self.slots or 1)
            memory=max(1,(self.info.get('mem',4096)-2048)//3072)
            return min(4,slots,math.ceil(slots/4),memory)
        # Original behavior: compile/run share only the configured task slots.
        return max(1, self.slots or 1)

    def _send_config(self):
        if self.managed:
            self.judge.relays.synchronize()
            return
        self._send(f"CONFIG {self.compile_limit()} {self.effective_cpu_limit()}\n")

    @staticmethod
    def _validate_cpu_limit(percent):
        if percent is not None and (type(percent) is not int or not 1 <= percent <= 100):
            raise ValueError("节点 CPU 上限必须是 1 到 100 的整数，或留空跟随全局")

    def effective_cpu_limit(self):
        return self.judge.cpu_limit if self.cpu_limit_override is None else self.cpu_limit_override

    def set_cpu_limit(self, percent):
        self._validate_cpu_limit(percent)
        with self.judge.lock:
            if self.judge.resetting:
                raise ValueError("正在恢复出厂设置")
            previous = self.cpu_limit_override
            self.cpu_limit_override = percent
            try:
                self.judge.save_nodes()
            except Exception:
                self.cpu_limit_override = previous
                raise
            self.judge._eta_cache = None
            if self.stage == "online":
                self._send_config()

    def power(self):
        if self.gateway:return 0
        if self.managed:return self.remote_status.get("power",0) if self.enabled else 0
        slots = self.effective_slots()
        cores = self.info.get("logical", slots)
        return min(slots, cores * self.effective_cpu_limit() / 100) / self.factor()

    def speed(self):
        """Per-slot speed at the configured concurrency, interpolated from the measured curve."""
        if not self.curve:
            return 0.0
        n = max(1, self.slots or 1)
        prev = self.curve[0]
        for cur in self.curve:
            if n <= cur[0]:
                if cur[0] == prev[0]:
                    return cur[1]
                frac = (n - prev[0]) / (cur[0] - prev[0])
                return prev[1] + (cur[1] - prev[1]) * frac
            prev = cur
        # Beyond the measured range the machine is oversubscribed: share the last figure out.
        return prev[1] * prev[0] / n

    def factor(self):
        """Use single-task CPU performance, never the configured slot count, for time limits."""
        sp = self.curve[0][1] if self.curve else 0
        c = self.judge.contest
        if sp <= 0 or (c and not c["scale"]):
            return 1.0
        return min(4.0, max(0.5, REFERENCE_SPEED / sp))

    def effective_slots(self):
        if self.stage != "online" or not self.enabled:
            return 0
        return self.slots or 0

    def set_enabled(self, on):
        with self.judge.lock:
            self.enabled = bool(on)
            if not on:
                self.kill_all()
            self.judge.save_nodes()
            self.judge.cv.notify_all()
        self.wake.set()

    def set_slots(self, n):
        with self.judge.lock:
            self.slots = max(0, int(n))
            if self.stage == "online":
                self._send_config()
            self.judge.save_nodes()
            self.judge.cv.notify_all()

    def restart(self):
        """Reconnect so the node deploys the current contest's data."""
        with self.judge.lock:
            self.restarting = True
            self.session += 1
            self.set_stage("offline")
            if self.managed:self.remote_status={}
        self.wake.set()
        self._drop_connection()

    def move_to(self, rid):
        with self.judge.lock:
            if self.local or self.relay_local:
                raise ValueError("本机评测节点固定在其所在主控/副控，请迁移下属电脑")
            rid = rid or None
            if rid and rid not in self.judge.relays.configs:
                raise ValueError("目标副控不存在")
            if self.relay_id == rid:return
            self.restarting = True
            self._requeue_all(cancelled=True)
            self.relay_id = rid
            self.managed = bool(rid)
            self.remote_status={}
            self.judge.save_nodes()
        self.restart()
        if not self.managed:self.ensure_started()

    def shutdown(self):
        self.alive = False
        self.enabled = False
        self.wake.set()
        self._drop_connection()
        with self.judge.lock:
            self.judge.cv.notify_all()

    def _send(self, text):
        self.outbox.put(text.encode("ascii"))

    def _writer(self, conn, outbox):
        while True:
            data = outbox.get()
            if data is None:
                return
            chunks, size, closing = [data], len(data), False
            while size < 65536:
                try:
                    more = outbox.get_nowait()
                except queue.Empty:
                    break
                if more is None:
                    closing = True
                    break
                chunks.append(more)
                size += len(more)
            try:
                conn.send(b"".join(chunks))
            except Exception as e:
                if self.conn is conn:
                    self.error = _describe(e, self.password)
                    self._drop_connection()
                return
            if closing:
                return

    def kill(self, tid):
        with self.judge.lock:
            task = self.inflight.get(tid)
            if task:
                task.cancelled = True
        self._send(f"KILL {tid}\n")

    def kill_all(self):
        for tid in list(self.inflight):
            self.kill(tid)

    def _drop_connection(self):
        c = self.conn
        self.conn = None
        self.outbox.put(None)
        if c:
            c.close()

    def _run(self):
        backoff = 3
        while self.alive:
            if self.managed:
                self.wake.wait(2);self.wake.clear();continue
            if not self.enabled or self.password_lost:
                self.set_stage("disabled" if not self.enabled else "error")
                if self.password_lost:
                    self.error = "密码需重新输入"
                self.wake.wait(2)
                self.wake.clear()
                continue
            self.session += 1
            try:
                self._session()
                backoff = 3
            except Exception as e:  # network, auth, deploy: stay visible and retry
                if self.restarting:
                    self.set_stage("offline")
                else:
                    self.error = _describe(e, self.password)
                    self.set_stage("error")
            finally:
                voluntary = self.restarting or not self.enabled or not self.alive or not self.judge.running
                self.restarting = False
                self._requeue_all(cancelled=voluntary)
                self._drop_connection()
            if not self.alive:
                break
            if self.stage == "error":
                self.wake.wait(backoff)
                self.wake.clear()
                backoff = min(backoff * 2, 30)
            else:
                self.set_stage("offline")

    def _session(self):
        if getattr(self.judge,'runtime','windows')=='linux':
            from linux_connection import Connection
            conn=Connection(self)
        elif self.relay_id:
            from relay import Connection
            conn = Connection(self)
        elif self.local:
            conn = LocalConn(self, os.path.join(self.judge.state_dir, LOCAL_SUBDIR))
        else:
            conn = SSHConn(self, {"host": self.host, "port": self.port, "user": self.user, "password": self.password,
                                  "dir": self.dir, "key": self.key})
        self.conn = conn
        conn.prepare()
        if not self.alive or not self.enabled:
            return
        self.set_stage("starting")
        reader = conn.open()
        self.last_rx = time.time()
        line = reader.readline()
        if not line:
            raise RuntimeError("代理未启动")
        a = line.decode("ascii", "replace").split()
        if a and a[0] == "FATAL":
            raise RuntimeError(base64.b64decode(a[1]).decode("utf8", "replace")[:400])
        if len(a) != 9 or a[0] != "HELLO" or a[8] != PROTOCOL:
            raise RuntimeError("代理响应异常: " + line.decode("utf8", "replace")[:200])
        self.info = {"build": int(a[1]), "logical": int(a[2]), "physical": int(a[3]), "perf": int(a[4]),
                     "mem": int(a[5]), "sandbox": a[7]}
        measured = [kv.split(":") for kv in a[6].split(",")]
        self.curve = sorted((int(k), float(sp)) for k, sp, _ in measured)
        self.throughput = {int(k): float(tp) for k, _, tp in measured}
        with self.judge.lock:
            if self.slots is None:
                self.slots = self.recommended_slots()
                self.judge.save_nodes()
        self.error = ""
        conn.set_timeout(HEARTBEAT_DEAD * 1.5)
        self.outbox = queue.Queue()
        self.cache_hits = self.cache_hit_events = 0
        self.cached_programs.clear()
        threading.Thread(target=self._writer, args=(conn, self.outbox), daemon=True, name=f"send{self.id}").start()
        self._send_config()
        self.cpu_limit_applied = None
        while self.cpu_limit_applied is None:
            reply = reader.readline()
            if not reply:
                raise RuntimeError("节点未确认算力设置")
            self._handle(reply.decode("ascii", "replace").rstrip("\r\n"))
        self.set_stage("online")
        session = self.session
        threading.Thread(target=self._dispatch, args=(session,), daemon=True, name=f"disp{self.id}").start()
        threading.Thread(target=self._heartbeat, args=(session,), daemon=True, name=f"heart{self.id}").start()
        while self.alive and self.enabled and self.session==session:
            line = reader.readline()
            if self.session!=session:break
            if not line:
                break
            self.last_rx = time.time()
            self._handle(line.decode("ascii", "replace").rstrip("\r\n"))
        if self.alive and self.enabled:
            raise RuntimeError("连接中断")

    def _dispatch(self, session):
        while self.alive and self.session == session and self.stage == "online":
            task = None
            with self.judge.lock:
                if self.judge.running and self.enabled and not self.routing_draining and self.session==session and self.stage=="online" and len(self.inflight) < (self.slots or 0):
                    task = self.judge.start_task(self)
                    if task:
                        self.inflight[task.id] = task
                if task is None:
                    if self.judge.running:self.judge.rebalance_tail()
                    self.judge.cv.wait(1)
            if task is not None:
                prepare=getattr(self.judge,"prepare_task",None)
                connection=self.conn
                if prepare:
                    try:prepare(self,task)
                    except Exception as error:
                        with self.judge.lock:
                            self.inflight.pop(task.id,None);task.error=str(error)
                            self.judge.on_done(task,failed=not task.cancelled)
                        if task.cancelled:
                            if self.session==session and self.conn is connection:self.set_stage('online')
                            continue
                        if self.session==session and self.conn is connection:
                            self.error=str(error);self._drop_connection()
                        return
                with self.judge.lock:
                    if not self.judge._current_task(task) or task.cancelled or self.session!=session:
                        # A cancelled upload never reached the agent, so no DONE will arrive.
                        if self.inflight.get(task.id) is task:self.inflight.pop(task.id)
                        self.judge.on_done(task)
                        self.judge.cv.notify_all()
                        continue
                    if task.yielded:
                        self.inflight.pop(task.id,None);self.judge.on_done(task);continue
                    # Queue TASK while holding the same lock as KILL/rejudge, preserving wire order.
                    s = task.sub
                    p = s.problem
                    tl = max(1,round(p["tl"] * task.factor))
                    tests = ",".join(map(str, task.tests))
                    task.sent=True
                    self._send(f"TASK {task.id} {s.prob} {tl} {p['ml']} {s.flags} {tests} {s.wire}\n")
    def _heartbeat(self,session):
        last_ping=time.time()
        while self.alive and self.enabled and self.session==session and self.conn is not None:
            now = time.time()
            if now - last_ping > HEARTBEAT_EVERY:
                last_ping = now
                self._send("PING\n")
                # Power loss or a pulled cable leaves TCP looking healthy; only silence reveals it.
                if now - self.last_rx > HEARTBEAT_DEAD:
                    self.error = "节点无响应"
                    self.set_stage("error")
                    self._requeue_all(cancelled=not self.judge.running)
                    self._drop_connection()
                    return
            time.sleep(1)

    def _handle(self, line):
        a = line.split(" ")
        kind = a[0]
        if kind == "FATAL" and len(a) >= 2:
            raise RuntimeError(base64.b64decode(a[1]).decode("utf8", "replace"))
        if kind == "CONFIG_OK" and len(a) == 2:
            self.cpu_limit_applied = int(a[1])
        elif kind == "TEST" and len(a) >= 8:
            task = self.inflight.get(int(a[1]))
            if task:
                detail = "" if a[7] == "-" else base64.b64decode(a[7]).decode("utf8", "replace")
                node_name=base64.b64decode(a[8]).decode("utf8","replace") if self.gateway and len(a)>8 else self.name()
                if self.judge.on_test(task, int(a[2]), a[3], int(a[4]), int(a[5]), int(a[6]), detail, node_name):
                    self.done += 1
                    self.tests_recent.append(time.time())
        elif kind == "COMPILE" and len(a) >= 5:
            task = self.inflight.get(int(a[1]))
            if task:
                if a[2]=="OK":self.cached_programs.add((task.sub.prob,task.sub.wire))
                if len(a) > 5 and a[5] == "HIT":
                    self.cache_hit_events += 1
                    self.cache_hits = max(self.cache_hits, self.cache_hit_events)
                log = "" if a[4] == "-" else base64.b64decode(a[4]).decode("utf8", "replace")
                self.judge.on_compile(task, a[2], int(a[3]), log, self.name(), cached=len(a) > 5 and a[5] == "HIT")
        elif kind == "DONE" and len(a) >= 2:
            with self.judge.lock:
                task = self.inflight.pop(int(a[1]), None)
                if task:
                    self.judge.on_done(task)
                self.judge.cv.notify_all()
        elif kind == "STATS" and len(a) == 4:
            self.compile_active, self.compile_waiting, reported_hits = map(int, a[1:])
            self.cache_hits = max(self.cache_hit_events, reported_hits)
        elif kind=="CAPACITY" and self.gateway and len(a)==2:
            with self.judge.lock:self.slots=max(0,min(1024,int(a[1])));self.judge.cv.notify_all()
        elif kind=="TREE" and self.gateway and len(a)==2:
            self.judge.relays.accept_status(self.relay_id,json.loads(base64.b64decode(a[1])))
        elif kind=="YIELDED" and self.gateway and len(a)==2:
            with self.judge.lock:
                task=self.inflight.get(int(a[1]))
                if task:task.yielded=True

    def _requeue_all(self, cancelled=False):
        with self.judge.lock:
            tasks = list(self.inflight.values())
            self.inflight.clear()
            for t in tasks:
                t.cancelled |= cancelled
                self.judge.on_done(t, failed=True)
            self.judge.cv.notify_all()
        if self.gateway:self.judge.relays.mark_offline(self.relay_id)

    def name(self):
        return self.host

    def status(self):
        if self.managed:
            if self.remote_status:
                return {**self.remote_status,"id":self.id,"relay":self.relay_id,"relay_local":self.relay_local,
                        "managed":True,"enabled":self.enabled,"cpu_limit":self.cpu_limit_override,
                        "connected_once":self.connected_once}
        now = time.time()
        while self.tests_recent and now - self.tests_recent[0] > 30:
            self.tests_recent.popleft()
        return {
            "id": self.id, "local": self.local, "host": self.host, "user": self.user, "port": self.port,
            "relay": self.relay_id, "relay_local": self.relay_local,
            "gateway":self.gateway,"managed":self.managed,"connected_once":self.connected_once,
            "stage": self.stage, "pct": self.pct, "error": self.error, "enabled": self.enabled, "slots": self.slots or 0,
            "transfer": self.transfer if self.stage in ("waiting_upload", "uploading") else None,
            "inflight": len(self.inflight), "done": self.done, "rate": round(len(self.tests_recent) / 30.0, 1),
            "info": self.info, "dir": self.dir, "factor": round(self.factor(), 2),
            "recommended": self.recommended_slots() if self.curve else None,
            "compile_active": self.compile_active, "compile_waiting": self.compile_waiting,
            "compile_limit": self.compile_limit(), "cache_hits": self.cache_hits,
            "power": round(self.power(), 1), "cpu_limit_applied": self.cpu_limit_applied,
            "cpu_limit": self.cpu_limit_override, "cpu_limit_effective": self.effective_cpu_limit(),
        }


def _describe(e, password=""):
    if isinstance(e, paramiko.AuthenticationException):
        return "密码错误" if password else "无密码登录被拒绝"
    if isinstance(e, (socket.timeout, TimeoutError)):
        return "连接超时"
    if isinstance(e, paramiko.SSHException):
        return "SSH: " + str(e)[:200]
    if isinstance(e, OSError) and e.errno in (10061, 111):
        return "SSH 端口未开放"
    if isinstance(e, OSError) and e.errno in (10051, 10060, 10065):
        return "主机不可达"
    return str(e)[:300] or e.__class__.__name__


# ------------------------------------------------------------------ bulk add parsing
_RANGE_BRACKET = re.compile(r"\[(\d+)-(\d+)\]")
_RANGE_TAIL = re.compile(r"^(.*\.)(\d+)-(\d+)$")


def parse_nodes(text, default_slots=None):
    """Lines such as: hp@192.168.11.10 password:abc slots:8 dir:D:\\judge
    Ranges: hp@192.168.11.[10-30] or hp@192.168.11.10-30. Errors are reported per line."""
    out, errors = [], []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        tokens = line.split()
        target = tokens[0]
        m = re.match(r"^([^@\s]+)@(.+)$", target)
        if not m:
            errors.append(line.split()[0])
            continue
        user, hostspec = m.group(1), m.group(2)
        port = 22
        pm = re.match(r"^(.*):(\d+)$", hostspec)
        if pm:
            hostspec, port = pm.group(1), int(pm.group(2))
        password, slots, workdir, keyfile = "", default_slots, "", ""
        for tok in tokens[1:]:
            kv = re.match(r"^(password|passwd|pwd|密码|slots|并发|dir|目录|key)[:=：](.*)$", tok, re.I)
            if kv:
                k, v = kv.group(1).lower(), kv.group(2)
                if k in ("password", "passwd", "pwd", "密码"):
                    password = v
                elif k in ("slots", "并发"):
                    slots = int(v) if v.isdigit() else slots
                elif k == "key":
                    keyfile = v
                else:
                    workdir = v
            elif not password:
                password = tok
        hosts = []
        rb = _RANGE_BRACKET.search(hostspec)
        rt = _RANGE_TAIL.match(hostspec)
        if rb:
            a, b = int(rb.group(1)), int(rb.group(2))
            hosts = [hostspec[:rb.start()] + str(i) + hostspec[rb.end():] for i in range(a, b + 1)]
        elif rt:
            hosts = [rt.group(1) + str(i) for i in range(int(rt.group(2)), int(rt.group(3)) + 1)]
        else:
            hosts = [hostspec]
        for h in hosts:
            out.append({"user": user, "host": h, "port": port, "password": password, "slots": slots, "dir": workdir,
                        "key": keyfile, "enabled": True})
    return out, errors
