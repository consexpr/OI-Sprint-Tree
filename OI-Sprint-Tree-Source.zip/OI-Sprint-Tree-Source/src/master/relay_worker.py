"""Headless relay executable. No scores or scheduling decisions live here."""
import base64
import json
import os
from pathlib import Path
import queue
import re
import sys
import threading
import ctypes
import io
import msvcrt
from types import SimpleNamespace

import judge as J
from relay import WIRE


def main():
    # Windowless PyInstaller executables do not initialize Python's stdio wrappers.
    # Inherit only the explicit SSH/subprocess pipes, without allocating a console.
    if sys.stdin is None:
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.GetStdHandle.argtypes=[ctypes.c_ulong];kernel.GetStdHandle.restype=ctypes.c_void_p
        for name,handle,mode,flags in (('stdin',-10,'rb',os.O_RDONLY),('stdout',-11,'wb',os.O_WRONLY)):
            raw=kernel.GetStdHandle(handle & 0xffffffff)
            if not raw or raw==ctypes.c_void_p(-1).value:raise RuntimeError('副控启动缺少通信管道')
            stream=os.fdopen(msvcrt.open_osfhandle(raw,flags|os.O_BINARY),mode,buffering=0)
            setattr(sys,name,io.TextIOWrapper(stream,encoding='utf8',write_through=True))
    if "--upload-worker" in sys.argv:
        import transfer_worker
        return transfer_worker.main()
    root=Path(sys.argv[sys.argv.index("--relay-worker")+1]).resolve()
    init=json.loads(sys.stdin.buffer.readline())
    if init.get("protocol")!=WIRE or not re.fullmatch("[0-9a-f]{16}",init.get("version","")):
        raise ValueError("invalid relay protocol/version")
    if init.get("data") and not re.fullmatch(r"bundle_[0-9a-f]{16}\.tar\.gz",init.get("data","")):
        raise ValueError("invalid relay data path")
    for field,attribute,pattern in (('agent_name','AGENT_NAME',r'[A-Za-z0-9_-]+\.exe'),
                                    ('agent_protocol','PROTOCOL',r'OI-SPRINT-[A-Z-]+/1'),
                                    ('remote_subdir','REMOTE_SUBDIR',r'\.[a-z_]+'),
                                    ('local_subdir','LOCAL_SUBDIR',r'[a-z-]+')):
        if field in init:
            if not re.fullmatch(pattern,init[field]):raise ValueError('invalid runtime identity')
            setattr(J,attribute,init[field])
    payload=root/('payload_'+init["version"])
    judge=SimpleNamespace(payload=str(payload),payload_version=lambda:init["version"],
                          data_dirname=lambda:init["data_name"],data_bundle=lambda:str(root/init["data"]),
                          contest={} if init["contest"] else None,deploy_slots=threading.BoundedSemaphore(4))
    # Empty dict is false; downstream prepares need a truthy current-contest marker.
    if init["contest"]: judge.contest={"relay":True}
    output=queue.Queue(maxsize=8192)
    endpoints={}
    lock=threading.RLock()
    def emit(value):
        try:output.put_nowait(value)
        except queue.Full:
            # Never block a result callback holding the scheduler lock. Root will
            # requeue the disconnected leases; no unacknowledged result is final.
            os._exit(7)
    def writer():
        while True:
            message=output.get()
            if message is None: return
            batch=[message]
            while len(batch)<32:
                try:batch.append(output.get_nowait())
                except queue.Empty:break
            try:
                sys.stdout.buffer.write(b''.join((json.dumps(item,ensure_ascii=True)+"\n").encode('ascii') for item in batch))
                sys.stdout.buffer.flush()
            except (OSError,ValueError):os._exit(7)
    threading.Thread(target=writer,daemon=True).start()
    emit({"ready":WIRE})
    class Endpoint:
        def __init__(self,token,cfg):
            self.token,self.cfg=token,cfg
            self.commands=queue.Queue(maxsize=2048)
            self.conn=None
            self.alive=self.enabled=True
            self.judge=judge
            self.transfer=None
        def set_stage(self,stage,pct=0):
            emit({"type":"stage","id":self.token,"stage":stage,"pct":pct,"transfer":self.transfer})
        def enqueue(self,item):
            try:self.commands.put_nowait(item)
            except queue.Full:
                self.close()
                emit({'type':'error','id':self.token,'error':'副控命令积压，未完成任务将重排'})
        def sender(self):
            try:
                while self.alive:
                    data=self.commands.get()
                    if data is None:return
                    self.conn.send(data)
            except Exception:
                if self.conn:self.conn.close()
        def run(self):
            try:
                if self.cfg.get('gateway'):
                    from broker import Broker
                    def forward(line):emit({'type':'line','id':self.token,'data':base64.b64encode((line+'\n').encode('ascii')).decode('ascii')})
                    forward(f'HELLO 0 1 1 1 4096 1:{int(J.REFERENCE_SPEED)}:{int(J.REFERENCE_SPEED)} branch {J.PROTOCOL}')
                    self.conn=Broker(root,{**init,'scale':self.cfg.get('scale',init.get('scale',True))},forward)
                    self.conn.configure_workers(self.cfg.get('workers',[]))
                    while self.alive:
                        item=self.commands.get()
                        if item is None:break
                        if isinstance(item,dict):
                            if item['op']=='configure':self.conn.configure_workers(item['workers'])
                            elif item['op']=='data':self.conn.install(root/item['archive'])
                        else:
                            for line in item.decode('ascii').splitlines():self.conn.control(line)
                    return
                if self.cfg.get("local"):
                    conn=J.LocalConn(self,str(root/"local-worker"))
                else: conn=J.SSHConn(self,self.cfg)
                self.conn=conn
                conn.prepare()
                if not self.alive:return
                reader=conn.open()
                threading.Thread(target=self.sender,daemon=True).start()
                while self.alive:
                    raw=reader.readline()
                    if not raw:break
                    emit({"type":"line","id":self.token,"data":base64.b64encode(raw).decode("ascii")})
                if self.alive: raise RuntimeError("下属节点连接中断")
            except Exception as error:
                if self.alive: emit({"type":"error","id":self.token,"error":J._describe(error,self.cfg.get("password",""))})
            finally:
                self.close()
                with lock:endpoints.pop(self.token,None)
        def close(self):
            self.alive=self.enabled=False
            if self.conn:self.conn.close()
            try:self.commands.put_nowait(None)
            except queue.Full:pass
    try:
        for raw in sys.stdin.buffer:
            message=json.loads(raw);token=message.get("id")
            if message["op"]=="open":
                with lock:
                    if token in endpoints:raise ValueError("duplicate relay endpoint")
                    endpoint=endpoints[token]=Endpoint(token,message["cfg"])
                threading.Thread(target=endpoint.run,daemon=True).start()
            elif message["op"]=="send":
                with lock:endpoint=endpoints.get(token)
                if endpoint:endpoint.enqueue(base64.b64decode(message["data"]))
            elif message['op'] in ('configure','data'):
                with lock:endpoint=endpoints.get(token)
                if endpoint:
                    if message['op']=='data' and (Path(message['archive']).name!=message['archive'] or not message['archive'].startswith('assigned-')):
                        raise ValueError('invalid private data path')
                    endpoint.enqueue(message)
            elif message["op"]=="close":
                with lock:endpoint=endpoints.get(token)
                if endpoint:endpoint.close()
    finally:
        with lock:active=list(endpoints.values())
        for endpoint in active:endpoint.close()
    return 0


if __name__=="__main__":
    try:sys.exit(main())
    except Exception as error:
        try:
            import traceback
            root=Path(sys.argv[sys.argv.index('--relay-worker')+1])
            root.mkdir(parents=True,exist_ok=True)
            with (root/'worker-error.log').open('a',encoding='utf8') as log:log.write(traceback.format_exc()+'\n')
        except Exception:pass
        try:
            if sys.stdout is not None:
                sys.stdout.write(json.dumps({'error':str(error)[:300]})+'\n');sys.stdout.flush()
        except Exception:pass
        sys.exit(1)
