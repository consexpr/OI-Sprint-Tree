"""Separate Linux edition entry point. It never opens an existing Classic state folder."""
import os
from pathlib import Path
import sys
import tarfile
import threading
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import judge as J
import main as console

J.LINUX_MODE=True
J.PROTOCOL='OI-SPRINT-LINUX/1'


class LinuxJudge(J.Judge):
    def __init__(self,folder):
        self.linux_digest_lock=threading.Lock();self.linux_digests={}
        self.linux_source_lock=threading.Lock()
        super().__init__(folder)

    def prepare_task(self,node,task):
        connection=node.conn
        cid=self.data_dirname()
        pool=Path(self.state_dir)/'linux-data'/cid
        with self.linux_source_lock:
            marker=pool/'.complete'
            if not marker.is_file():
                pool.parent.mkdir(parents=True,exist_ok=True)
                with tarfile.open(self.data_bundle(),'r:gz') as archive:archive.extractall(pool.parent,filter='data')
                marker.write_text('ready')
        for test in task.tests:
            if task.cancelled or task.yielded:break
            for ext in ('.in','.ans'):
                connection.install_file(pool/(task.sub.prob+str(test)+ext),cid)

    def factory_reset(self):
        with self.lock:
            if self.resetting:raise ValueError('正在恢复出厂设置')
            self.resetting=True;self.running=False;self.epoch+=1;self.prepare_cancel.set()
            nodes=list(self.nodes.values())
        try:
            if self.prepare_thread and self.prepare_thread.is_alive():
                self.prepare_thread.join(10)
                if self.prepare_thread.is_alive():raise ValueError('正在停止比赛准备，请稍后重试')
            def reset_node(node):
                try:
                    if node.conn and node.stage=='online':node.conn.reset_data()
                    elif not node.local:return node.name()+'：节点离线，远端比赛数据未清理'
                except Exception as error:return node.name()+'：远端清理未完成（'+str(error)[:200]+'）'
                finally:node.shutdown()
            with ThreadPoolExecutor(max_workers=4) as pool:
                warnings=[message for message in pool.map(reset_node,nodes) if message]
            self.relays.close()
            for node in nodes:
                if node.thread:
                    node.thread.join(10)
                    if node.thread.is_alive():raise ValueError('正在停止节点连接，请稍后重试')
            with self.lock:
                if self.store:self.store.close()
                self.store=None;self.contest=None;self.preparing=None;self.nodes.clear();self.node_seq=0
                self.relays.configs.clear();self._reset([]);self.rev+=1
            for folder in (self.state_dir,self.export_dir):J.remove_managed_tree(self.app_dir,folder)
            os.makedirs(self.contests_dir,exist_ok=True)
            self.cpu_limit=100;self.linux_digests.clear();self.load_nodes()
            return {'ok':True,'warnings':warnings}
        finally:
            with self.lock:self.resetting=False;self.cv.notify_all()


console.J.Judge=LinuxJudge
console.APP_TITLE='OI-Sprint Linux'


def main():
    if '--app-dir' not in sys.argv:
        base=Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parents[2]/'build'/'oi-sprint-linux-dev'
        sys.argv.extend(['--app-dir',str(base)])
    if '--port' not in sys.argv:sys.argv.extend(['--port','8876'])
    return console.main()


if __name__=='__main__':raise SystemExit(main())
