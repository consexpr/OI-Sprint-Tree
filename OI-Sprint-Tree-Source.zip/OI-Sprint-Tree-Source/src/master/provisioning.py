"""Validate structured node forms without touching the network or exposing credentials."""
import discover


def integer(value, label, low, high, optional=False):
    if optional and value in (None, ""):
        return None
    if isinstance(value, bool):
        raise ValueError(label + "必须为整数")
    try:
        number = int(str(value))
    except (ValueError, TypeError):
        raise ValueError(label + "必须为整数") from None
    if not low <= number <= high:
        raise ValueError(f"{label}必须在 {low} 到 {high} 之间")
    return number


def configurations(data, judge):
    addresses = str(data.get("addresses", "")).strip()
    if not addresses:
        raise ValueError("请填写机器地址，一行一个，也支持 192.168.1.20-40")
    hosts = discover.expand(addresses)
    user = str(data.get("user", "")).strip()
    if not user or any(c in user for c in "\r\n\x00") or len(user) > 256:
        raise ValueError("请填写有效的 Windows 用户名")
    automatic = bool(getattr(judge, 'topology', None))
    role = data.get("role", "auto" if automatic else "worker")
    if role not in ("auto", "worker", "relay"):
        raise ValueError("请选择评测机或副控")
    parent = None if role == 'auto' else data.get("relay") or None
    if parent and parent not in judge.relays.configs:
        raise ValueError("选择的上级副控已不存在")
    if role == "relay" and parent:
        raise ValueError("当前副控部署接口暂只支持连接主控，下级副控尚未实现")
    auth = data.get("auth", "password")
    if auth not in ("password", "key", "agent"):
        raise ValueError("无效的认证方式")
    password = str(data.get("password", "")) if auth == "password" else ""
    key = str(data.get("key", "")).strip() if auth == "key" else ""
    if auth == "password" and not password:
        raise ValueError("密码为空；免密登录请选择 SSH 密钥或系统 SSH 认证")
    if auth == "key" and not key:
        raise ValueError("请填写私钥文件路径")
    if "\x00" in password or any(c in key for c in "\r\n\x00"):
        raise ValueError("认证信息含无效字符")
    common = dict(user=user, port=integer(data.get("port", 22), "SSH 端口", 1, 65535),
                  password=password, key=key, dir="", enabled=True, relay=parent,
                  slots=integer(data.get("slots"), "并发", 0, 1024, True),
                  cpu_limit=integer(data.get("cpu_limit"), "CPU 上限", 1, 100, True))
    common['auto_route'] = role == 'auto'
    return [{**common, "host": host} for host in hosts], role


def preview(data, judge):
    configs, role = configurations(data, judge)
    rows = []
    for cfg in configs:
        own_host=judge.is_master_host(cfg['host'])
        existing = next((n for n in list(judge.nodes.values()) if not n.local and not n.gateway
                         and (n.host, n.port, n.user) == (cfg["host"], cfg["port"], cfg["user"])), None)
        relay_exists = role == "relay" and any((r["host"], r["port"], r["user"]) ==
                                              (cfg["host"], cfg["port"], cfg["user"])
                                              for r in list(judge.relays.configs.values()))
        rows.append(dict(host=cfg["host"], port=cfg["port"], user=cfg["user"], role=role,
                         existing=bool(own_host or existing or relay_exists), id=existing.id if existing else None))
    return {"items": rows, "total": len(rows), "new": sum(not r["existing"] for r in rows)}


def add(data, judge):
    configs, role = configurations(data, judge)
    result = {"added": 0, "skipped": 0, "errors": [], "ids": []}
    for cfg, row in zip(configs, preview(data, judge)["items"]):
        if row["existing"]:
            result["skipped"] += 1
            continue
        try:
            if role == "relay":
                rid = judge.relays.add_config(cfg, str(data.get("name", "")))
                result["ids"].append(rid)
            else:
                result["ids"].append(judge.add_node(cfg).id)
            result["added"] += 1
        except Exception as error:
            # Do not echo a raw exception that might contain credentials.
            result["errors"].append({"host": cfg["host"], "error": "添加失败，请查看节点状态或重试"})
    return result
