"""Small Windows-side TLS integration check; does not pretend to execute Linux programs."""
import datetime
import hashlib
import json
from pathlib import Path
import socket
import ssl
import sys
import tempfile
import threading
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'src'/'master')]
from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID
from linux_agent import wire
from linux_connection import Connection
import judge


def main():
    with tempfile.TemporaryDirectory(dir=ROOT/'build',prefix='linux-tls-check-') as directory:
        folder=Path(directory);key=ec.generate_private_key(ec.SECP256R1())
        subject=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'transport-check')])
        now=datetime.datetime.now(datetime.timezone.utc)
        cert=(x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(key.public_key())
              .serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(minutes=1))
              .not_valid_after(now+datetime.timedelta(days=1)).sign(key,hashes.SHA256()))
        (folder/'cert.pem').write_bytes(cert.public_bytes(serialization.Encoding.PEM))
        (folder/'key.pem').write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(folder/'cert.pem',folder/'key.pem')
        listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen(2)
        errors=[];received=[];secret='temporary-integration-secret-123456789'
        source=folder/'p1.in';source.write_bytes(b'123456789\n'*20000)
        def service():
            try:
                raw,_=listener.accept()
                with context.wrap_socket(raw,server_side=True) as peer:
                    auth,_=wire.receive(peer);assert auth['token']==secret
                    wire.send(peer,{'op':'event','line':'HELLO 1 4 4 0 8192 1:0:0 isolate-cgroup2 OI-SPRINT-LINUX/1'})
                    cfg,_=wire.receive(peer);assert cfg=={'op':'configure','compile_limit':2,'cpu_limit':40,'bytes':0}
                    wire.send(peer,{'op':'event','line':'CONFIG_OK 40'})
                    offer,_=wire.receive(peer);rid=offer['request'];assert offer['size']==source.stat().st_size
                    wire.send(peer,{'op':'offered','request':rid,'needed':True})
                    content=bytearray()
                    while True:
                        message,payload=wire.receive(peer)
                        if message['op']=='commit':break
                        assert message['op']=='chunk';content.extend(payload)
                    assert hashlib.sha256(content).hexdigest()==offer['sha256']
                    assert content==source.read_bytes();received.append(len(content))
                    wire.send(peer,{'op':'committed','request':rid})
                    try:wire.receive(peer)
                    except (EOFError,OSError):pass
                raw,_=listener.accept()
                try:
                    with context.wrap_socket(raw,server_side=True) as peer:
                        try:wire.receive(peer)
                        except (EOFError,OSError):received.append('pin-rejected-before-auth')
                except OSError:
                    # A client rejecting the pin may close during the server's TLS ticket write.
                    raw.close();received.append('pin-rejected-before-auth')
            except BaseException as error:errors.append(error)
            finally:listener.close()
        thread=threading.Thread(target=service,daemon=True);thread.start()
        profiles=folder/'linux-connections';profiles.mkdir()
        profile={'host':'127.0.0.1','port':listener.getsockname()[1],'token_sealed':judge.protect(secret),
                 'fingerprint':cert.fingerprint(hashes.SHA256()).hex()}
        path=profiles/'1.json';path.write_text(json.dumps(profile))
        root=SimpleNamespace(state_dir=str(folder),linux_digest_lock=threading.Lock(),linux_digests={})
        node=SimpleNamespace(id=1,judge=root,set_stage=lambda *a:None)
        conn=Connection(node);conn.prepare()
        assert conn.readline().startswith(b'HELLO ')
        conn.send(b'CONFIG 2 40\n');assert conn.readline()==b'CONFIG_OK 40\n'
        conn.install_file(source,'data_fixture');conn.install_file(source,'data_fixture')
        conn.close()
        path.write_text(json.dumps({**profile,'fingerprint':'0'*64}))
        wrong=Connection(node)
        try:wrong.prepare()
        except ssl.SSLError:pass
        else:raise AssertionError('incorrect certificate pin accepted')
        finally:wrong.close()
        thread.join(5)
        assert not thread.is_alive() and not errors,(thread.is_alive(),errors,received)
        assert received==[source.stat().st_size,'pin-rejected-before-auth'],received
    print('PASS TLS authentication, framed configuration, verified file transfer, local reuse, certificate pin rejection')
    print('This checks transport only; real WSL2/Isolate execution is not verified here.')


if __name__=='__main__':main()
