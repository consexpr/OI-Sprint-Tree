"""Sidecar predeployment for new nodes; never controls or restarts the live master."""
from concurrent.futures import ThreadPoolExecutor
import json
import os
import socket
import sys
import threading
import time
from types import SimpleNamespace
import urllib.request
import uuid

if not getattr(sys, "frozen", False):
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "master"))
import judge as J

PRINT_LOCK = threading.Lock()
JOURNAL_LOCK = threading.Lock()
PENDING_STAGES = {"connecting", "waiting_upload", "uploading"}


def post(base, route, data):
    request = urllib.request.Request(base + route, json.dumps(data).encode("utf8"),
                                     {"X-Judge": "1", "Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=20) as response:
        return json.load(response)


def same_node(node, cfg):
    return not node.get("local") and not cfg.get("local") and (node["host"], node["user"], node["port"]) == (
        cfg["host"], cfg["user"], cfg.get("port") or 22)


def journal_path(app):
    return os.path.join(app, "OI-Sprint-Deploy-Assist-Recovery.json")


def save_journal(app, journal):
    with JOURNAL_LOCK:
        path = journal_path(app)
        with open(path + ".tmp", "w", encoding="utf8") as f:
            json.dump(journal, f, ensure_ascii=False, indent=1)
            f.flush()
            os.fsync(f.fileno())
        os.replace(path + ".tmp", path)


def credentials(raw):
    cfg = dict(raw)
    cfg["password"] = J.unprotect(cfg.get("password_sealed", ""))
    if cfg["password"] is None:
        raise ValueError(f"{cfg['host']} 的密码无法解密，请用运行原主控的同一 Windows 用户打开辅助程序")
    for key in ("user", "host", "password", "dir", "key"):
        if any(c.isspace() for c in cfg.get(key, "")):
            raise ValueError(f"{cfg['host']} 的连接参数含空白，旧主控接口无法无损恢复，未进行接管")
    return cfg


def node_text(cfg, slots=0):
    parts = [f"{cfg['user']}@{cfg['host']}:{cfg.get('port') or 22}", f"slots:{slots}"]
    parts += [f"{key}:{cfg[key]}" for key in ("password", "dir", "key") if cfg.get(key)]
    return " ".join(parts)


def restore_entry(app, base, journal, entry):
    cfg = credentials(entry["original"])
    live = state(base)
    if not live.get("contest") or live["contest"]["id"] != journal["contest"]:
        raise RuntimeError("比赛已改变，停止自动恢复；原节点配置保存在恢复文件中")
    if entry.get("prepared"):
        cfg["dir"] = entry["directory"]
    matches = [n for n in live["nodes"] if same_node(n, cfg)]
    if matches:
        node = matches[0]
        if node["id"] not in (entry["old_id"], entry.get("new_id")):
            if entry["phase"] == "restoring" and not node["inflight"] and not node["slots"] and node["dir"] == cfg.get("dir", ""):
                entry["new_id"] = node["id"]
            else:
                raise RuntimeError("节点已被其他操作重新添加，未覆盖其设置")
    else:
        entry["phase"] = "restoring"
        save_journal(app, journal)
        post(base, "/api/nodes/add", {"text": node_text(cfg)})
        node = next(n for n in state(base)["nodes"] if same_node(n, cfg))
        entry["new_id"] = node["id"]
        save_journal(app, journal)
    post(base, "/api/nodes/update", {"id": node["id"], "cpu_limit": cfg.get("cpu_limit")})
    slots = cfg.get("slots")
    if slots is None:
        deadline = time.monotonic() + 40
        while time.monotonic() < deadline:
            node = next(n for n in state(base)["nodes"] if n["id"] == node["id"])
            if node.get("recommended") is not None:
                slots = node["recommended"]
                break
            time.sleep(.5)
        if slots is None:
            entry["phase"] = "awaiting_recommended"
            save_journal(app, journal)
            say(cfg["host"] + " 已接回主控，并发暂留 0；上线后用模式 3 恢复自动推荐并发")
            return False
    post(base, "/api/nodes/update", {"id": node["id"], "slots": slots})
    entry["phase"] = "restored"
    save_journal(app, journal)
    say(cfg["host"] + " 已接回原主控并恢复并发和 CPU 设置")
    return True


def recover(app, base):
    with open(journal_path(app), encoding="utf8") as f:
        journal = json.load(f)
    for entry in journal["nodes"]:
        if entry["phase"] not in ("planned", "restored", "unchanged"):
            restore_entry(app, base, journal, entry)


def takeover(app, base, ids):
    live = state(base)
    if not live.get("contest") or live.get("preparing") or live.get("resetting"):
        raise ValueError("当前比赛正在切换或未准备好，未接管任何节点")
    if os.path.exists(journal_path(app)):
        with open(journal_path(app), encoding="utf8") as f:
            previous = json.load(f)
        if any(e["phase"] not in ("planned", "restored", "unchanged") for e in previous["nodes"]):
            raise ValueError("有上次未恢复的节点，请先选择模式 3 恢复")
    selected = [n for n in live["nodes"] if n["id"] in ids]
    if len(selected) != len(set(ids)):
        raise ValueError("选择的节点不存在")
    with open(os.path.join(app, "state", "nodes.json"), encoding="utf8") as f:
        saved = json.load(f)
    entries = []
    for node in selected:
        if node["local"] or not node["enabled"] or node["stage"] not in PENDING_STAGES or node["inflight"]:
            raise ValueError(f"节点 {node['id']} 不是等待连接/上传的空闲远端节点，未进行接管")
        raw = next(c for c in saved if same_node(node, c))
        cfg = credentials(raw)
        ips = addresses(cfg["host"])
        if any(not n["local"] and n["id"] != node["id"] and ips & addresses(n["host"]) for n in live["nodes"]):
            raise ValueError(f"{cfg['host']} 有其他节点指向同一台机器，未进行接管")
        entries.append({"old_id": node["id"], "original": raw, "phase": "planned", "directory": None,
                        "new_id": None, "prepared": False})
    journal = {"contest": live["contest"]["id"], "nodes": entries}
    save_journal(app, journal)

    def handle(entry):
        cfg = credentials(entry["original"])
        try:
            # Use a separate remote root: an old extraction may finish after its SSH
            # channel closes, so never deploy over the files it could still be writing.
            probe = J.SSHConn(SimpleNamespace(set_stage=lambda *args: None), cfg)
            try:
                sftp = probe._connect()
                directory = probe.sftp_dir.rsplit("/", 1)[0] + "/.upload_assist_" + uuid.uuid4().hex[:8]
                sftp.close()
            finally:
                probe.close()
            cfg["dir"] = directory.lstrip("/")
            if any(c.isspace() for c in cfg["dir"]):
                raise ValueError("远端目录含空白，旧主控接口无法无损接回，未进行接管")
            entry["directory"] = cfg["dir"]
            now = state(base)
            if not now.get("contest") or now["contest"]["id"] != journal["contest"]:
                raise RuntimeError("比赛已切换，未进行接管")
            node = next(n for n in now["nodes"] if n["id"] == entry["old_id"])
            if node["stage"] not in PENDING_STAGES or node["inflight"]:
                entry["phase"] = "unchanged"
                save_journal(app, journal)
                say(cfg["host"] + " 已开始评测或完成上传，保持原连接")
                return
            entry["phase"] = "limiting"
            save_journal(app, journal)
            post(base, "/api/nodes/update", {"id": node["id"], "slots": 0})
            node = next(n for n in state(base)["nodes"] if n["id"] == entry["old_id"])
            # slots=0 prevents any new tasks. If the upload finished meanwhile, leave
            # its connection intact and restore its capacity without killing a task.
            if node["stage"] not in PENDING_STAGES or node["inflight"]:
                restore_entry(app, base, journal, entry)
                return
            entry["phase"] = "detaching"
            save_journal(app, journal)
            post(base, "/api/nodes/remove", {"id": node["id"]})
            entry["phase"] = "removed"
            save_journal(app, journal)
            say(cfg["host"] + " 旧上传已断开，其他节点继续评测")
            result = prepare_new(app, base, [cfg], allow_local=True, reconnecting=True)
            entry["prepared"] = bool(result["ready"])
            save_journal(app, journal)
        except Exception as error:
            say(cfg["host"] + " 接管未完成：" + J._describe(error, cfg.get("password", "")))
        finally:
            if entry["phase"] not in ("planned", "unchanged", "restored"):
                try:
                    restore_entry(app, base, journal, entry)
                except Exception as error:
                    say(cfg["host"] + " 自动恢复未完成：" + str(error) + "；请使用模式 3，原配置已加密留存")

    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(handle, entries))
    return journal


def say(message):
    with PRINT_LOCK:
        print(message, flush=True)


def state(base):
    with urllib.request.urlopen(base + "/api/state?since=999999999999", timeout=20) as response:
        return json.load(response)


def addresses(host):
    return {item[4][0] for item in socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)}


def prepare_new(app, base, configs, allow_local=False, reconnecting=False):
    snapshot = state(base)
    current = snapshot.get("contest")
    if not current or snapshot.get("preparing") or snapshot.get("resetting"):
        raise ValueError("主控尚未准备好当前比赛，请在现有比赛正常运行时使用辅助程序")
    cid = current["id"]
    if len(cid) != 16 or any(c not in "0123456789abcdef" for c in cid):
        raise ValueError("比赛标识无效")
    with open(os.path.join(app, "state", "contests", cid, "contest.json"), encoding="utf8") as f:
        contest = json.load(f)
    bundle = os.path.join(app, "state", "contests", cid, "data.tar.gz")
    payload = os.path.join(app, "payload")
    with open(os.path.join(payload, "version.txt"), encoding="utf8") as f:
        version = f.read().strip()
    if not all(os.path.isfile(path) for path in (bundle, os.path.join(payload, "runtime.tar.gz"),
                                                os.path.join(payload, J.AGENT_NAME))):
        raise ValueError("缺少节点载荷或当前比赛数据包")
    existing = set()
    for node in snapshot["nodes"]:
        if not node["local"]:
            existing.update(addresses(node["host"]))
    if not allow_local:
        existing.update(addresses(socket.gethostname()))
        existing.update(("127.0.0.1", "::1"))
    seen, ready, failed = set(), [], []
    for cfg in configs:
        ips = addresses(cfg["host"])
        if ips & existing:
            raise ValueError(f"{cfg['host']} 已在主控中或是主控本机，拒绝接管，避免影响现有评测")
        if ips & seen:
            raise ValueError(f"{cfg['host']} 重复，请每台机器只填写一次")
        seen.update(ips)

    judge = SimpleNamespace(payload=payload, contest=contest, payload_version=lambda: version,
                            data_dirname=lambda: "data_" + cid, data_bundle=lambda: bundle,
                            deploy_slots=threading.BoundedSemaphore(4))

    class Node:
        alive = enabled = True
        transfer = None

        def __init__(self, cfg):
            self.judge = judge
            self.host = cfg["host"]
            self.last = 0
            self.previous = ""

        def set_stage(self, stage, pct=0):
            now = time.monotonic()
            if stage == self.previous and stage == "uploading" and now - self.last < 2 and pct != 100:
                return
            self.previous, self.last = stage, now
            label = {"connecting": "连接", "waiting_upload": "等待上传", "uploading": "上传",
                     "extracting": "解压"}.get(stage, stage)
            detail = ""
            if stage == "uploading" and self.transfer:
                t = self.transfer
                detail = f" {pct}%  {t['done']/1048576:.0f}/{t['total']/1048576:.0f} MB  {t['rate']/1048576:.1f} MB/s"
            say(self.host + "  " + label + detail)

    class Predeploy(J.SSHConn):
        def _cleanup_remote(self, keep=None, clear_cache=False):
            pass  # Sidecar deployment never removes old data or caches.

        def _exec(self, command, timeout=600):
            if "tar -xzf" in command:
                live = state(base)
                if not live.get("contest") or live["contest"]["id"] != cid:
                    raise RuntimeError("比赛已切换，已停止部署此节点")
                for node in live["nodes"]:
                    if not node["local"] and addresses(node["host"]) & addresses(self.cfg["host"]):
                        raise RuntimeError("该机器已被加入主控，辅助程序停止接管")
            return super()._exec(command, timeout)

    def deploy(cfg):
        conn = Predeploy(Node(cfg), cfg)
        try:
            conn.prepare()
            say(cfg["host"] + ("  预部署完成，正在接回主控" if reconnecting else "  预部署完成，可加入原主控"))
            ready.append(cfg["host"])
        except Exception as error:
            say(cfg["host"] + "  失败：" + J._describe(error, cfg.get("password", "")))
            failed.append(cfg["host"])
        finally:
            conn.close()

    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(deploy, configs))
    return {"ready": ready, "failed": failed}


def main():
    if "--upload-worker" in sys.argv:
        import transfer_worker
        return transfer_worker.main()
    app = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.abspath(sys.argv[1])
    print("OI-Sprint 在线部署辅助程序 v2\n不重启主控，不暂停整场评测，不终止正在执行的提交。\n"
          "接管期间不要在网页上手动增删或修改选中的节点。\n"
          "请将本程序放到正在运行的 OI-Sprint-Classic.exe 旁边。", flush=True)
    mutex = None
    try:
        import ctypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
        kernel.CreateMutexW.restype = ctypes.c_void_p
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel.ReleaseMutex.argtypes = [ctypes.c_void_p]
        mutex = kernel.CreateMutexW(None, True, "Local\\OI-Sprint-Deploy-Assist-v2")
        if not mutex or ctypes.get_last_error() == 183:
            raise ValueError("另一个辅助程序正在工作，请先等待它完成")
        port = int(input("当前主控端口 [8987]：").strip() or "8987")
        base = f"http://127.0.0.1:{port}"
        mode = input("1 预部署新机器；2 接管已有上传节点；3 恢复上次节点设置 [2]：").strip() or "2"
        if mode == "3":
            recover(app, base)
            return 0
        if mode == "2":
            candidates = [n for n in state(base)["nodes"] if not n["local"] and n["enabled"]
                          and n["stage"] in PENDING_STAGES and not n["inflight"]]
            if not candidates:
                print("没有可接管的上传/连接节点；已在线评测的节点保持原样。", flush=True)
                return 0
            for node in candidates:
                print(f"{node['id']:>4}  {node['user']}@{node['host']}  {node['stage']}  {node['pct']}%", flush=True)
            value = input("输入要接管的编号，逗号分隔；all 表示上述全部；空行取消：").strip()
            if not value:
                return 0
            ids = [n["id"] for n in candidates] if value.lower() == "all" else [int(v.strip()) for v in value.split(",")]
            takeover(app, base, ids)
            print("本轮接管结束；如有恢复未完成提示，保留恢复文件并使用模式 3。", flush=True)
            return 0
        if mode != "1":
            raise ValueError("模式只能是 1、2 或 3")
        print("粘贴新机器地址，格式与原主控相同，每行一台；空行开始。", flush=True)
        lines = []
        while True:
            line = input().strip()
            if not line:
                break
            lines.append(line)
        configs, errors = J.parse_nodes("\n".join(lines), None)
        if errors or not configs:
            raise ValueError("节点格式错误或未填写节点")
        result = prepare_new(app, f"http://127.0.0.1:{port}", configs)
        print(f"完成 {len(result['ready'])} 台，失败 {len(result['failed'])} 台。\n"
              "现在将成功的节点添加到原主控即可；工具链和比赛数据会直接复用。", flush=True)
        return 0 if not result["failed"] else 1
    except Exception as error:
        print("未完成：" + str(error), flush=True)
        return 1
    finally:
        if mutex:
            kernel.ReleaseMutex(mutex)
            kernel.CloseHandle(mutex)
        try:
            input("按回车关闭辅助程序，原主控继续运行。")
        except EOFError:
            pass


if __name__ == "__main__":
    sys.exit(main())
