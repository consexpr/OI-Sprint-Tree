"""Streaming, offline rejudging of suspect points in an OI-Sprint HTML export."""
import argparse
import base64
from collections import Counter
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import queue
import re
import shutil
import sqlite3
import subprocess
import sys
import tarfile
import threading
import time
import uuid

if hasattr(sys.stdout, "reconfigure") and not sys.stdout.isatty():
    sys.stdout.reconfigure(encoding="utf8")

if not getattr(sys, "frozen", False):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "master"))
import contest as C
import scan
import ijson

REFERENCE_SPEED = 925919.0
CHAR = {"AC": "A", "WA": "W", "TLE": "T", "MLE": "M", "RE": "R", "NOF": "N", "OLE": "O", "SE": "S"}
NODE = "0.0.0.0"


def say(text):
    print(text, flush=True)


def json_text(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/").replace("<!--", "\\u003c!--")


class JsonRange(io.RawIOBase):
    def __init__(self, path, start, end):
        self.file = open(path, "rb")
        self.start, self.end = start, end
        self.file.seek(start)
        self.pending = b""
        self.tail = b""
        self.finished = False

    def read(self, size=-1):
        if size == 0:
            return b""
        # Older exports used the JS-only escape <\!-- inside source strings.
        # Normalize it in the parser stream only; never change the source report.
        pattern = b"<\\!--"
        while not self.finished and (size < 0 or len(self.pending) < size):
            remaining = self.end - self.file.tell()
            chunk = self.file.read(min(65536, remaining))
            data = self.tail + chunk
            self.finished = not chunk or self.file.tell() >= self.end
            keep = 0
            if not self.finished:
                for n in range(1, len(pattern)):
                    if data.endswith(pattern[:n]):
                        keep = n
            stable = data[:-keep] if keep else data
            self.tail = data[-keep:] if keep else b""
            self.pending += stable.replace(pattern, b"\\u003c!--")
        take = len(self.pending) if size < 0 else min(size, len(self.pending))
        value, self.pending = self.pending[:take], self.pending[take:]
        return value

    def readinto(self, buffer):
        chunk = self.read(len(buffer))
        buffer[:len(chunk)] = chunk
        return len(chunk)

    def readable(self):
        return True

    def close(self):
        self.file.close()
        super().close()


def locate_json(path):
    # Our exports write JSON on one line: newlines in source strings are escaped.
    # Locate its byte bounds without loading that potentially multi-GB line.
    with open(path, "rb") as f:
        head = f.read(1024 * 1024)
        match = re.search(rb"(?m)^\s*const EXPORT\s*=\s*", head)
        if not match or head[match.end():match.end() + 1] != b"{":
            raise ValueError("这不是包含成绩和源码的 OI-Sprint 导出 HTML")
        start = match.end()
        f.seek(start)
        tick = time.monotonic()
        size = os.path.getsize(path)
        while True:
            position = f.tell()
            chunk = f.read(1024 * 1024)
            if not chunk:
                raise ValueError("报告数据行不完整")
            newline = chunk.find(b"\n")
            if newline >= 0:
                line_end = position + newline
                break
            if time.monotonic() - tick > 1:
                say(f"定位报告数据：{f.tell()*100/max(size,1):.1f}%")
                tick = time.monotonic()
        f.seek(max(start, line_end - 128))
        tail = f.read(line_end - f.tell()).rstrip(b"\r \t")
        if not tail.endswith(b"};"):
            raise ValueError("报告格式不支持：导出的 JSON 应完整保存在一行中")
        end = line_end - (line_end - max(start, line_end - 128) - len(tail)) - 1
        return start, end


def metadata(path, bounds):
    result = {}
    with JsonRange(path, *bounds) as source:
        builder, key, depth = None, None, 0
        for prefix, event, value in ijson.parse(source, use_float=True):
            if prefix == "" and event == "map_key":
                if value in ("rows", "status", "subs"):
                    break
                key, builder, depth = value, ijson.common.ObjectBuilder(), 0
                continue
            if builder is not None:
                builder.event(event, value)
                depth += (1 if event in ("start_map", "start_array") else -1 if event in ("end_map", "end_array") else 0)
                if depth == 0:
                    result[key] = builder.value
                    builder = None
    if not result.get("problems") or "name" not in result:
        raise ValueError("报告缺少比赛名称或题目设置")
    for p in result["problems"]:
        if not C._VALID_ID.fullmatch(p["id"]) or p["tests"] < 1 or p["tl"] <= 0:
            raise ValueError("报告中的题目设置无效")
    return result


def summary(sub, problem):
    tests = {t[0]: t for t in sub["tests"]}
    score = sum(t[7] for t in tests.values())
    if sub.get("compile") and sub["compile"][0] == "CE":
        strip = "C" * problem["tests"]
    elif sub["state"] == "held" and not any(t[1] for t in tests.values()):
        strip = "H" * problem["tests"]
    else:
        fill = "K" if sub["state"] == "skipped" else "."
        strip = "".join(CHAR.get(tests.get(i, [0, None])[1], fill) for i in range(1, problem["tests"] + 1))
    return score, strip


def index_report(path, bounds, meta, db, mode="tle"):
    db.executescript("CREATE TABLE subs(id INTEGER PRIMARY KEY, key TEXT UNIQUE, sid TEXT, prob TEXT, raw TEXT, selected TEXT, score INT, strip TEXT);"
                     "CREATE INDEX students ON subs(sid,prob);")
    db.execute("CREATE TABLE excluded(sid TEXT,prob TEXT,state TEXT,reasons TEXT)")
    problems = {p["id"]: p for p in meta["problems"]}
    count, selected, groups, checked, statuses = 0, 0, 0, 0, Counter()
    wa_detected, excluded = 0, 0
    wanted = set()
    tick = time.monotonic()
    with JsonRange(path, *bounds) as source:
        for key, sub in ijson.kvitems(source, "subs", use_float=True):
            p = problems[sub["prob"]]
            if key != f"{sub['sid']}/{sub['prob']}" or len(sub["tests"]) != p["tests"]:
                raise ValueError("报告中的提交/测点编号不完整：" + key)
            active = sub["state"] not in ("held", "skipped")
            excluded += not active
            if not active:
                db.execute("INSERT INTO excluded VALUES(?,?,?,?)", (sub["sid"],sub["prob"],sub["state"],json.dumps(sub.get("reasons",[]),ensure_ascii=False)))
            ce = sub.get("compile") and sub["compile"][0] == "CE"
            targets = []
            seen = set()
            for t in sub["tests"]:
                if len(t) < 8 or t[0] in seen or not 1 <= t[0] <= p["tests"]:
                    raise ValueError("报告中的测点格式无效：" + key)
                seen.add(t[0])
                checked += 1
                if active and not ce and t[1]:
                    statuses[t[1]] += 1
                # A point already verified on this repair node does not need another pass.
                if active and (mode == "full" or (not ce and t[6] != NODE)):
                    suspect = mode == "full" or (t[1] == "TLE" and 0 <= t[2] < p["tl"])
                    if t[1] == "WA":
                        wa_detected += 1
                    if suspect:
                        targets.append(t[0])
                        wanted.add((p["id"], t[0]))
            if active and ce:
                statuses["CE"] += p["tests"]
            score, strip = summary(sub, p)
            db.execute("INSERT INTO subs(key,sid,prob,raw,selected,score,strip) VALUES(?,?,?,?,?,?,?)",
                       (key, sub["sid"], sub["prob"], json.dumps(sub, ensure_ascii=False, separators=(",", ":")), json.dumps(targets), score, strip))
            count += 1
            selected += len(targets)
            groups += bool(targets)
            if count % 256 == 0:
                db.commit()
            if time.monotonic() - tick > 1:
                pct = (source.file.tell() - bounds[0]) * 100 / max(1, bounds[1] - bounds[0])
                say(f"自动扫描 {pct:.1f}%：已读 {checked:,} 点，需复核 {selected:,} 点")
                tick = time.monotonic()
    groups = db.execute("SELECT COUNT(*) FROM subs WHERE selected!='[]'").fetchone()[0]
    db.commit()
    say(f"扫描完成：{checked:,} 个测点，自动选出 {selected:,} 个，涉及 {groups:,} 份提交")
    if not count:
        raise ValueError("报告不包含可恢复的提交源码")
    say("节点范围：全部；完整复核包含 AC、WA、TLE、CE 等原判定" if mode == "full" else "节点范围：全部；WA 不重测")
    return wanted, statuses, {"scanned": checked, "selected": selected, "groups": groups,
                              "wa_detected": wa_detected, "wa_selected": wa_detected if mode == "full" else 0,
                              "nodes": "all", "mode": mode, "excluded_submissions": excluded}


def current_data(meta, html, app):
    for base in dict.fromkeys((app, html.parent, html.parent.parent)):
        try:
            cid = (base / "state/current.txt").read_text(encoding="utf8").strip()
            if not re.fullmatch("[0-9a-f]{16}", cid):
                continue
            folder = base / "state/contests" / cid
            cfg = json.loads((folder / "contest.json").read_text(encoding="utf8"))
            fields = ("id", "tl", "ml", "tests", "full")
            same = cfg["name"] == meta["name"] and [[p[k] for k in fields] for p in cfg["problems"]] == [[p[k] for k in fields] for p in meta["problems"]]
            if same and (folder / "data.tar.gz").is_file():
                return folder / "data.tar.gz", cfg.get("scale", True), cid
        except (OSError, ValueError, KeyError):
            pass
    return None, None, None


def stage_data(data, target, wanted, problems):
    target.mkdir(parents=True)
    names = {f"{p}{t}{extension}" for p, t in wanted for extension in (".in", ".ans")}
    if len(names) != len(wanted) * 2:
        raise ValueError("不同题目的规范测点文件名发生冲突，不能安全重测")
    copied = set()
    if data.is_file():
        with tarfile.open(data, "r:gz") as archive:
            for member in archive:
                name = member.name.replace("\\", "/").rsplit("/", 1)[-1]
                if name in names and member.isfile():
                    if name in copied:
                        raise ValueError("数据包包含重名测点：" + name)
                    with archive.extractfile(member) as src, open(target / name, "wb") as dst:
                        shutil.copyfileobj(src, dst)
                    copied.add(name)
    else:
        groups = C.scan_data(str(data), [p["id"] for p in problems])
        for p in problems:
            if any(prob == p["id"] for prob, _ in wanted) and len(groups.get(p["id"], [])) != p["tests"]:
                raise ValueError(p["id"] + " 的数据测点数与报告不一致，请选择原比赛数据")
        for p, t in sorted(wanted):
            inp, ans = groups[p][t - 1]
            for source, ext in ((inp, ".in"), (ans, ".ans")):
                name = f"{p}{t}{ext}"
                shutil.copyfile(source, target / name)
                copied.add(name)
    missing = names - copied
    if missing:
        raise ValueError("缺少测试输入或标准答案：" + ", ".join(sorted(missing)[:8]))
    say(f"已准备 {len(wanted):,} 个不同测点的数据；其他测点不执行")


class LocalAgent:
    def __init__(self, root, agent):
        self.proc = subprocess.Popen([str(agent), "serve", str(root), "data"], stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)
        self.messages = queue.Queue()
        def reader():
            for line in self.proc.stdout:
                self.messages.put(line.decode("ascii", "replace").strip())
            self.messages.put(None)
        threading.Thread(target=reader, daemon=True).start()
        try:
            self.handshake()
        except BaseException:
            self.close()
            raise

    def handshake(self):
        deadline = time.monotonic() + 90
        while True:
            line = self.line(deadline)
            if not line:
                say("本机评测器正在初始化、检查工具链和测速……")
            if line.startswith("HELLO "):
                a = line.split()
                speed = float(a[6].split(",")[0].split(":")[1])
                self.factor = min(4.0, max(.5, REFERENCE_SPEED / speed)) if speed > 0 else 1.0
                break
        self.send("CONFIG 1 100")
        deadline = time.monotonic() + 10
        while not self.line(deadline).startswith("CONFIG_OK "):
            pass

    def send(self, message):
        self.proc.stdin.write(message.encode("ascii") + b"\n")
        self.proc.stdin.flush()

    def line(self, deadline):
        try:
            line = self.messages.get(timeout=max(.01, min(5, deadline - time.monotonic())))
        except queue.Empty:
            if time.monotonic() >= deadline:
                raise TimeoutError("本机评测进程长时间未返回")
            return ""
        if line is None:
            raise RuntimeError("本机评测进程已退出")
        if line.startswith("FATAL "):
            raise RuntimeError(base64.b64decode(line.split()[1]).decode("utf8", "replace"))
        return line

    def close(self):
        if self.proc.poll() is None:
            self.proc.kill()
        self.proc.wait(10)
        self.proc.stdin.close()
        self.proc.stdout.close()


def rerun(db, meta, agent, statuses, info, log, scale=True, batch_size=0):
    problems = {p["id"]: p for p in meta["problems"]}
    factor = info.get("factor", agent.factor) if scale else 1.0
    for key in ("rerun", "changed", "failed"):
        info.setdefault(key, 0)
    info.update(interrupted=False, node=NODE, scale=scale, factor=factor)
    full = info.get("mode") == "full"
    say(f"本机串行复核，时限倍率 {factor:.3f}；复核节点标记 {NODE}")
    log.writerow(("考号", "题目", "测点", "原结果", "新结果", "原CPU毫秒", "新CPU毫秒", "折算墙钟毫秒", "说明"))
    last = 0
    started = last_progress = time.monotonic()
    previous_elapsed = info.get("elapsed_seconds", 0)
    processed = 0
    try:
        while True:
            row = db.execute("SELECT id,raw,selected FROM subs WHERE id>? AND selected!='[]' ORDER BY id LIMIT 1", (last,)).fetchone()
            if row is None:
                break
            last, raw, selected = row
            sub, targets = json.loads(raw), json.loads(selected)
            p = problems[sub["prob"]]
            points = C.points_for(p["full"], p["tests"])
            rewritten, changed = scan.rewrite_long(sub["code"])
            if changed and scan.lp64_risks(sub['code']):
                raise ValueError(f"{sub['sid']} / {p['id']}：LP64 动态格式串无法安全自动转换，原成绩保留")
            flags = (1 if "_unlocked" in sub["code"] else 0) | (2 if changed else 0)
            wire = base64.b64encode(rewritten.encode("utf8")).decode() or "-"
            tl = max(1, round(p["tl"] * factor))
            agent.send(f"TASK {last} {p['id']} {tl} {p['ml']} {flags} {','.join(map(str, targets))} {wire}")
            remaining, by_test, error = set(targets), {t[0]: t for t in sub["tests"]}, ""
            completed = set()
            old_ce = bool(sub.get("compile") and sub["compile"][0] == "CE")
            original_status = {t: "CE" if old_ce else by_test[t][1] for t in targets}
            deadline = time.monotonic() + 100 + len(targets) * (max(30000, tl * 10 + 5000) / 1000 + 5)
            try:
                while True:
                    line = agent.line(deadline)
                    if not line:
                        say(f"复核 {info['rerun']:,}/{info['selected']:,}：{sub['sid']} / {p['id']}，正在编译或执行")
                        continue
                    a = line.split()
                    if a[0] == "COMPILE" and int(a[1]) == last:
                        detail = base64.b64decode(a[4]).decode("utf8", "replace") if a[4] != "-" else ""
                        if a[2] != "OK":
                            error = detail or a[2]
                        if full and a[2] in ("OK", "CE"):
                            if old_ce:
                                statuses["CE"] -= p["tests"]
                                for test, old in by_test.items():
                                    old[:] = [test, None, 0, 0, 0, "", "", 0]
                                old_ce = False
                            if a[2] == "CE":
                                # A fresh compiler rejection is a completed rejudge,
                                # unlike an infrastructure failure (SE).
                                for test, old in by_test.items():
                                    if old[1]:
                                        statuses[old[1]] -= 1
                                    if test in remaining:
                                        info["rerun"] += 1
                                        info["changed"] += original_status[test] != "CE"
                                        log.writerow((sub["sid"], p["id"], test, original_status[test], "CE", old[2], "", "", detail))
                                    old[:] = [test, None, 0, 0, 0, "", NODE, 0]
                                statuses["CE"] += p["tests"]
                                completed.update(targets)
                                remaining.clear()
                            sub["compile"] = [a[2], int(a[3]), detail]
                            sub["rewritten"] = changed
                            sub["state"] = "done"
                            sub["running_tests"] = []
                    elif a[0] == "TEST" and int(a[1]) == last:
                        test, verdict = int(a[2]), a[3]
                        if test not in remaining:
                            raise RuntimeError("评测器返回了未请求或重复的测点")
                        remaining.remove(test)
                        old = list(by_test[test])
                        detail = base64.b64decode(a[7]).decode("utf8", "replace") if a[7] != "-" else ""
                        cpu, wall, mem = round(int(a[4]) / factor), round(int(a[5]) / factor), int(a[6])
                        if verdict not in CHAR or verdict == "SE":
                            info["failed"] += 1
                            log.writerow((sub["sid"], p["id"], test, old[1], "保留原结果", old[2], cpu, wall, detail))
                        else:
                            new = [test, verdict, cpu, wall, mem, detail, NODE, points[test - 1] if verdict == "AC" else 0]
                            by_test[test][:] = new
                            if old[1]:
                                statuses[old[1]] -= 1
                            statuses[verdict] += 1
                            info["rerun"] += 1
                            completed.add(test)
                            info["changed"] += original_status[test] != verdict
                            log.writerow((sub["sid"], p["id"], test, old[1], verdict, old[2], cpu, wall, detail))
                        now = time.monotonic()
                        if now - last_progress >= .5 or info["rerun"] == info["selected"]:
                            say(f"复核 {info['rerun']:,}/{info['selected']:,} ({info['rerun']*100/max(1,info['selected']):.2f}%)：{sub['sid']} / {p['id']} / {test}  {old[1]} → {verdict}")
                            last_progress = now
                    elif a[0] == "DONE" and int(a[1]) == last:
                        for test in remaining:
                            info["failed"] += 1
                            log.writerow((sub["sid"], p["id"], test, by_test[test][1], "保留原结果", by_test[test][2], "", "", error or "评测器未返回该点"))
                        break
            finally:
                score, strip = summary(sub, p)
                sub["score"] = score
                # Keep failed/unfinished points pending so --resume never skips them.
                # A pre-existing 0.0.0.0 marker is not proof this pass completed.
                pending = set(targets) - completed
                info["elapsed_seconds"] = previous_elapsed + time.monotonic() - started
                db.execute("UPDATE subs SET raw=?,selected=?,score=?,strip=? WHERE id=?", (json.dumps(sub, ensure_ascii=False, separators=(",", ":")), json.dumps(sorted(pending)), score, strip, last))
                if has_checkpoint(db):
                    save_progress(db, info, statuses)
                db.commit()
            processed += 1
            if batch_size and processed >= batch_size:
                say("本批复核已保存；其余测点可以用 --resume 继续")
                break
    except KeyboardInterrupt:
        info["interrupted"] = True
        say("停止本机复核，正在保存已完成结果；未重测的点保留原判定")
    except (RuntimeError, TimeoutError, BrokenPipeError, OSError) as error:
        info["interrupted"] = True
        info["error"] = str(error)
        say("本机复核中断：" + str(error) + "；正在保存已完成结果，其余点保留原判定")


def has_checkpoint(db):
    return bool(db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='checkpoint'").fetchone())


def save_progress(db, info, statuses):
    db.execute("INSERT OR REPLACE INTO checkpoint(key,value) VALUES('progress',?)",
               (json.dumps({"info":info, "statuses":dict(statuses)}, ensure_ascii=False),))


def pending_points(db):
    return sum(len(json.loads(row[0])) for row in db.execute("SELECT selected FROM subs WHERE selected!='[]'"))


def data_manifest(runtime):
    result = {}
    for path in sorted((runtime / "data").iterdir()):
        if path.is_file():
            with open(path, "rb") as f:
                result[path.name] = hashlib.file_digest(f, "sha256").hexdigest()
    return result


def write_report(original, bounds, output, meta, db, statuses, info):
    temporary = Path(str(output) + ".tmp-" + uuid.uuid4().hex[:8])
    meta = dict(meta)
    full = info.get("mode") == "full"
    pending = pending_points(db)
    info["pending"] = pending
    info["complete"] = full and pending == 0 and not info.get("excluded_submissions") and info["rerun"] == info["selected"]
    rule = "all points of all active submissions including original CE" if full else "all nodes, TLE CPU below problem limit only; original WA unchanged"
    meta["repair"] = {**info, "generated": time.time(), "rule": rule}
    message = (f"完整复核已完成：{info['rerun']:,} 个测点，均在本机重新评测。" if info["complete"] else
               f"完整复核未完成：还剩 {pending:,} 个测点，{info.get('excluded_submissions',0):,} 份搁置或跳过的提交；不能作为已全部修复的成绩。" if full else
               f"仅修复低耗时 TLE：复核 {info['rerun']:,} 点；原有 WA 等其他结果未完整复核。")
    color = "#0e9f83" if info["complete"] else "#b42318"
    banner = f'<aside id="oi-sprint-repair-status" role="status" style="padding:14px 20px;border-bottom:3px solid {color};background:#fff;color:#15202b;font:16px/1.5 sans-serif">{message}</aside>'.encode("utf8")
    with open(temporary, "xb") as dst, open(original, "rb") as src:
        prefix = src.read(bounds[0])
        # Replace our prior notice when rechecking an already repaired report.
        prefix = re.sub(rb'<aside id="oi-sprint-repair-status".*?</aside>', b'', prefix, flags=re.S)
        prefix, inserted = re.subn(rb'(<body\b[^>]*>)', lambda m: m[0] + banner, prefix, count=1)
        if inserted != 1:
            raise ValueError("报告缺少 HTML body，不能写入复核完成状态")
        dst.write(prefix)
        def emit(value):
            dst.write(value.encode("utf8"))
        emit("{")
        for i, (key, value) in enumerate(meta.items()):
            emit(("," if i else "") + json_text(key) + ":" + json_text(value))
        emit(',"rows":[')
        order = {p["id"]: i for i, p in enumerate(meta["problems"])}
        sid, student, first = None, None, True
        for student_id, prob, score, strip in db.execute("SELECT sid,prob,score,strip FROM subs ORDER BY sid,prob"):
            if student_id != sid:
                if student is not None:
                    emit(("" if first else ",") + json_text(student)); first = False
                sid = student_id
                student = [sid, 0, [None] * len(order), [""] * len(order)]
            student[1] += score
            student[2][order[prob]], student[3][order[prob]] = score, strip
        if student is not None:
            emit(("" if first else ",") + json_text(student))
        emit('],"status":' + json_text({k: v for k, v in statuses.items() if v}) + ',"subs":{')
        first = True
        tick = time.monotonic()
        for key, raw in db.execute("SELECT key,raw FROM subs ORDER BY id"):
            emit(("" if first else ",") + json_text(key) + ":" + json_text(json.loads(raw)))
            first = False
            if time.monotonic() - tick > 1:
                say(f"正在输出修复 HTML：{dst.tell()/1048576:.0f} MB")
                tick = time.monotonic()
        emit("}}")
        src.seek(bounds[1]); shutil.copyfileobj(src, dst)
    os.replace(temporary, output)


def main():
    parser = argparse.ArgumentParser(description="完整复核比赛 HTML，或仅补测低耗时 TLE；支持断点继续")
    parser.add_argument("html", nargs="?")
    parser.add_argument("--data", help="原测试数据文件夹，或比赛 data.tar.gz")
    parser.add_argument("--output")
    parser.add_argument("--mode", choices=("full", "tle"), default="full")
    parser.add_argument("--resume", help="先前输出的 OI-Sprint-Repair-Work 中的具体任务目录")
    parser.add_argument("--batch-size", type=int, default=0, help="本批最多处理多少份提交，0 为不限")
    parser.add_argument("--tle-only", action="store_true")
    parser.add_argument("--yes", action="store_true", help="跳过命中数量确认")
    parser.add_argument("--no-scale", action="store_true")
    args = parser.parse_args()
    if args.tle_only:
        args.mode = "tle"
    app = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parents[2]
    bundled = Path(getattr(sys, "_MEIPASS", app / "build/oi-sprint/repair-payload"))
    session = None
    if args.resume:
        work = Path(args.resume).resolve()
        if not (work / "report.sqlite").is_file():
            raise ValueError("续跑目录缺少 report.sqlite")
        with sqlite3.connect(work / "report.sqlite") as prior:
            session = json.loads(prior.execute("SELECT value FROM checkpoint WHERE key='session'").fetchone()[0])
        args.mode = session["mode"]
    supplied = session["html"] if session else args.html or input("导出的 HTML 路径（可直接粘贴）：").strip().strip('"')
    if not supplied:
        return 0
    html = Path(supplied)
    if not html.is_file():
        raise ValueError("报告文件不存在：" + str(html))
    html = html.resolve()
    output = Path(args.output) if args.output else html.with_name(html.stem + ("_完整复核.html" if args.mode == "full" else "_修复.html"))
    if output.exists() and not args.output:
        output = html.with_name(html.stem + "_修复_" + time.strftime("%Y%m%d_%H%M%S") + ".html")
    if output.resolve() == html or output.exists():
        raise ValueError("输出不能覆盖原报告或已有文件，请换一个输出文件名")
    if not session:
        work = app / "OI-Sprint-Repair-Work" / (time.strftime("%Y%m%d_%H%M%S") + "-" + uuid.uuid4().hex[:8])
        work.mkdir(parents=True)
    db = sqlite3.connect(work / "report.sqlite")
    db.execute("PRAGMA synchronous=NORMAL")
    db.execute("PRAGMA cache_size=-8192")
    agent = None
    try:
        bounds = locate_json(html)
        meta = metadata(html, bounds)
        runtime = work / "runtime"
        if session:
            st = html.stat()
            if [st.st_size, st.st_mtime_ns] != session["source_stat"]:
                raise ValueError("原报告在任务创建后已改变，不能混用断点")
            saved = json.loads(db.execute("SELECT value FROM checkpoint WHERE key='progress'").fetchone()[0])
            info, statuses = saved["info"], Counter(saved["statuses"])
            wanted = {(p, t) for p, selected in db.execute("SELECT prob,selected FROM subs WHERE selected!='[]'") for t in json.loads(selected)}
            say("检查续跑数据是否与首次复核一致……")
            if data_manifest(runtime) != session["manifest"]:
                raise ValueError("暂存测试数据已改变，拒绝继续，原报告和断点记录保持不变")
            scale = session["scale"]
        else:
            say("完整复核所有可评测提交，包含原来的 AC、WA、TLE 和 CE；搁置/跳过项单独列出" if args.mode == "full" else
                "自动扫描所有节点，只复核低耗时 TLE；全部 WA 保留")
            wanted, statuses, info = index_report(html, bounds, meta, db, args.mode)
        pending = pending_points(db)
        if pending and not args.yes and input(f"本次待复核 {pending:,} 点，开始？[Y/n] ").strip().lower() in ("n", "no"):
            say("已取消重测，原 HTML 保持不变")
            return 0
        for key in ("rerun", "changed", "failed"):
            info.setdefault(key, 0)
        info.update(node=NODE, interrupted=False)
        if wanted and not session:
            found, original_scale, cid = current_data(meta, html, app)
            data = Path(args.data) if args.data else None
            if data is None and found:
                say("检测到当前比赛数据：" + str(found))
                if input("确认这是本报告对应的原比赛数据？[Y/n] ").strip().lower() not in ("n", "no"):
                    data = found
            if data is None:
                chosen = input("原比赛 data 文件夹路径（可直接粘贴）：").strip().strip('"')
                if not chosen:
                    raise ValueError("没有选择测试数据，原报告未修改")
                data = Path(chosen)
            recorded = meta.get("contest", {}).get("scale")
            scale = False if args.no_scale else recorded if recorded is not None else original_scale if data == found else True
            if not args.no_scale and recorded is None and data != found:
                scale = input("旧报告未记录设置。原比赛是否勾选了“按节点速度折算时限”？[Y/n] ").strip().lower() not in ("n", "no")
            runtime.mkdir()
            say("准备独立本机工具链；不连接主控和远端节点")
            with tarfile.open(bundled / "runtime.tar.gz", "r:gz") as archive:
                archive.extractall(runtime, filter="data")
            stage_data(data, runtime / "data", wanted, meta["problems"])
            agent_file = runtime / "oi-sprint-repair-agent.exe"
            shutil.copyfile(bundled / "oi-sprint-repair-agent.exe", agent_file)
            st = html.stat()
            session = {"html":str(html), "source_stat":[st.st_size, st.st_mtime_ns], "mode":args.mode,
                       "scale":bool(scale), "manifest":data_manifest(runtime)}
            db.execute("CREATE TABLE checkpoint(key TEXT PRIMARY KEY,value TEXT)")
            db.execute("INSERT INTO checkpoint VALUES('session',?)", (json.dumps(session, ensure_ascii=False),))
            save_progress(db, info, statuses)
            db.commit()
        if wanted:
            say("断点目录：" + str(work))
            say('续跑命令：OI-Sprint-Repair-Full.exe --resume "' + str(work) + '"')
            agent = LocalAgent(runtime, runtime / "oi-sprint-repair-agent.exe")
            with open(work / "复核记录.csv", "a", encoding="utf-8-sig", newline="") as audit:
                rerun(db, meta, agent, statuses, info, csv.writer(audit), bool(scale), args.batch_size)
            agent.close(); agent = None
            save_progress(db, info, statuses)
            db.commit()
            shutil.copyfile(work / "复核记录.csv", output.with_suffix(".复核记录.csv"))
        say("正在重新计算排名数据并生成新 HTML")
        write_report(html, bounds, output, meta, db, statuses, info)
        if info.get("excluded_submissions") and db.execute("SELECT 1 FROM sqlite_master WHERE name='excluded'").fetchone():
            excluded_path = output.with_suffix(".未评测提交.csv")
            with open(excluded_path, "w", encoding="utf-8-sig", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(("考号", "题目", "原状态", "原搁置原因"))
                writer.writerows(db.execute("SELECT sid,prob,state,reasons FROM excluded ORDER BY sid,prob"))
            say("原搁置/跳过项清单：" + str(excluded_path))
        say(f"本机复核 {info['rerun']:,} 点，改变判定 {info['changed']:,} 点，待复核 {info['pending']:,} 点")
        if args.mode == "full":
            say("全部可评测记录已复核完成；以相同规则、本机工具链和本次运行结果为准" if info["complete"] else "复核尚未完整完成，不能作为已全部修复的成绩")
        say("修复报告：" + str(output.resolve()))
        return 2 if args.mode == "full" and not info["complete"] else 0
    finally:
        if agent:
            agent.close()
        db.close()


if __name__ == "__main__":
    try:
        code = main()
    except Exception as error:
        say("修复未完成：" + str(error) + "。原 HTML 保持不变。")
        code = 1
    if getattr(sys, "frozen", False):
        try:
            input("按回车关闭修复程序。")
        except EOFError:
            pass
    sys.exit(code)
