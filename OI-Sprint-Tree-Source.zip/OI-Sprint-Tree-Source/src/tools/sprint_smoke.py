"""One small end-to-end run of the extracted portable, including loopback SSH."""
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import urllib.request
import uuid
import zipfile

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / "build" / "oi-sprint" / ("smoke-" + uuid.uuid4().hex[:8])
RUN.mkdir(parents=True)
package = Path(sys.argv[sys.argv.index("--package")+1]) if "--package" in sys.argv else ROOT / "OI-Sprint-Classic-Portable.zip"
with zipfile.ZipFile(package) as archive:
    archive.extractall(RUN)
APP = RUN / "OI-Sprint-Classic"
if "--patch" in sys.argv:
    with zipfile.ZipFile(sys.argv[sys.argv.index("--patch")+1]) as archive:
        archive.extractall(APP)


def free_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


PORT, SSH_PORT = free_port(), free_port()
BASE = f"http://127.0.0.1:{PORT}"


def api(path, body=None):
    request = urllib.request.Request(BASE + path, None if body is None else json.dumps(body).encode(),
                                     {"X-Judge": "1", "Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=8) as response:
        return json.load(response)


def state():
    return api("/api/state?since=0")


def wait_for(predicate, timeout=70):
    end = time.monotonic() + timeout
    last = None
    while time.monotonic() < end:
        try:
            last = state()
            if last.get("preparing", {}).get("stage") == "error" if last.get("preparing") else False:
                raise RuntimeError(last["preparing"])
            if predicate(last):
                return last
        except (ConnectionError, urllib.error.URLError):
            pass
        time.sleep(0.1)
    raise TimeoutError(str(last)[:1800])


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf8")


def main():
    sources = {
        "alpha": '#include<cstdio>\nint main(){freopen("alpha.in","r",stdin);freopen("alpha.out","w",stdout);int a,b;scanf("%d%d",&a,&b);printf("%d\\n",a+b);}',
        "wrong": '#include<cstdio>\nint main(){freopen("wrong.out","w",stdout);printf("999\\n");}',
        "slow": '#include<cstdio>\nint main(){freopen("slow.in","r",stdin);freopen("slow.out","w",stdout);int n;scanf("%d",&n);volatile unsigned x=0;if(n==2)for(;;)++x;for(unsigned i=0;i<10000000;++i)x+=i;printf("2\\n");}',
        "bad": 'int main( {',
    }
    for p, code in sources.items():
        write(RUN / "answers" / "s1" / (p + ".cpp"), code)
        for test in range(1, 5 if p in ("alpha", "slow") else 3):
            inp = "1 2\n" if p == "alpha" else ("2\n" if p == "slow" and test % 2 == 0 else "1\n")
            write(RUN / "data" / f"{p}{test}.in", inp)
            write(RUN / "data" / f"{p}{test}.ans", "3\n" if p == "alpha" else "2\n")
    env = dict(os.environ)
    env["PATH"] = str(Path(os.environ["SystemRoot"]) / "System32")
    log = open(RUN / "master.log", "w", encoding="utf8")
    sshlog = open(RUN / "ssh.log", "w", encoding="utf8")
    remote = RUN / "ssh-home"
    remote.mkdir()
    # Only marked, disposable legacy deployments are eligible for cleanup.
    for legacy, agent in ((remote / ".oi_judge", "agent.exe"), (RUN / "remote-base/.oi_sprint", "oi-sprint-agent.exe")):
        write(legacy / "VERSION", "legacy")
        write(legacy / agent, "legacy-marker")
        write(legacy / "mingw/bin/g++.exe", "legacy-marker")
        write(legacy / "data_0123456789abcdef/old.in", "old")
        write(legacy / "keep.txt", "keep")
    ssh = subprocess.Popen([sys.executable, str(ROOT / "src/tools/test_ssh_server.py"), str(remote), str(SSH_PORT)],
                           stdout=sshlog, stderr=sshlog, creationflags=0x08000000)
    master = None
    def start():
        return subprocess.Popen([str(APP / "OI-Sprint-Classic.exe"), "--no-browser", "--port", str(PORT)],
                                env=env, stdout=log, stderr=log, creationflags=0x08000000)
    try:
        master = start()
        wait_for(lambda s: s["contest"] is None)
        report = api("/api/contest/scan", {"data": str(RUN / "data"), "answers": str(RUN / "answers")})
        config = {"name": "OI-Sprint-Classic smoke", "data": str(RUN / "data"), "answers": str(RUN / "answers"),
                  "scale": False, "problems": [{**p, "tl": 180, "ml": 128, "full": 100} for p in report["problems"]]}
        api("/api/contest/apply", config)
        wait_for(lambda s: s["contest"] is not None and not s["preparing"])
        order = list(reversed([p["id"] for p in config["problems"]]))
        api("/api/problems/reorder", {"order": order})
        assert [p["id"] for p in state()["problems"]] == order
        local = next(n for n in state()["nodes"] if n["local"])
        api("/api/nodes/update", {"id": local["id"], "enabled": True, "slots": 4})
        api("/api/settings", {"cpu_limit": 50})
        custom = (RUN / "remote-base").as_posix()
        api("/api/nodes/add", {"text": f"test@127.0.0.1:{SSH_PORT} password:testpw slots:2 dir:{custom}"})
        online = wait_for(lambda s: len(s["nodes"]) == 2 and all(n["stage"] == "online" for n in s["nodes"]))
        assert all(n["compile_limit"] == n["slots"] for n in online["nodes"])
        assert (RUN / "remote-base/.oi_sprint_classic/oi-sprint-classic-agent.exe").exists()
        for legacy in (remote / ".oi_judge", RUN / "remote-base/.oi_sprint"):
            assert not (legacy / "data_0123456789abcdef").exists()
            assert (legacy / "keep.txt").read_text() == "keep"
        print("PASS portable launch without Python/MinGW on PATH and isolated SSH deployment", flush=True)
        api("/api/settings", {"cpu_limit": 50})
        wait_for(lambda s: all(n["cpu_limit_applied"] == 50 for n in s["nodes"]))
        assert all(n["cpu_limit"] is None for n in state()["nodes"])
        api("/api/nodes/update", {"id": local["id"], "cpu_limit": 25})
        api("/api/settings", {"cpu_limit": 60})
        wait_for(lambda s: all(n["cpu_limit_applied"] == (25 if n["local"] else 60) for n in s["nodes"]))
        api("/api/nodes/update", {"id": local["id"], "cpu_limit": None})
        wait_for(lambda s: all(n["cpu_limit_applied"] == 60 for n in s["nodes"]))
        api("/api/settings", {"cpu_limit": 50})
        wait_for(lambda s: all(n["cpu_limit_applied"] == 50 for n in s["nodes"]))
        print("PASS new-node inheritance, independent override and return to global", flush=True)
        api("/api/control", {"op": "start"})
        started = time.monotonic()
        parallel = 0
        while True:
            current = state()
            for p in ("alpha", "slow"):
                detail = api(f"/api/sub?sid=s1&prob={p}")
                parallel = max(parallel, len(detail["running_tests"]))
            if all(p["done"] == p["total"] for p in current["problems"]):
                break
            if time.monotonic() - started > 45:
                raise TimeoutError(current)
            time.sleep(0.04)
        assert parallel == 1, parallel
        expected = {"alpha": ["AC"] * 4, "wrong": ["WA"] * 2, "slow": ["AC", "TLE", "AC", "TLE"]}
        for p, verdicts in expected.items():
            detail = api(f"/api/sub?sid=s1&prob={p}")
            assert [t[1] for t in detail["tests"]] == verdicts, detail
        assert api("/api/sub?sid=s1&prob=bad")["compile"][0] == "CE"
        wait_for(lambda s: all(n["inflight"] == 0 for n in s["nodes"]))
        print(f"PASS AC/WA/TLE/CE and whole-submission scheduling (peak points per submission {parallel}, batch {time.monotonic()-started:.2f}s)", flush=True)
        api("/api/settings", {"cpu_limit": 100})
        wait_for(lambda s: all(n["cpu_limit_applied"] == 100 for n in s["nodes"]))
        before = sum(n["cache_hits"] for n in state()["nodes"])
        t0 = time.monotonic()
        api("/api/act", {"op": "rejudge", "problems": ["alpha"]})
        wait_for(lambda s: all(p["done"] == p["total"] for p in s["problems"]))
        after = sum(n["cache_hits"] for n in state()["nodes"])
        # The original shared queue may send rejudging to a different, cold node.
        assert all(t[1] == "AC" for t in api("/api/sub?sid=s1&prob=alpha")["tests"])
        print(f"PASS rejudge ({after-before} cache hits, {time.monotonic()-t0:.2f}s)", flush=True)
        # Atomic result batches are committed every 0.5 seconds.
        time.sleep(0.7)
        saved_rows = state()["rows"]
        api("/api/nodes/update", {"id": local["id"], "slots": 0})
        api("/api/settings", {"cpu_limit": 35})
        wait_for(lambda s: all(n["cpu_limit_applied"] == 35 for n in s["nodes"]))
        api("/api/nodes/update", {"id": local["id"], "cpu_limit": 20})
        wait_for(lambda s: all(n["cpu_limit_applied"] == (20 if n["local"] else 35) for n in s["nodes"]))
        api("/api/control", {"op": "pause"})
        master.terminate()
        master.wait(timeout=8)
        master = start()
        restored = wait_for(lambda s: s["contest"] is not None)
        assert restored["rows"] == saved_rows
        assert [p["id"] for p in restored["problems"]] == order
        restored = wait_for(lambda s: all(n["stage"] == "online" for n in s["nodes"]))
        assert restored["cpu_limit"] == 35
        assert all(n["cpu_limit_applied"] == (20 if n["local"] else 35) for n in restored["nodes"])
        assert all(n["cpu_limit"] == (20 if n["local"] else None) for n in restored["nodes"])
        assert next(n for n in restored["nodes"] if n["local"])["slots"] == 0
        with urllib.request.urlopen(BASE + "/api/export") as response:
            exported = response.read().decode("utf8")
        start = exported.index("const EXPORT = ") + len("const EXPORT = ")
        blob, _ = json.JSONDecoder().raw_decode(exported[start:])
        assert [p["id"] for p in blob["problems"]] == order
        print("PASS saved results, zero slots after reconnect, CPU cap, problem order and HTML export", flush=True)
        if "--cpu-only" in sys.argv:
            print("PASS node CPU override and inheritance after reconnect/restart", flush=True)
            print("Smoke artifacts:", RUN, flush=True)
            return
        import shutil
        old_id = restored["contest"]["id"]
        next_data = RUN / "data-next"
        shutil.copytree(RUN / "data", next_data)
        config["data"] = str(next_data)
        api("/api/contest/apply", config)
        fresh = wait_for(lambda s: s["contest"] and s["contest"]["id"] != old_id and not s["preparing"])
        wait_for(lambda s: all(n["stage"] == "online" for n in s["nodes"]))
        assert not (APP / "state/contests" / old_id).exists()
        assert len(api("/api/contests")["contests"]) == 1
        reset = api("/api/factory-reset", {"confirm": True})
        assert reset["warnings"] == [], reset
        blank = state()
        assert blank["contest"] is None and blank["rows"] == [] and blank["cpu_limit"] == 100
        assert len(blank["nodes"]) == 1 and blank["nodes"][0]["local"] and not blank["nodes"][0]["enabled"]
        assert not (APP / "exports").exists() and not (APP / "state/worker-classic").exists()
        assert list((APP / "state/contests").iterdir()) == []
        deployed = RUN / "remote-base/.oi_sprint_classic"
        assert not list(deployed.glob("data_*")) and not (deployed / "cache").exists() and not (deployed / "run").exists()
        assert (deployed / "oi-sprint-classic-agent.exe").exists()
        assert (RUN / "data/alpha1.in").exists() and (RUN / "answers/s1/alpha.cpp").exists()
        print("PASS only-current history policy and factory reset (local + SSH), original inputs preserved", flush=True)
        print("Smoke artifacts:", RUN, flush=True)
    finally:
        if master and master.poll() is None:
            master.terminate()
            master.wait(timeout=8)
        ssh.terminate()
        ssh.wait(timeout=8)
        log.close()
        sshlog.close()


if __name__ == "__main__":
    main()
