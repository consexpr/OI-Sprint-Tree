"""Small loopback comparison: four 4 MiB SFTP uploads, with/without competing Python work."""
import concurrent.futures
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import threading
import time
import uuid

import paramiko

ROOT = Path(__file__).resolve().parents[2]


def upload(port, payload, name):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect("127.0.0.1", port=port, username="test", password="testpw",
                       allow_agent=False, look_for_keys=False, timeout=5)
        tr = client.get_transport()
        tr.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        tr.default_window_size = 8 * 1024 * 1024
        with client.open_sftp() as sftp:
            sftp.putfo(io.BytesIO(payload), name, file_size=len(payload))
    finally:
        client.close()


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--child":
        upload(int(sys.argv[2]), Path(sys.argv[3]).read_bytes(), sys.argv[4])
        return
    directory = ROOT / "build/oi-sprint" / ("transfer-probe-" + uuid.uuid4().hex[:8])
    directory.mkdir()
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    payload = (ROOT / "build/oi-sprint/dist/OI-Sprint-Classic/payload/runtime.tar.gz").read_bytes()[:4 * 1024 * 1024]
    source = directory / "payload.bin"
    source.write_bytes(payload)
    log = open(directory / "server.log", "wb")
    server = subprocess.Popen([sys.executable, str(ROOT / "src/tools/test_ssh_server.py"), str(directory), str(port)],
                              stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
    stop = threading.Event()
    busy = None

    def work():
        # Deliberately synthetic: represents Python CPU contention, not a measured judge load.
        value = 0
        while not stop.is_set():
            for number in range(10000):
                value = (value + number) & 0xffffffff

    try:
        for _ in range(100):
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=.1):
                    break
            except OSError:
                time.sleep(.05)
        modes = ("processes-busy",) if "--production-only" in sys.argv else ("threads-idle", "threads-busy", "processes-busy")
        for mode in modes:
            stop.clear()
            if mode.endswith("busy"):
                busy = threading.Thread(target=work)
                busy.start()
            started = time.perf_counter()
            if mode.startswith("threads"):
                with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                    list(pool.map(lambda i: upload(port, payload, f"{mode}-{i}.bin"), range(4)))
            else:
                sys.path.insert(0, str(ROOT / "src/master"))
                import judge
                def isolated(index):
                    conn = judge.SSHConn(None, {"host": "127.0.0.1", "port": port, "user": "test", "password": "testpw"})
                    try:
                        conn._upload_bundle(str(source), f"{mode}-{index}.bin", lambda *args: None)
                    finally:
                        conn.close()
                with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                    list(pool.map(isolated, range(4)))
            elapsed = time.perf_counter() - started
            stop.set()
            if busy:
                busy.join()
                busy = None
            print(json.dumps({"mode": mode, "seconds": round(elapsed, 2),
                              "MiB_s_total": round(4 * len(payload) / elapsed / 1048576, 2)}), flush=True)
    finally:
        stop.set()
        if busy:
            busy.join(2)
        server.terminate()
        server.wait(5)
        log.close()


if __name__ == "__main__":
    main()
