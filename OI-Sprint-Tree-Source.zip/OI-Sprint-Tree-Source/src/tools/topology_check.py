"""Small deterministic checks of promotion, drain ordering and automatic failover."""
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'master'))
import judge as J
from topology import Controller
import provisioning


def main():
    original = J.Node.ensure_started
    J.Node.ensure_started = lambda self: None  # no network or compiler in this check
    try:
        with tempfile.TemporaryDirectory(prefix='sprint-topology-') as folder:
            j = J.Judge(folder)
            c = j.topology = Controller(j)
            cfg = dict(user='judge', password='secret', port=22, slots=2, cpu_limit=40, auto_route=True)
            nodes = [j.add_node(dict(cfg, host=f'192.168.1.{i}')) for i in range(10, 18)]
            for n in nodes:
                n.stage = 'online'
                n.info = dict(logical=4, mem=8192, perf=100)
            best = nodes[3]
            best.slots = 0
            best.info = dict(logical=16, mem=32768, perf=200)
            lease = SimpleNamespace(id=7, sent=True, cancelled=False, yielded=False)
            best.inflight[7] = lease
            c.tick(0); c.tick(11)
            assert c.pending[best.id] == ('promote', None)
            assert lease.yielded and best.routing_draining and not j.relays.configs
            assert best.outbox.get_nowait() == b'YIELD 7\n'
            c.tick(12)
            assert not j.relays.configs  # never transfer an active lease
            best.inflight.clear()
            c.tick(13)
            rid = best.relay_id
            assert best.relay_local and best.managed and best.id in j.nodes
            assert best.slots == 0 and best.cpu_limit_override == 40 and best.password == 'secret'
            g = c.gateway(rid)
            assert g and len(j.nodes) == 9 and len(j.relays.configs) == 1
            print('PASS automatic promotion preserves identity, zero concurrency and CPU override; drains first')

            g.stage = 'online'
            c.tick(14); c.tick(25); c.tick(26); c.tick(27); c.tick(28)
            assert all(n.relay_id == rid for n in nodes)
            assert not c.pending and not g.routing_draining
            print('PASS all workers attach automatically without choosing roles or parents')

            # A single offline snapshot does not cause churn; sustained failure
            # lets the children reconnect directly using their saved credentials.
            g.stage = 'offline'
            c.tick(40)
            assert all(n.relay_id == rid for n in nodes)
            c.tick(61); c.tick(62); c.tick(63); c.tick(64)
            assert all(n.relay_id is None for n in nodes if not n.relay_local)
            assert best.relay_id == rid
            print('PASS transient loss is stable; failed vice is bypassed automatically')

            form = dict(addresses='192.168.2.10-12', user='judge', auth='agent', port=22)
            configs, role = provisioning.configurations(form, j)
            assert role == 'auto' and len(configs) == 3
            assert all(n['auto_route'] and n['relay'] is None for n in configs)
            assert J.Node(j, 999, nodes[0].to_config()).auto_route
            print('PASS batch form and saved nodes retain automatic routing')

        with tempfile.TemporaryDirectory(prefix='sprint-topology-growth-') as folder:
            j = J.Judge(folder)
            c = j.topology = Controller(j)
            rid = j.relays.add_config(dict(cfg, host='192.168.3.1', slots=1))
            g = c.gateway(rid); g.stage = 'online'
            own = next(n for n in j.nodes.values() if n.relay_local)
            own.stage = 'online'; own.info = dict(logical=8, mem=16384)
            leaves = [j.add_node(dict(cfg, host=f'192.168.3.{i}', relay=rid)) for i in range(2, 18)]
            for n in leaves:
                n.stage = 'online'; n.info = dict(logical=4, mem=8192)
            c.tick(0); c.tick(11)
            candidate = j.nodes[next(nid for nid, a in c.pending.items() if a[0] == 'promote')]
            c.tick(12)
            assert candidate.relay_id is None and candidate.id in c.pending
            candidate.stage = 'online'
            c.tick(13)
            assert candidate.relay_local and candidate.relay_id != rid and len(j.relays.configs) == 2
            # A new worker is routed before ensure_started, so it does not first
            # receive a full direct deployment and then get uploaded again.
            c.good_since[g.id] = 0
            newcomer = j.add_node(dict(cfg, host='192.168.3.30'))
            assert newcomer.managed and newcomer.relay_id == rid
            print('PASS growth elects a second vice from a managed leaf; newcomers skip direct upload')

        with tempfile.TemporaryDirectory(prefix='sprint-connect-prune-') as folder:
            j = J.Judge(folder)
            c = j.topology = Controller(j)
            bad = j.add_node(dict(cfg, host='192.168.4.1'))
            known = j.add_node(dict(cfg, host='192.168.4.2'))
            known.set_stage('online'); known.set_stage('error')
            bad.set_stage('error')
            c.tick(0)
            assert bad.id not in j.nodes and not bad.alive
            assert known.id in j.nodes and known.connected_once
            assert J.Node(j, 100, known.to_config()).connected_once
            rid = j.relays.add_config(dict(cfg, host='192.168.4.3'))
            child = j.add_node(dict(cfg, host='192.168.4.4', relay=rid))
            j.relays.accept_status(rid, [dict(id=child.id, stage='error', info={}, connected_once=True)])
            unconnected = j.add_node(dict(cfg, host='192.168.4.5', relay=rid))
            j.relays.accept_status(rid, [dict(id=unconnected.id, stage='error', info={})])
            c.tick(1)
            assert child.id in j.nodes and unconnected.id not in j.nodes
            import json
            saved = json.loads((Path(folder) / 'state/nodes.json').read_text(encoding='utf8'))
            assert all(n.get('host') not in ('192.168.4.1', '192.168.4.5') for n in saved)
            print('PASS failed first connections removed from list and saved config; established nodes retained')
    finally:
        J.Node.ensure_started = original


if __name__ == '__main__': main()
