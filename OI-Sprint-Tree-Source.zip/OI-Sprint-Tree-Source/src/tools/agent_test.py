"""Drives oi-sprint-agent.exe directly with hostile and edge-case programs. Never triggers a real shutdown:
privilege checks are done by inspecting the token, not by calling shutdown APIs."""
import base64
import subprocess
import sys
import threading
import time

WORKER = sys.argv[1] if len(sys.argv) > 1 else r"D:\Tester\build\worker"
WINH = '#define WIN32_LEAN_AND_MEAN\n#include "D:/mingw64/x86_64-w64-mingw32/include/windows.h"\n'

SCRATCH_OUTSIDE = WORKER + r"\pwned.txt"
CASES = {
    "stack_900mb": ('#include<bits/stdc++.h>\nusing namespace std;\nint f(int d){volatile char b[1024];b[0]=d;'
                    'if(d==0)return 0;return f(d-1)+b[0]-d+1;}\nint main(){freopen("crystal.in","r",stdin);'
                    'freopen("crystal.out","w",stdout);cout<<f(900000)+2;}\n'),
    "dfs_1e7": ('#include<bits/stdc++.h>\nusing namespace std;\nint n=10000000;long long dfs(int u){if(u==n)return 1;'
                'return dfs(u+1)+1;}\nint main(){freopen("crystal.in","r",stdin);freopen("crystal.out","w",stdout);'
                'cout<<dfs(0)-9999999;}\n'),
    "cxx14_only": ('#include<bits/stdc++.h>\nusing namespace std;\nint main(){freopen("crystal.in","r",stdin);'
                   'freopen("crystal.out","w",stdout);auto f=[](auto x){return x;};'
                   'cout<<f(__cplusplus==201402L?2:0);}\n'),
    "cxx17_rejected": ('#include<bits/stdc++.h>\nusing namespace std;\nint main(){auto [a,b]=make_pair(1,2);'
                       'if constexpr(sizeof(int)==4){} return a+b;}\n'),
    "windows_h_rejected": '#include<windows.h>\nint main(){return 0;}\n',
    "unlocked": ('#define getchar getchar_unlocked\n#include<bits/stdc++.h>\nusing namespace std;\n'
                 'int main(){freopen("crystal.in","r",stdin);freopen("crystal.out","w",stdout);'
                 'int c=getchar();while(c!=EOF)c=getchar();printf("2\\n");}\n'),
    "binary_mode": ('#include<cstdio>\nint main(){freopen("crystal.out","w",stdout);printf("2\\n");fclose(stdout);'
                    'FILE*f=fopen("crystal.out","rb");int c,n=0;while((c=fgetc(f))!=EOF)n++;fclose(f);'
                    'freopen("crystal.out","w",stdout);printf("len%d\\n",n);}\n'),
    "no_freopen": '#include<cstdio>\nint main(){printf("2\\n");}\n',
    "wrong_answer": ('#include<cstdio>\nint main(){freopen("crystal.out","w",stdout);printf("999\\n");}\n'),
    "trailing_ws": ('#include<cstdio>\nint main(){freopen("crystal.out","w",stdout);printf("2  \\n\\n\\n");}\n'),
    "bss_2g": ('#include<cstdio>\nstatic char a[2000000000];\nint main(){freopen("crystal.out","w",stdout);'
               'a[1999999999]=1;printf("%d\\n",a[1999999999]+a[12345]+1);}\n'),
    "bss_900_touch": ('#include<cstdio>\n#include<cstring>\nstatic char a[900000000];\nint main(){freopen("crystal.out","w",stdout);'
               'memset(a,1,sizeof a);printf("%d\\n",a[5]+1);}\n'),
    "bss800_heap800": ('#include<cstdio>\n#include<cstring>\n#include<cstdlib>\nstatic char a[800000000];\nint main(){freopen("crystal.out","w",stdout);'
               'memset(a,1,sizeof a);char*p=(char*)malloc(800000000);if(!p)abort();memset(p,1,800000000);printf("%d\\n",a[5]+p[5]);}\n'),
    "vector_double": ('#include<bits/stdc++.h>\nint main(){std::vector<long long> v;for(;;)v.push_back(1);}\n'),
    "malloc_bomb": ('#include<bits/stdc++.h>\nint main(){freopen("crystal.out","w",stdout);for(;;){char*p=new char[1<<24];'
                    'memset(p,1,1<<24);}}\n'),
    "tle_spin": 'int main(){for(;;);}\n',
    "tle_sleep": '#include<thread>\n#include<chrono>\nint main(){std::this_thread::sleep_for(std::chrono::hours(1));}\n',
    "output_flood": ('#include<cstdio>\nint main(){freopen("crystal.out","w",stdout);for(;;)fwrite("xxxxxxxxxxxxxxxx",1,16,stdout);}\n'),
    "segv": 'int main(){volatile int*p=0;*p=1;}\n',
    "div0": 'int main(){volatile int a=0;return 1/a;}\n',
    "stack_overflow": 'int f(int x){volatile char b[4096];b[0]=x;return f(x+1)+b[0];}\nint main(){return f(0);}\n',
    "abort": '#include<cstdlib>\nint main(){abort();}\n',
    "hostile_system": ('#include<bits/stdc++.h>\nint main(){int r=system("echo pwned > C:\\\\Windows\\\\Temp\\\\csp_pwn.txt");'
                       'freopen("crystal.out","w",stdout);printf("system=%d\\n",r);}\n'),
    "hostile_child": (WINH + '#include<cstdio>\nint main(){STARTUPINFOA si{};si.cb=sizeof si;PROCESS_INFORMATION pi{};'
                      'char c[]="cmd.exe /c exit 0";BOOL ok=CreateProcessA(0,c,0,0,0,CREATE_NO_WINDOW,0,0,&si,&pi);'
                      'UINT w=WinExec("cmd.exe /c exit 0",0);freopen("crystal.out","w",stdout);'
                      'printf("cp=%d winexec=%u err=%lu\\n",ok,w,GetLastError());}\n'),
    "hostile_token": (WINH + '#include<cstdio>\nint main(){HANDLE t;OpenProcessToken(GetCurrentProcess(),'
                      'TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY,&t);LUID l;LookupPrivilegeValueA(0,"SeShutdownPrivilege",&l);'
                      'TOKEN_PRIVILEGES p;p.PrivilegeCount=1;p.Privileges[0].Luid=l;p.Privileges[0].Attributes=SE_PRIVILEGE_ENABLED;'
                      'AdjustTokenPrivileges(t,0,&p,0,0,0);DWORD e=GetLastError();JOBOBJECT_BASIC_UI_RESTRICTIONS u{};'
                      'BOOL q=QueryInformationJobObject(0,JobObjectBasicUIRestrictions,&u,sizeof u,0);'
                      'freopen("crystal.out","w",stdout);printf("adj=%lu ui=%d,%lx\\n",e,q,u.UIRestrictionsClass);}\n'),
    "hostile_files": (WINH + '#include<cstdio>\nint main(){const char*d[]={"C:/Windows/Temp/csp_pwn2.txt",'
                      '"../../../pwned.txt","../../../data/crystal1.in"};char o[200]="";int k=0;'
                      'for(auto x:d){FILE*f=fopen(x,"a");k=k*10+(f?1:0);if(f)fclose(f);}'
                      'FILE*a=fopen("../../../data/crystal1.ans","r");int ra=a?1:0;'
                      'FILE*i=fopen("crystal.in","r+");int ri=i?1:0;'
                      'FILE*h=fopen("C:/Users/Administrator/csp_pwn3.txt","w");int rh=h?1:0;'
                      'int rm=remove("../../../oi-sprint-agent.exe")==0;int rd=remove("../../../data/crystal2.in")==0;'
                      'freopen("crystal.out","w",stdout);printf("open%d ans%d in%d home%d rm%d rd%d\\n",k,ra,ri,rh,rm,rd);}\n'),
}


class Agent:
    def __init__(self):
        self.p = subprocess.Popen([WORKER + r"\oi-sprint-agent.exe", "serve", WORKER], stdin=subprocess.PIPE,
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        self.lines = {}
        self.done = {}
        self.cv = threading.Condition()
        self.hello = self.p.stdout.readline().decode().strip()
        threading.Thread(target=self.reader, daemon=True).start()

    def reader(self):
        for raw in self.p.stdout:
            a = raw.decode().split()
            if not a:
                continue
            with self.cv:
                if a[0] in ("COMPILE", "TEST"):
                    self.lines.setdefault(int(a[1]), []).append(a)
                elif a[0] == "DONE":
                    self.done[int(a[1])] = True
                self.cv.notify_all()

    def run(self, tid, prob, src, tests="1", tl=1300, ml=1024, flags=0):
        b = base64.b64encode(src.encode()).decode() or "-"
        self.p.stdin.write(f"TASK {tid} {prob} {tl} {ml} {flags} {tests} {b}\n".encode())
        self.p.stdin.flush()

    def wait(self, tid, timeout=120):
        end = time.time() + timeout
        with self.cv:
            while tid not in self.done and time.time() < end:
                self.cv.wait(1)
        return self.lines.get(tid, [])


def dec(s):
    return base64.b64decode(s).decode("utf8", "replace") if s != "-" else ""


def main():
    a = Agent()
    print("HELLO:", a.hello)
    ids = {}
    for i, (name, src) in enumerate(CASES.items(), 1):
        flags = 1 if "_unlocked" in src or "getchar_unlocked" in src else 0
        a.run(i, "crystal", src, flags=flags)
        ids[i] = name
    for i, name in ids.items():
        res = a.wait(i)
        out = []
        for r in res:
            if r[0] == "COMPILE":
                msg = dec(r[4])
                out.append(f"compile={r[2]}({r[3]}ms)" + (" " + next((l for l in msg.splitlines() if "error" in l), "")[:110] if r[2] == "CE" else ""))
            else:
                out.append(f"{r[3]} cpu={r[4]} wall={r[5]} mem={int(r[6]) // 1024}MB {dec(r[7])}")
        print(f"{name:20s} {' | '.join(out)}")
    # Timing check with nothing else running: wall should track cpu.
    n = len(ids) + 1
    a.run(n, "crystal", CASES["tle_spin"])
    r = a.wait(n)
    print("spin alone:", [x[3:6] for x in r if x[0] == "TEST"])
    # Fixed work (about 0.8 s on a P-core) at rising concurrency: cpu time should stay comparable.
    work = ('#include<cstdio>\nint main(){freopen("crystal.out","w",stdout);volatile unsigned long long n=0;'
            'for(long long i=0;i<4000000000LL;i++)n=n+1;printf("2\\n");}\n')
    n += 1
    for conc in (1, 8, 16, 24):
        ids2 = list(range(n, n + conc))
        n += conc
        for i in ids2:
            a.run(i, "crystal", work, tl=20000)
        vals = []
        for i in ids2:
            for x in a.wait(i):
                if x[0] == "TEST":
                    vals.append((int(x[4]), int(x[5])))
        cpus = sorted(v[0] for v in vals)
        walls = sorted(v[1] for v in vals)
        print(f"fixed work x{conc}: cpu min/med/max {cpus[0]}/{cpus[len(cpus)//2]}/{cpus[-1]}  wall max {walls[-1]}")
    a.p.stdin.close()


if __name__ == "__main__":
    main()
