"""Stage the portable toolchain without touching the original distribution."""
import io
import os
from pathlib import Path
import shutil
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "build" / "oi-sprint" / "worker"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    if not (OUT / "mingw" / "bin" / "g++.exe").exists():
        with zipfile.ZipFile(ROOT / "OI-Judge-Portable.zip") as z:
            bundle = z.read("OI-Judge/payload/runtime.tar.gz")
        with tarfile.open(fileobj=io.BytesIO(bundle), mode="r:gz") as tf:
            tf.extractall(OUT, filter="data")
    shutil.copytree(ROOT / "src" / "agent" / "compat", OUT / "compat", dirs_exist_ok=True)
    print("OI-Sprint toolchain staged:", OUT)


if __name__ == "__main__":
    main()
