"""Disposable frozen-build check: root -> SSH vice -> SSH worker, with forced outages."""
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid

ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build/oi-sprint-tree'
DIST=BUILD/'OI-Sprint-Tree'
RUN=BUILD/('ssh-check-'+uuid.uuid4().hex[:8])
RUN.mkdir()
APP=RUN/'app';APP.mkdir()
shutil.copytree(DIST/'payload',APP/'payload')


def port(host='127.0.0.1'):
    with socket.socket() as sock:
        sock.bind((host,0));return sock.getsockname()[1]


PORT,VICE_PORT,LEAF_PORT=port(),port('127.0.0.2'),port('127.0.0.3')
BASE=f'http://127.0.0.1:{PORT}'
env=dict(os.environ);env['PATH']=os.path.join(os.environ['SystemRoot'],'System32')
processes=[];logs=[]


def spawn(command,name):
    log=open(RUN/(name+'.log'),'ab');logs.append(log)
    proc=subprocess.Popen(command,stdout=log,stderr=log,env=env,creationflags=0x08000000)
    processes.append(proc);return proc


def kill(proc):
    if proc and proc.poll() is None:
        subprocess.run(['taskkill.exe','/PID',str(proc.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=0x08000000)
        proc.wait(timeout=8)


def ssh(which):
    host,number=('127.0.0.2',VICE_PORT) if which=='vice' else ('127.0.0.3',LEAF_PORT)
    home=RUN/(which+'-home');home.mkdir(exist_ok=True)
    return spawn([sys.executable,str(ROOT/'src/tools/test_ssh_server.py'),str(home),str(number),host],which)


def master():
    return spawn([str(DIST/'OI-Sprint-Tree.exe'),'--app-dir',str(APP),'--no-browser','--port',str(PORT)],'master')


def api(path,body=None):
    request=urllib.request.Request(BASE+path,None if body is None else json.dumps(body).encode(),
                                   {'X-Judge':'1','Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=15) as response:return json.load(response)


def wait(predicate,timeout=65,fail_errors=False):
    end=time.monotonic()+timeout;last=None
    while time.monotonic()<end:
        try:
            last=api('/api/state?since=0')
            if predicate(last):return last
            if fail_errors:
                errors=[(n['host'],n['error']) for n in last['nodes'] if n['stage']=='error']
                if errors:raise RuntimeError(errors)
            if last.get('preparing',{}):
                if last['preparing'].get('stage')=='error':raise RuntimeError(last['preparing'])
        except (urllib.error.URLError,ConnectionError):pass
        time.sleep(.08)
    raise TimeoutError(json.dumps(last,ensure_ascii=False)[:4500])


def completed(state):
    return state['problems'] and all(p['done']==p['total'] for p in state['problems'])


def verify():
    state=wait(completed)
    assert state['status']=={'AC':16},state['status']
    for student in ('s1','s2','s3','s4'):
        detail=api(f'/api/sub?sid={student}&prob=p')
        assert [t[1] for t in detail['tests']]==['AC']*4,detail
        assert detail['score']==100,detail
    wait(lambda s:all(n['inflight']==0 for n in s['nodes']))
    return state


def main():
    vice=leaf=root=None
    checks=[]
    try:
        vice,leaf=ssh('vice'),ssh('leaf')
        root=master();wait(lambda s:s['contest'] is None)
        data=RUN/'data';data.mkdir()
        for number in range(1,5):
            (data/f'p{number}.in').write_text(str(number)+'\n')
            (data/f'p{number}.ans').write_text(str(number)+'\n')
        code='#include<cstdio>\n#include<thread>\n#include<chrono>\nint main(){freopen("p.in","r",stdin);freopen("p.out","w",stdout);int n=0;scanf("%d",&n);volatile unsigned v=0;for(unsigned i=0;i<150000000u*(unsigned)n;++i)v+=i;if(n==4)std::this_thread::sleep_for(std::chrono::seconds(3));printf("%d\\n",n);}'
        answers=RUN/'answers'
        for student in ('s1','s2','s3','s4'):
            folder=answers/student;folder.mkdir(parents=True)
            (folder/'p.cpp').write_text(code)
        api('/api/contest/apply',dict(name='tree SSH audit',data=str(data),answers=str(answers),scale=False,
                                     problems=[dict(id='p',name='p',tl=10000,ml=128,full=100)]))
        wait(lambda s:s['contest'] and not s['preparing'])
        joined=api('/api/nodes/batch',dict(role='relay',addresses='127.0.0.2',user='test',port=VICE_PORT,
                                         auth='password',password='testpw',slots=2))
        assert joined['added']==1,joined
        rid=joined['ids'][0]
        api('/api/nodes/batch',dict(role='worker',addresses='127.0.0.3',user='test',port=LEAF_PORT,
                                  auth='password',password='testpw',slots=2,relay=rid))
        online=wait(lambda s:len([n for n in s['nodes'] if n.get('managed') and n['stage']=='online'])==2,100,True)
        own=next(n for n in online['nodes'] if n.get('relay_local'))
        child=next(n for n in online['nodes'] if n.get('managed') and not n.get('relay_local'))
        print('PASS frozen root -> SSH vice -> SSH worker; both compute nodes online',flush=True)
        checks.append('frozen SSH tree deployment')
        api('/api/control',{'op':'start'})
        wait(lambda s:s['problems'][0]['done']>=1 and not completed(s) and any(n['inflight'] for n in s['nodes'] if n.get('managed')))
        kill(leaf);leaf=ssh('leaf')
        first=verify()
        wait(lambda s:next(n for n in s['nodes'] if n['id']==child['id'])['stage']=='online')
        print('PASS worker process/SSH outage: no missing or duplicate points; 16 AC, 400 total',flush=True)
        checks.append('worker outage and recovery')
        api('/api/act',{'op':'rejudge'})
        wait(lambda s:s['problems'][0]['done']>=1 and not completed(s))
        kill(vice);vice=ssh('vice')
        second=verify()
        print('PASS vice process/SSH outage: branch recreated, saved points retained; 16 AC, 400 total',flush=True)
        checks.append('vice outage and recovery')
        wait(lambda s:len([n for n in s['nodes'] if n.get('managed') and n['stage']=='online'])==2)
        api('/api/nodes/update',{'id':own['id'],'slots':0})
        api('/api/relays/reconnect',{'id':rid})
        zero=wait(lambda s:all(n['stage']=='online' for n in s['nodes'] if n.get('managed')))
        assert next(n for n in zero['nodes'] if n['id']==own['id'])['slots']==0,zero['nodes']
        api('/api/control',{'op':'pause'})
        exported=urllib.request.urlopen(BASE+'/api/export',timeout=15).read().decode('utf8')
        start=exported.index('const EXPORT = ')+len('const EXPORT = ')
        report,_=json.JSONDecoder().raw_decode(exported[start:])
        assert all(row[1]==100 for row in report['rows']) and report['status']=={'AC':16}
        kill(root);root=master()
        restored=wait(lambda s:s['contest'] is not None and len(s['rows'])==4)
        assert restored['rows']==second['rows'],(restored['rows'],second['rows'])
        print('PASS zero concurrency after reconnect; HTML totals; process restart restores all scores',flush=True)
        checks.append('zero slots, export, persistence')
        result={'checks':checks,'points':16,'total_score':400,'run':str(RUN)}
        (RUN/'result.json').write_text(json.dumps(result,indent=2))
        print(json.dumps(result),flush=True)
    finally:
        for proc in reversed(processes):kill(proc)
        for log in logs:log.close()


if __name__=='__main__':main()
