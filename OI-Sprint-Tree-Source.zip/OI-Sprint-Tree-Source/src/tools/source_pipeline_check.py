"""One bounded synthetic comparison plus source-byte / analysis equivalence."""
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import zipfile

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'master'))
import contest as C
import judge as J
import scan


def main():
    with tempfile.TemporaryDirectory(prefix='sprint-source-pipe-') as folder:
        root=Path(folder);answer=root/'answers';answer.mkdir()
        sources={};raws={}
        functions='\n'.join(f'int f{i}(int x){{return x*{i+1}+{i};}}' for i in range(100))
        variants=['int main(){return 0;}',
                  '// shutdown("x")\nint main(){long /* comment */ long x=0;return x;}',
                  'int main(){system("shutdown /s");}',
                  'const char *s="%ld";int main(){long x=1;printf("%ld",x);}',
                  '#define F "%ld"\nint main(){long x=1;printf(F,x);}']
        count=2304
        for i in range(count):
            sid=f's{i:05}';student=answer/sid;student.mkdir()
            raw=(f'// 选手 {i}\n#include<cstdio>\n'+functions+'\n'+variants[i%len(variants)]).encode('gb18030' if i%3==0 else 'utf8')
            if i%7==0:raw=b'\xef\xbb\xbf'+raw.decode('gb18030' if i%3==0 else 'utf8').encode('utf8')
            path=student/'p.cpp';path.write_bytes(raw);sources[sid]=str(path);raws[sid]=raw
        report,answers,_,students=C.scan(str(root),str(answer))
        assert len(students)==count and answers['p']==sources
        # Warm identical input files before both timings.
        for path in sources.values():Path(path).read_bytes()
        problem=dict(id='p',tests=1,points=[100])
        old=root/'old.zip';started=time.perf_counter()
        with zipfile.ZipFile(old,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
            for sid,path in sources.items():archive.write(path,f'{sid}/p/p.cpp')
        expected={}
        with zipfile.ZipFile(old) as archive:
            for sid in sources:
                raw=archive.read(f'{sid}/p/p.cpp')
                expected[sid]=J.Sub(sid,problem,scan.decode_source(raw),raw)
        old_time=time.perf_counter()-started
        actual={};new=root/'new.zip';started=time.perf_counter()
        def consume(p,sid,raw,analysis):
            actual[sid]=J.Sub(sid,problem,analysis[0],raw,source_analysis=analysis)
        C.pack_answers({'p':sources},['p'],str(new),analyzer=scan.prepare_source,consume=consume)
        new_time=time.perf_counter()-started
        with zipfile.ZipFile(new) as archive:
            for sid,sub in actual.items():
                assert archive.read(f'{sid}/p/p.cpp')==raws[sid]
                before=expected[sid]
                assert (sub.code,sub.wire,sub.flags,sub.rewritten,sub.reasons)==(before.code,before.wire,before.flags,before.rewritten,before.reasons)
        assert len(actual)==count
        original=new.read_bytes()
        def cancel(*args):raise RuntimeError('cancel')
        try:C.pack_answers({'p':sources},['p'],str(new),progress=cancel)
        except RuntimeError:pass
        else:raise AssertionError('cancel ignored')
        assert new.read_bytes()==original and not Path(str(new)+'.tmp').exists()
        print('PASS parallel scans and process analysis preserve bytes, encoding, isolation and rewritten source; cancellation is atomic',flush=True)
        result=dict(files=count,workers=min(4,os.cpu_count() or 1),old_seconds=round(old_time,3),new_seconds=round(new_time,3),
                    conditions='same generated files, both input caches warm; old ZIP+reload versus fused process pipeline')
        output=Path(__file__).resolve().parents[2]/'build/oi-sprint-tree/source-pipeline-result.json'
        output.write_text(json.dumps(result,indent=2))
        print(json.dumps(result),flush=True)


if __name__=='__main__':main()
