"""Windowless Windows supervisor for a dedicated WSL2 distribution.

The frozen executable is built with --noconsole. All child processes explicitly
use CREATE_NO_WINDOW. No student program executes in this Windows process.
"""
import argparse
import ctypes
import datetime
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tarfile
import threading
import time

HIDDEN=0x08000000
DISTRO='OI-Sprint-Linux'
GUEST_PORT=38777


class Blob(ctypes.Structure):
    _fields_=[('size',ctypes.c_ulong),('data',ctypes.POINTER(ctypes.c_char))]


def protect_secret(value,encrypt=True):
    import base64
    raw=value.encode() if encrypt else base64.b64decode(value)
    buffer=ctypes.create_string_buffer(raw)
    source=Blob(len(raw),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_char)));target=Blob()
    function=ctypes.windll.crypt32.CryptProtectData if encrypt else ctypes.windll.crypt32.CryptUnprotectData
    if not function(ctypes.byref(source),None,None,None,None,0,ctypes.byref(target)):
        raise RuntimeError('无法保护后台节点接入凭据')
    try:result=ctypes.string_at(target.data,target.size)
    finally:ctypes.windll.kernel32.LocalFree(ctypes.cast(target.data,ctypes.c_void_p))
    return base64.b64encode(result).decode() if encrypt else result.decode()


def check_listener(port,fingerprint,deadline_seconds=90):
    import ssl,hashlib
    context=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);context.check_hostname=False;context.verify_mode=ssl.CERT_NONE
    deadline=time.monotonic()+deadline_seconds
    while time.monotonic()<deadline:
        try:
            with socket.create_connection(('127.0.0.1',port),timeout=2) as raw,context.wrap_socket(raw) as secure:
                if hashlib.sha256(secure.getpeercert(binary_form=True)).hexdigest()!=fingerprint:
                    raise RuntimeError('后台端口证书不匹配')
            return
        except OSError:time.sleep(1)
    raise RuntimeError('后台服务未就绪，请查看 supervisor.log；不将部署标记为成功')


def run(command,timeout=60,**kwargs):
    return subprocess.run(command,creationflags=HIDDEN,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                          timeout=timeout,**kwargs)


def decoded(raw):
    return raw.decode('utf-16-le' if b'\x00' in raw[:80] else 'utf8','replace').strip('\ufeff\x00\r\n ')


def wsl(*command,timeout=60,**kwargs):
    result=run(['wsl.exe','--distribution',DISTRO,'--user','root','--exec',*command],timeout,**kwargs)
    if result.returncode:
        raise RuntimeError(decoded(result.stderr or result.stdout)[-1200:] or 'WSL 执行失败')
    return result.stdout


def atomic_json(path,value):
    temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(value,ensure_ascii=False),encoding='utf8')
    os.replace(temporary,path)


def register_background(folder,port):
    executable=Path(sys.executable).resolve()
    if not getattr(sys,'frozen',False):
        raise RuntimeError('后台任务必须使用 --noconsole 打包后的节点程序')
    user=decoded(run(['whoami.exe']).stdout)
    task='OI-Sprint-Linux-Background'
    command=subprocess.list2cmdline([str(executable),'--serve','--folder',str(folder)])
    result=run(['schtasks.exe','/Create','/TN',task,'/SC','ONSTART','/RU',user,'/NP','/RL','HIGHEST','/TR',command,'/F'])
    if result.returncode:
        raise RuntimeError('无法注册无窗口后台任务：'+decoded(result.stderr or result.stdout)[-500:])
    settings="Set-ScheduledTask -TaskName 'OI-Sprint-Linux-Background' -Settings (New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden) | Out-Null"
    result=run(['powershell.exe','-NoProfile','-NonInteractive','-WindowStyle','Hidden','-Command',settings])
    if result.returncode:raise RuntimeError('后台任务自动恢复设置失败：'+decoded(result.stderr)[-500:])
    firewall="if (-not (Get-NetFirewallRule -DisplayName 'OI-Sprint Linux Node' -ErrorAction SilentlyContinue)) { New-NetFirewallRule -DisplayName 'OI-Sprint Linux Node' -Direction Inbound -Action Allow -Protocol TCP -LocalPort "+str(port)+" -Program '"+str(executable).replace("'","''")+"' -RemoteAddress LocalSubnet -Profile Any -ErrorAction Stop | Out-Null }"
    result=run(['powershell.exe','-NoProfile','-NonInteractive','-WindowStyle','Hidden','-Command',firewall])
    if result.returncode:raise RuntimeError('后台节点防火墙规则创建失败：'+decoded(result.stderr)[-500:])
    run(['schtasks.exe','/Run','/TN',task])


def prepare(folder,request):
    if not ctypes.windll.shell32.IsUserAnAdmin():
        raise RuntimeError('首次后台部署需要管理员权限，用于注册计划任务及配置专用端口')
    result=run(['wsl.exe','--list','--quiet'])
    if result.returncode:
        raise RuntimeError('WSL2 尚不可用。请先启用 WSL 和虚拟机平台，完成必要重启；部署不会自动重启电脑。')
    distributions=decoded(result.stdout).splitlines()
    if DISTRO not in [name.strip() for name in distributions]:
        image=folder/'linux-rootfs.tar.gz'
        if not image.is_file():
            raise RuntimeError('缺少随版本提供的 linux-rootfs.tar.gz，不能部署未固定的系统环境')
        installed=folder/'wsl-system';installed.mkdir(exist_ok=True)
        result=run(['wsl.exe','--import',DISTRO,str(installed),str(image),'--version','2'],timeout=1800)
        if result.returncode:raise RuntimeError(decoded(result.stderr or result.stdout)[-1000:])
    # The immutable base image must already contain the pinned GCC and Isolate.
    manifest=json.loads(wsl('/usr/bin/cat','/etc/oi-sprint-linux-image.json'))
    if manifest.get('version')!=request['image_version']:
        raise RuntimeError('Linux 环境版本不匹配，请使用对应发行版载荷；不会覆盖已有环境')
    identity_path=folder/'identity.json'
    if identity_path.is_file():
        identity=json.loads(identity_path.read_text(encoding='utf8'))
        if identity.get('image_version')!=request['image_version']:
            raise RuntimeError('已有节点的 Linux 镜像版本不同，需要先完成节点迁移后更新')
        if identity.get('runtime_version')!=request['runtime_version']:
            raise RuntimeError('已有后台代理版本不同，安全更新流程尚未完成；未改动运行环境')
        token=protect_secret(identity['token_sealed'],False)
        register_background(folder,identity['port'])
        check_listener(identity['port'],identity['fingerprint'])
        return {**{k:v for k,v in identity.items() if k not in ('token_sealed','runtime_version')},'ok':True,'token':token}
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes,serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID
    key=ec.generate_private_key(ec.SECP256R1())
    subject=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'OI-Sprint Linux Node')])
    now=datetime.datetime.now(datetime.timezone.utc)
    certificate=(x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(key.public_key())
                 .serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(minutes=5))
                 .not_valid_after(now+datetime.timedelta(days=3650)).sign(key,hashes.SHA256()))
    import hashlib,secrets
    token=secrets.token_hex(32)
    config={'root':'/var/lib/oi-sprint-linux','port':GUEST_PORT,'token':token,
            'compiler':manifest['compiler'],'isolate':'/opt/oi-sprint-linux/bin/isolate',
            'certificate':'/etc/oi-sprint-linux/node.crt','private_key':'/etc/oi-sprint-linux/node.key',
            'cgroup_root':'/sys/fs/cgroup/oisprintlinux'}
    contents={
        'etc/oi-sprint-linux/node.json':json.dumps(config).encode(),
        'etc/oi-sprint-linux/node.crt':certificate.public_bytes(serialization.Encoding.PEM),
        'etc/oi-sprint-linux/node.key':key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())}
    with tarfile.open(folder/'linux-agent.tar.gz','r:gz') as source:
        for member in source:
            if not member.isfile() or '/' in member.name or not member.name.endswith('.py'):
                raise RuntimeError('Linux 代理载荷包含无效条目')
            contents['opt/oi-sprint-linux/agent/'+member.name]=source.extractfile(member).read()
    archive=io.BytesIO()
    with tarfile.open(fileobj=archive,mode='w:gz') as target:
        for name,content in contents.items():
            item=tarfile.TarInfo(name);item.size=len(content);item.mode=0o600
            target.addfile(item,io.BytesIO(content))
    # Linux files stay in its filesystem. No drive mount is needed after deployment.
    script="import tarfile,sys;tarfile.open(fileobj=sys.stdin.buffer,mode='r|gz').extractall('/',filter='data')"
    wsl('/usr/bin/python3','-c',script,input=archive.getvalue(),timeout=120)
    port=next((p for p in range(8877,8897) if port_available(p)),None)
    if port is None:raise RuntimeError('8877 到 8896 均被占用，无法建立节点后台端口')
    atomic_json(folder/'supervisor.json',{'port':port})
    fingerprint=certificate.fingerprint(hashes.SHA256()).hex()
    identity={'port':port,'token_sealed':protect_secret(token),'fingerprint':fingerprint,
              'image_version':request['image_version'],'runtime_version':request['runtime_version']}
    atomic_json(identity_path,identity)
    register_background(folder,port)
    check_listener(port,fingerprint)
    return {'ok':True,'port':port,'token':token,'fingerprint':fingerprint,'image_version':request['image_version']}


def port_available(port):
    try:
        with socket.socket() as listener:listener.bind(('0.0.0.0',port))
        return True
    except OSError:return False


def forward(client,address):
    upstream=None
    try:
        upstream=socket.create_connection(address,timeout=10)
        client.settimeout(None);upstream.settimeout(None)
        def copy(source,target):
            try:
                while block:=source.recv(1<<16):target.sendall(block)
            except OSError:pass
            finally:
                try:target.shutdown(socket.SHUT_WR)
                except OSError:pass
        thread=threading.Thread(target=copy,args=(client,upstream),daemon=True);thread.start()
        copy(upstream,client);thread.join(5)
    finally:
        client.close()
        if upstream:upstream.close()


def serve(folder):
    config=json.loads((folder/'supervisor.json').read_text())
    with open(folder/'supervisor.log','ab',buffering=0) as log:
        proc=subprocess.Popen(['wsl.exe','-d',DISTRO,'-u','root','--exec','/usr/bin/python3',
                               '/opt/oi-sprint-linux/agent/start.py','--config','/etc/oi-sprint-linux/node.json'],
                              creationflags=HIDDEN,stdin=subprocess.DEVNULL,stdout=log,stderr=log)
        try:
            address=wsl('/bin/hostname','-I').decode().split()[0]
            with socket.socket() as listener:
                listener.bind(('0.0.0.0',config['port']));listener.listen(32);listener.settimeout(2)
                while proc.poll() is None:
                    try:client,_=listener.accept()
                    except socket.timeout:continue
                    threading.Thread(target=forward,args=(client,(address,GUEST_PORT)),daemon=True).start()
            raise RuntimeError('Linux 服务退出，代码 '+str(proc.returncode))
        finally:
            if proc.poll() is None:proc.terminate()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--folder',required=True)
    parser.add_argument('--serve',action='store_true');parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--request');parser.add_argument('--result')
    args=parser.parse_args();folder=Path(args.folder).resolve();folder.mkdir(parents=True,exist_ok=True)
    if args.serve:
        return serve(folder)
    if not args.prepare or not args.request or not args.result:raise SystemExit(2)
    request_path=Path(args.request)
    try:
        request=json.loads(request_path.read_text(encoding='utf8'));result=prepare(folder,request)
    except Exception as error:result={'ok':False,'error':str(error)[:1600]}
    atomic_json(Path(args.result),result)
    return 0 if result['ok'] else 1


if __name__=='__main__':raise SystemExit(main())
