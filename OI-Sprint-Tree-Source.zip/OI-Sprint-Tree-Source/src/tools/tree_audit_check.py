"""Focused audit regressions. Only disposable data; never run the real contest."""
import base64
import io
import os
from pathlib import Path
import queue
import subprocess
import sys
import tarfile
import tempfile
import threading
from types import SimpleNamespace

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'master'))
sys.path.insert(0,str(Path(__file__).resolve().parent))
import assigned_data as D
import broker
import judge as J
import relay
from sprint_checks import fixture,take


def main():
    with tempfile.TemporaryDirectory(prefix='sprint-audit-') as raw:
        root=Path(raw);name='data_0123456789abcdef'
        source=root/'source';source.mkdir()
        (source/'p1.in').write_bytes(b'2\n');(source/'p1.ans').write_bytes(b'2\n')
        packet=root/'packet.tar.gz'
        D.write_packet(packet,[(p,name+'/'+p.name) for p in source.iterdir()])
        target=root/'installed'
        D.install_packet(packet,target,name)
        assert (target/name/'p1.in').read_bytes()==b'2\n'
        (target/name/'p1.in').write_bytes(b'broken')
        D.install_packet(packet,target,name)
        assert (target/name/'p1.in').read_bytes()==b'2\n'
        corrupt=root/'corrupt.tar.gz'
        with tarfile.open(packet) as old,tarfile.open(corrupt,'w:gz') as new:
            for entry in old:
                data=old.extractfile(entry).read()
                if entry.name.endswith('.in'):data=b'3\n'
                new.addfile(entry,io.BytesIO(data))
        try:D.install_packet(corrupt,target,name)
        except ValueError:pass
        else:raise AssertionError('corrupt packet accepted')
        assert (target/name/'p1.in').read_bytes()==b'2\n'
        truncated=root/'truncated.tar.gz';truncated.write_bytes(packet.read_bytes()[:len(packet.read_bytes())//2])
        try:D.install_packet(truncated,root/'truncated-target',name)
        except (OSError,ValueError,EOFError,tarfile.TarError):pass
        else:raise AssertionError('truncated packet accepted')
        assert not (root/'truncated-target'/name/'p1.in').exists()
        # Exercise the exact no-Python installer used by SSH leaves.
        remote=root/'remote';remote.mkdir();(remote/'packet.tar.gz').write_bytes(packet.read_bytes())
        script=D.install_script(remote,'packet.tar.gz',D.digest(packet),name)
        encoded=base64.b64encode(script.encode('utf-16le')).decode('ascii')
        installed=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',encoded],
                                 stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,creationflags=0x08000000)
        assert installed.returncode==0,installed.stderr.decode('utf8','replace')
        assert (remote/name/'p1.in').read_bytes()==b'2\n'
        print('PASS complete/checksummed/atomic local and Windows leaf installation')

        j,s,a,b=fixture();j.contest={'scale':True}
        a.curve=[(1,500000),(8,200000)];a.slots=1
        before=a.factor();a.slots=8
        assert a.factor()==before
        task=take(j,a);a.curve=[(1,250000)]
        assert task.factor==before
        j,s,a,b=fixture();s.problem.update(name='p',full=100)
        j.contest={'scale':False,'name':'audit','problems':j.problems}
        restarted=[];a.gateway=True;a.restart=lambda:restarted.append(True)
        j._save_contest=lambda:None
        with j.lock:j._update_in_place({'scale':True,'name':'audit','problems':[dict(s.problem)]})
        assert restarted==[True]
        print('PASS concurrency-independent limits and frozen running-task factor')

        j,s,a,b=fixture(1);j.failure_limit=broker.Broker.failure_limit
        t=take(j,a);j.on_test(t,1,'SE',0,0,0,'broken input','a');j.on_done(t,failed=True)
        assert s.tests[1][0]=='SE' and J.Judge.failure_limit==5 and j.failure_limit==1
        print('PASS one retry budget across root and relay')

        j,s,a,b=fixture(1);t=take(j,a)
        assert not j.on_test(t,1,'TLE',20,3000,1,'','a') and not s.tests
        j.on_done(t)
        retry=take(j,b)
        assert j.on_test(retry,1,'TLE',1001,1100,1,'','b')
        print('PASS inconsistent low-CPU TLE is retried instead of scored')

        j,s,a,b=fixture();j.running=True;a.stage='online';a.session=7;a.alive=True
        j.prepare_task=lambda node,task:(j._invalidate(s),setattr(a,'alive',False))
        a._dispatch(7)
        assert not a.inflight and not s.tasks and not s.attempts
        print('PASS cancelled preparation releases its unsent slot')

        old_protocol=J.PROTOCOL
        try:
            J.PROTOCOL='OI-SPRINT-TREE/1';a.slots=16;a.info={'mem':16384}
            assert a.compile_limit()==4
            a.info['mem']=4096;assert a.compile_limit()==1
        finally:J.PROTOCOL=old_protocol

        conn=relay.Connection(SimpleNamespace())
        conn.messages=queue.Queue(maxsize=1);conn.messages.put(b'old result')
        conn.close();assert conn.messages.get_nowait()==b''
        print('PASS bounded compilation and nonblocking close under backpressure')

        # Repeated leases must not upload/decompress the same test packet again.
        packets=root/'packets';packets.mkdir()
        fake=SimpleNamespace(assigned_root=str(source.parent),state_dir=str(root/'state'),data_dirname=lambda:name)
        (source.parent/name).mkdir()
        for p in source.iterdir():(source.parent/name/p.name).write_bytes(p.read_bytes())
        long_packet=relay.data_package(fake,'p',list(range(1,2)))
        assert len(long_packet.name)<100
        sent=[]
        node=SimpleNamespace(gateway=True,judge=fake)
        connection=relay.Connection(node)
        connection.hub=SimpleNamespace(conn=SimpleNamespace(client=SimpleNamespace(open_sftp=lambda:SimpleNamespace(close=lambda:None)),sftp_dir='remote'),
                                       upload=lambda *args:sent.append('upload'),send=lambda msg:sent.append(msg['op']))
        connection.send(b'TASK 1 p 1000 128 0 1 -\nTASK 2 p 1000 128 0 1 -\n')
        assert sent==['upload','data','send','send'],sent
        print('PASS one packet transfer per connection and bounded packet filename')


if __name__=='__main__':main()
