"""Throwaway SSH/SFTP server for exercising the master's deploy path without touching system settings.
Behaves like Win32-OpenSSH: exec goes through cmd.exe, SFTP paths look like /C:/Users/x.
Usage: test_ssh_server.py <home dir> [port]. Listens on 127.0.0.1 only; password is "testpw",
or empty for user "nopw"."""
import os
import socket
import ipaddress
import subprocess
import sys
import threading
import time

import paramiko
from paramiko import SFTPAttributes, SFTPHandle, SFTPServer, SFTPServerInterface
from paramiko.sftp import SFTP_FAILURE, SFTP_NO_SUCH_FILE, SFTP_OK

HOME = os.path.abspath(sys.argv[1]).replace("\\", "/")
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 2222
BIND = sys.argv[3] if len(sys.argv) > 3 else "127.0.0.1"
if not ipaddress.ip_address(BIND).is_loopback:
    raise ValueError("Disposable test server must stay on loopback")
SLOW_ORIGINAL = "--slow-original" in sys.argv
KEY = paramiko.RSAKey.generate(2048)


def to_local(path):
    path = path.replace("\\", "/")
    if path in (".", ""):
        return HOME
    if path.startswith("/") and len(path) > 2 and path[2] == ":":
        return path[1:]
    if not path.startswith("/"):
        return HOME + "/" + path
    return path


class Handle(SFTPHandle):
    slow = False

    def write(self, offset, data):
        if self.slow:
            time.sleep(.01)
        return super().write(offset, data)

    def stat(self):
        return SFTPAttributes.from_stat(os.fstat(self.readfile.fileno() if self.readfile else self.writefile.fileno()))


class SFTP(SFTPServerInterface):
    def canonicalize(self, path):
        return "/" + HOME if path in (".", "") else (path if path.startswith("/") else "/" + HOME + "/" + path)

    def stat(self, path):
        try:
            return SFTPAttributes.from_stat(os.stat(to_local(path)))
        except OSError:
            return SFTP_NO_SUCH_FILE

    lstat = stat

    def open(self, path, flags, attr):
        p = to_local(path)
        try:
            fd = os.open(p, flags | getattr(os, "O_BINARY", 0), 0o666)
        except OSError:
            return SFTP_NO_SUCH_FILE
        h = Handle(flags)
        h.slow = SLOW_ORIGINAL and os.path.relpath(p, HOME).replace("\\", "/") == ".oi_sprint_classic/bundle.tar.gz"
        if flags & os.O_WRONLY:
            h.writefile = os.fdopen(fd, "wb")
        elif flags & os.O_RDWR:
            h.readfile = h.writefile = os.fdopen(fd, "r+b")
        else:
            h.readfile = os.fdopen(fd, "rb")
        return h

    def list_folder(self, path):
        p = to_local(path)
        out = []
        for name in os.listdir(p):
            a = SFTPAttributes.from_stat(os.stat(os.path.join(p, name)))
            a.filename = name
            out.append(a)
        return out

    def mkdir(self, path, attr):
        try:
            os.mkdir(to_local(path))
            return SFTP_OK
        except OSError:
            return SFTP_FAILURE

    def remove(self, path):
        try:
            os.remove(to_local(path))
            return SFTP_OK
        except OSError:
            return SFTP_FAILURE

    def rename(self, oldpath, newpath):
        try:
            os.rename(to_local(oldpath),to_local(newpath))
            return SFTP_OK
        except OSError:return SFTP_FAILURE

    def posix_rename(self, oldpath, newpath):
        try:
            os.replace(to_local(oldpath),to_local(newpath))
            return SFTP_OK
        except OSError:return SFTP_FAILURE


class Server(paramiko.ServerInterface):
    def check_auth_password(self, username, password):
        ok = password == "testpw" or (username == "nopw" and password == "")
        return paramiko.AUTH_SUCCESSFUL if ok else paramiko.AUTH_FAILED

    def get_allowed_auths(self, username):
        return "password"

    def check_channel_request(self, kind, chanid):
        return paramiko.OPEN_SUCCEEDED

    def check_channel_exec_request(self, channel, command):
        threading.Thread(target=run_exec, args=(channel, command.decode()), daemon=True).start()
        return True


def run_exec(chan, cmd):
    p = subprocess.Popen("cmd.exe /c " + cmd, cwd=HOME, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, creationflags=0x08000000)

    def pump_in():
        try:
            while True:
                d = chan.recv(65536)
                if not d:
                    break
                p.stdin.write(d)
                p.stdin.flush()
        except Exception:
            pass
        try:
            p.stdin.close()
        except OSError:
            pass

    def pump_err():
        for d in iter(lambda: p.stderr.read(4096), b""):
            chan.sendall_stderr(d)

    threading.Thread(target=pump_in, daemon=True).start()
    t = threading.Thread(target=pump_err, daemon=True)
    t.start()
    for d in iter(lambda: p.stdout.read1(65536), b""):
        chan.sendall(d)
    p.wait()
    t.join(2)
    chan.send_exit_status(p.returncode)
    chan.close()


def handle(sock):
    tr = paramiko.Transport(sock)
    tr.add_server_key(KEY)
    tr.set_subsystem_handler("sftp", SFTPServer, SFTP)
    tr.start_server(server=Server())
    while tr.is_active():
        tr.join(5)


def main():
    os.makedirs(HOME, exist_ok=True)
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((BIND, PORT))
    s.listen(16)
    print("listening", PORT, flush=True)
    while True:
        c, _ = s.accept()
        threading.Thread(target=handle, args=(c,), daemon=True).start()


if __name__ == "__main__":
    main()
