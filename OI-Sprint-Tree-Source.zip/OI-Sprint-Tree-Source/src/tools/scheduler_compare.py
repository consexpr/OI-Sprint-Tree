"""One warm-cache batch comparison, same input/agent/slots/compile limit for both policies."""
import json
from pathlib import Path
import shutil
import sys
import time
import types
import uuid

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src/master'))
import tree_main
import judge as J


def main():
    run=ROOT/'build/oi-sprint-tree'/('scheduler-compare-'+uuid.uuid4().hex[:8]);run.mkdir()
    shutil.copytree(ROOT/'build/oi-sprint-tree/OI-Sprint-Tree/payload',run/'payload')
    data=run/'data';data.mkdir();answers=run/'answers'
    code='#include<cstdio>\nint main(){freopen("PROB.in","r",stdin);freopen("PROB.out","w",stdout);unsigned n=0;scanf("%u",&n);volatile unsigned v=0;for(unsigned i=0;i<n;++i)v+=i;printf("%u\\n",n);}'
    for problem in ('fast','slow'):
        for number in range(1,9):
            n=1000000 if problem=='fast' or number%2 else 200000000
            for extension in ('.in','.ans'):(data/(problem+str(number)+extension)).write_text(str(n)+'\n')
        for student in ('s1','s2','s3','s4'):
            folder=answers/student;folder.mkdir(parents=True,exist_ok=True)
            (folder/(problem+'.cpp')).write_text(code.replace('PROB',problem))
    judge=J.Judge(str(run));node=None
    def wait(predicate,timeout=45):
        end=time.monotonic()+timeout
        while time.monotonic()<end:
            with judge.lock:
                if predicate():return
                if judge.preparing and judge.preparing.get('stage')=='error':raise RuntimeError(judge.preparing)
                if node and node.stage=='error':raise RuntimeError(node.error)
            time.sleep(.005)
        raise TimeoutError([(s.sid,s.prob,s.state,len(s.tests)) for s in judge.subs.values()])
    try:
        judge.configure(dict(name='scheduler comparison',data=str(data),answers=str(answers),scale=False,
                             problems=[dict(id=p,name=p,tl=5000,ml=128,full=100) for p in ('fast','slow')]))
        wait(lambda:judge.contest is not None and judge.preparing is None)
        judge.load_nodes();node=next(iter(judge.nodes.values()))
        node.set_slots(4);node.set_enabled(True)
        wait(lambda:node.stage=='online')
        def complete():return all(not s.remaining() for s in judge.subs.values()) and not node.inflight
        judge.start();wait(complete)  # Warm every executable and every input in both policies.
        current_start=judge.start_task;current_rebalance=judge.rebalance_tail
        def original_start(self,worker):
            if getattr(self.store,'error',None):return None
            for problem in self.problems:
                if not problem['on']:continue
                for sid in self.students:
                    sub=self.subs.get((sid,problem['id']))
                    if sub is None or not sub.queued or sub.tasks:continue
                    tests=sub.remaining()
                    if not tests:continue
                    sub.queued=False;self.ready_count-=1;sub.state='running';self.task_seq+=1
                    task=J.Task(self.task_seq,sub,sub.gen,worker,tests);sub.tasks[task.id]=task
                    return task
            return None
        rows=[]
        for policy in ('original_whole_submission','current'):
            judge.pause()
            judge.start_task=types.MethodType(original_start,judge) if policy.startswith('original') else current_start
            judge.rebalance_tail=(lambda:None) if policy.startswith('original') else current_rebalance
            judge.act('rejudge')
            before=node.cache_hits
            began=time.perf_counter();judge.start();wait(complete);elapsed=time.perf_counter()-began
            assert judge.status_counts=={'AC':64},judge.status_counts
            assert all(s.score()==100 for s in judge.subs.values())
            rows.append(dict(policy=policy,seconds=round(elapsed,4),points=64,cache_hits=node.cache_hits-before,
                             slots=node.slots,compile_limit=node.compile_limit(),cpu_limit=node.effective_cpu_limit()))
        result=dict(runs=rows,cache='both warm',same_input=True,same_agent=True,run=str(run))
        (run/'result.json').write_text(json.dumps(result,indent=2))
        print(json.dumps(result),flush=True)
    finally:
        judge.running=False
        if node:
            node.shutdown()
            if node.thread:node.thread.join(5)
        if judge.store:judge.store.close()


if __name__=='__main__':main()
