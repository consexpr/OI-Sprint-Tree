"""End-to-end control-plane test against a running master."""
import json
import sys
import time
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8767"


def get(path):
    with urllib.request.urlopen(BASE + path, timeout=60) as r:
        return json.loads(r.read())


def post(path, body):
    req = urllib.request.Request(BASE + path, json.dumps(body).encode(),
                                 {"Content-Type": "application/json", "X-Judge": "1"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())


def st():
    return get("/api/state?since=999999999")


def brief(s):
    return {"run": s["running"], "done": sum(p["done"] for p in s["problems"]),
            "eta": s["eta"] and round(s["eta"]), "rate": round(s["rate"], 1), "cap": s["capacity"],
            "nodes": [(n["host"], n["stage"], n["slots"], n["inflight"], n["done"], n["factor"]) for n in s["nodes"]],
            "status": s["status"]}


def show(label, value):
    print(f"[{label}] {value}", flush=True)


def wait_online(nid, tries=60):
    for _ in range(tries):
        time.sleep(1.5)
        n = next(x for x in st()["nodes"] if x["id"] == nid)
        if n["stage"] == "online":
            return n
    return n


def main():
    stage = sys.argv[2] if len(sys.argv) > 2 else "all"
    if stage in ("all", "control"):
        post("/api/nodes/update", {"id": 1, "slots": 6})
        post("/api/nodes/update", {"id": 2, "slots": 6})
        post("/api/control", {"op": "start"})
        time.sleep(30)
        show("after 30s", brief(st()))
        post("/api/nodes/update", {"id": 1, "slots": 10})
        time.sleep(8)
        show("slots raised to 10", brief(st())["nodes"])
        post("/api/nodes/update", {"id": 1, "slots": 6})

        post("/api/control", {"op": "pause"})
        time.sleep(1)
        a = brief(st())
        time.sleep(30)
        b = brief(st())
        show("pause drains", {"t+1s": (a["done"], [n[3] for n in a["nodes"]]), "t+31s": (b["done"], [n[3] for n in b["nodes"]])})
        time.sleep(10)
        c = brief(st())
        show("still paused, no new work", c["done"] == b["done"] or (c["done"], b["done"]))

        post("/api/control", {"op": "start"})
        time.sleep(12)
        show("resumed", brief(st())["nodes"])
        post("/api/nodes/update", {"id": 2, "enabled": False})
        time.sleep(3)
        show("remote node disabled", brief(st())["nodes"])
        post("/api/nodes/update", {"id": 2, "enabled": True})
        n = wait_online(2)
        show("remote rejoined", (n["stage"], n["info"].get("sandbox"), n["error"]))
        time.sleep(10)
        show("both working", brief(st())["nodes"])

    if stage in ("all", "act"):
        s = st()
        held = s["held"]
        show("held", held)
        before = get("/api/sub?sid=SC-S00791&prob=hub")
        show("S00791 state", (before["state"], before["reasons"], before["score"]))
        r = post("/api/act", {"op": "prioritize", "problems": ["hub"], "students": ["SC-S00005"]})
        show("prioritize", r)
        r = post("/api/act", {"op": "skip", "problems": ["subway"], "students": ["SC-S01900", "SC-S01901"]})
        show("skip", r)
        r = post("/api/act", {"op": "unskip", "problems": ["subway"], "students": ["SC-S01900", "SC-S01901"]})
        show("unskip", r)

        # Rejudge only the TLE tests of one finished submission.
        s = get("/api/state?since=0")
        target = None
        for row in s["rows"]:
            for i, strip in enumerate(row[3]):
                if "T" in strip and "." not in strip:
                    target = (row[0], s["problems"][i]["id"], strip)
                    break
            if target:
                break
        show("rejudge target", target)
        if target:
            r = post("/api/act", {"op": "rejudge", "problems": [target[1]], "students": [target[0]], "statuses": ["TLE"]})
            show("rejudge TLE", r)
            time.sleep(1)
            d = get(f"/api/sub?sid={target[0]}&prob={target[1]}")
            show("after rejudge pending", sum(1 for t in d["tests"] if t[1] is None))


if __name__ == "__main__":
    main()
