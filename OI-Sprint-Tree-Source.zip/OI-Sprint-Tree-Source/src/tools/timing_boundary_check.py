"""Four native points: bounded CPU work and infinite work, at 100% and 1% caps."""
import json
from pathlib import Path
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src/tools'))
import agent_test


def main():
    parent=ROOT/'build/oi-sprint-tree'
    work=max(parent.glob('artifact-check-*'),key=lambda p:p.stat().st_mtime)
    shutil.copyfile(parent/'OI-Sprint-Tree/payload/oi-sprint-tree-agent.exe',work/'oi-sprint-agent.exe')
    agent_test.WORKER=str(work.resolve())
    bounded='''#include<cstdio>
extern "C" __declspec(dllimport) void* __stdcall GetCurrentProcess();
extern "C" __declspec(dllimport) int __stdcall GetProcessTimes(void*,unsigned long long*,unsigned long long*,unsigned long long*,unsigned long long*);
int main(){unsigned long long c,e,k,u;GetProcessTimes(GetCurrentProcess(),&c,&e,&k,&u);auto start=k+u;
volatile unsigned x=0;do{for(unsigned i=0;i<50000;++i)x+=i;GetProcessTimes(GetCurrentProcess(),&c,&e,&k,&u);}while(k+u-start<500000);
freopen("sample.out","w",stdout);puts("2");}'''
    a=agent_test.Agent();rows=[]
    try:
        assert a.hello.startswith('HELLO '),a.hello
        tid=0
        for cap in (100,1):
            a.p.stdin.write(f'CONFIG 1 {cap}\n'.encode());a.p.stdin.flush()
            for name,source,expected,limit in (('50ms CPU work',bounded,'AC',250),('infinite work','int main(){for(;;);}','TLE',150)):
                tid+=1;a.run(tid,'sample',source,tl=limit,ml=128)
                result=a.wait(tid,30)
                point=next((r for r in result if r[0]=='TEST'),None)
                assert point and point[3]==expected,result
                if expected=='TLE':assert int(point[4])>limit,point
                else:assert int(point[4])<=limit,point
                rows.append(dict(cap=cap,program=name,status=point[3],cpu_ms=int(point[4]),wall_ms=int(point[5]),limit_ms=limit))
        (parent/'timing-result.json').write_text(json.dumps(rows,indent=2))
        print(json.dumps(rows),flush=True)
    finally:
        if a.p.poll() is None:
            a.p.stdin.close()
            try:a.p.wait(5)
            except Exception:a.p.kill();a.p.wait()


if __name__=='__main__':main()
