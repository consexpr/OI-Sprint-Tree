"""Scenario tests against a running master, using a generated contest with known results.
Harmless programs only. Usage: scenario_test.py <base url> <fixture dir> <ssh key> <ssh node dir> [real contest root]"""
import ctypes
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "master"))
import contest as C  # noqa: E402

BASE, FX, KEY, SSH_DIR = sys.argv[1:5]
REAL = sys.argv[5] if len(sys.argv) > 5 else None
fails = []


def check(name, ok, info=""):
    print(("PASS " if ok else "FAIL ") + name + (f"  {info}" if info != "" else ""), flush=True)
    if not ok:
        fails.append(name)


def post(path, body, ok_only=True):
    req = urllib.request.Request(BASE + path, json.dumps(body).encode(), {"Content-Type": "application/json", "X-Judge": "1"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        if ok_only:
            raise RuntimeError(e.read().decode())
        return {"http": e.code, **json.loads(e.read())}


def get(path):
    with urllib.request.urlopen(BASE + path, timeout=60) as r:
        return json.loads(r.read())


def st():
    return get("/api/state?since=999999999")


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf8", newline="\n") as f:
        f.write(text)


def layouts():
    t = tempfile.mkdtemp(dir=FX)
    # Subfolders with bare numbers and .out answers; flat with underscores; a problem whose id ends in a digit; samples.
    for i in (1, 2, 10):
        write(f"{t}/d/alpha/{i}.in", "1")
        write(f"{t}/d/alpha/{i}.out", "1")
        write(f"{t}/d/beta_{i:02d}.in", "1")
        write(f"{t}/d/beta_{i:02d}.ans", "1")
        write(f"{t}/d/p1{i}.in", "1")
        write(f"{t}/d/p1{i}.ans", "1")
    write(f"{t}/d/ex_gamma1.in", "1")
    write(f"{t}/d/ex_gamma1.ans", "1")
    write(f"{t}/d/noanswer1.in", "1")
    write(f"{t}/a/s1/alpha/alpha.cpp", "int main(){}")
    write(f"{t}/a/s1/beta.cpp", "int main(){}")
    write(f"{t}/a/s2/p1/main.cpp", "int main(){}")
    write(f"{t}/a/s2/ghost/ghost.cpp", "int main(){}")
    write(f"{t}/a/s3/.keep", "")
    r, _, data, students = C.scan(f"{t}/d", f"{t}/a")
    ids = {p["id"]: (p["tests"], p["subs"]) for p in r["problems"]}
    check("layouts: three structures found", ids == {"alpha": (3, 1), "beta": (3, 1), "p1": (3, 1)}, ids)
    check("layouts: numeric test order", [os.path.basename(a) for a, _ in data["alpha"]] == ["1.in", "2.in", "10.in"])
    check("layouts: unmatched reported", r["no_data"] == ["ghost"] and r["no_answers"] == ["ex_gamma"], r)
    check("layouts: .in without answer ignored", "noanswer" not in r["no_answers"])
    check("layouts: student without code counted", students == ["s1", "s2", "s3"], students)
    check("points add up", all(sum(C.points_for(f, n)) == f for f, n in ((100, 3), (100, 30), (7, 7), (0, 5), (100, 7))))
    shutil.rmtree(t, ignore_errors=True)


SPIN = """#include<bits/stdc++.h>
using namespace std;
int main(){freopen("slow.in","r",stdin);freopen("slow.out","w",stdout);long long a,b;cin>>a>>b;
volatile unsigned long long n=0;auto t=chrono::steady_clock::now();
while(chrono::duration<double>(chrono::steady_clock::now()-t).count()<%s)n=n+1;cout<<a+b<<endl;}
"""


def build_contest(root, students=120, tests=6):
    for i in range(1, tests + 1):
        write(f"{root}/data/slow{i}.in", f"{i} {i * 2}\n")
        write(f"{root}/data/slow{i}.ans", f"{i * 3}\n")
        write(f"{root}/data/mem{i}.in", f"{i}\n")
        write(f"{root}/data/mem{i}.ans", f"{i}\n")
    for s in range(1, students + 1):
        write(f"{root}/answers/T{s:03d}/slow/slow.cpp", SPIN % "0.5")
    # Stack follows the problem's memory limit: 100 MB of recursion passes at 256 MB, not at 64 MB.
    write(f"{root}/answers/T001/mem/mem.cpp", """#include<bits/stdc++.h>
using namespace std;
int f(int d){volatile char b[1024];b[0]=(char)d;if(d==0)return 0;return f(d-1)+(b[0]==(char)d?0:1);}
int main(){freopen("mem.in","r",stdin);freopen("mem.out","w",stdout);int x;cin>>x;cout<<x+f(100000)<<endl;}
""")
    write(f"{root}/answers/T002/mem/mem.cpp", """#include<bits/stdc++.h>
using namespace std;
int main(){freopen("mem.in","r",stdin);freopen("mem.out","w",stdout);int x;cin>>x;cout<<x<<endl;}
""")


def wait_ready(timeout=300):
    end = time.time() + timeout
    while time.time() < end:
        s = st()
        if not s["preparing"]:
            return s
        if s["preparing"].get("stage") == "error":
            raise RuntimeError(s["preparing"])
        time.sleep(0.5)
    raise RuntimeError("prepare timed out")


def wait_online(pred, timeout=240):
    end = time.time() + timeout
    while time.time() < end:
        ns = [n for n in st()["nodes"] if pred(n)]
        if ns and all(n["stage"] == "online" for n in ns):
            return ns[0]
        time.sleep(1)
    return next(iter([n for n in st()["nodes"] if pred(n)]), None)


def counts():
    s = st()
    return s, sum(p["done"] for p in s["problems"]), sum(p["total"] for p in s["problems"])


def suspend(pid, resume=False):
    h = ctypes.windll.kernel32.OpenProcess(0x0800, False, pid)  # PROCESS_SUSPEND_RESUME
    fn = ctypes.windll.ntdll.NtResumeProcess if resume else ctypes.windll.ntdll.NtSuspendProcess
    fn.argtypes = [ctypes.c_void_p]
    fn(ctypes.c_void_p(h))
    ctypes.windll.kernel32.CloseHandle(h)


def agent_pids(match):
    out = subprocess.run(["powershell", "-NoProfile", "-c",
                          "Get-CimInstance Win32_Process -Filter \"Name='oi-sprint-agent.exe'\" | ForEach-Object { \"$($_.ProcessId)|$($_.ExecutablePath)\" }"],
                         capture_output=True, text=True).stdout
    return [int(l.split("|")[0]) for l in out.splitlines() if match.lower() in l.lower()]


def main():
    layouts()

    # ---- no contest yet
    s = st()
    check("starts with no contest", s["contest"] is None, s["contest"])
    bad = post("/api/contest/scan", {"data": FX + "/none", "answers": FX + "/none"}, ok_only=False)
    check("bad folder is a readable error", bad.get("http") == 400 and "不存在" in bad["error"], bad)

    # ---- configure
    root = os.path.join(FX, "t1")
    build_contest(root)
    data, answers = root + "/data", root + "/answers"
    report = post("/api/contest/scan", {"data": data, "answers": answers})
    check("scan finds problems", [(p["id"], p["tests"], p["subs"]) for p in report["problems"]] == [("mem", 6, 2), ("slow", 6, 120)], report["problems"])
    check("students counted", report["students"] == 120)
    cfg = {"name": "测试赛 A", "data": data, "answers": answers, "scale": True,
           "problems": [{"id": "slow", "name": "慢题", "tl": 2000, "ml": 256, "full": 100},
                        {"id": "mem", "name": "栈题", "tl": 2000, "ml": 256, "full": 100}]}
    post("/api/contest/apply", cfg)
    s = wait_ready()
    check("contest active", s["contest"]["name"] == "测试赛 A" and len(s["students"] if False else s["problems"]) == 2, s["contest"])
    check("limits applied", sorted((p["id"], p["tl"], p["ml"], p["full"]) for p in s["problems"]) == [("mem", 2000, 256, 100), ("slow", 2000, 256, 100)], [(p["id"], p["tl"], p["ml"], p["full"]) for p in s["problems"]])

    # ---- nodes: local joins, judging starts, then a remote joins while running
    local = st()["nodes"][0]
    post("/api/nodes/update", {"id": local["id"], "enabled": True})
    n = wait_online(lambda x: x["local"])
    check("local node online", n and n["stage"] == "online", n and (n["stage"], n["error"], n["info"]))
    post("/api/nodes/update", {"id": local["id"], "slots": 4})
    time.sleep(1)
    post("/api/control", {"op": "start"})
    time.sleep(6)
    _, d0, total = counts()
    check("judging with one node", d0 > 0, (d0, total))
    cap0 = st()["capacity"]

    post("/api/nodes/add", {"text": f"Administrator@127.0.0.1:2222 key:{KEY} dir:{SSH_DIR}"})
    n = wait_online(lambda x: x["port"] == 2222)
    check("remote added without pausing", n and n["stage"] == "online" and st()["running"], n and (n["stage"], n["error"]))
    rid = n["id"]
    post("/api/nodes/update", {"id": rid, "slots": 4})
    time.sleep(4)
    n = next(x for x in st()["nodes"] if x["id"] == rid)
    check("remote receives work at once", n["inflight"] > 0, n["inflight"])
    check("capacity grows with the new node", st()["capacity"] > cap0, (cap0, st()["capacity"]))

    # ---- silent death: the process freezes with TCP still up, as with power loss
    pids = agent_pids(SSH_DIR.replace("/", "\\"))
    check("found remote agent", len(pids) == 1, pids)
    for pid in pids:
        suspend(pid)
    t0 = time.time()
    frozen = next(x for x in st()["nodes"] if x["id"] == rid)["inflight"]
    while time.time() - t0 < 70:
        time.sleep(1)
        n = next(x for x in st()["nodes"] if x["id"] == rid)
        if n["inflight"] == 0:
            break
    took = time.time() - t0
    check("frozen node detected, work returned", n["inflight"] == 0 and took < 65, f"{frozen} tasks back after {took:.0f}s, stage {n['stage']}")
    _, d1, _ = counts()
    time.sleep(5)
    _, d2, _ = counts()
    check("others keep judging meanwhile", d2 > d1, (d1, d2))
    for pid in pids:
        suspend(pid, resume=True)

    # ---- it comes back on its own
    n = wait_online(lambda x: x["id"] == rid, 120)
    check("frozen node rejoins by itself", n and n["stage"] == "online", n and (n["stage"], n["error"]))

    # ---- abrupt kill while working
    time.sleep(3)
    for pid in agent_pids(SSH_DIR.replace("/", "\\")):
        subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True)
    time.sleep(2)
    n = wait_online(lambda x: x["id"] == rid, 120)
    check("killed agent recovers", n and n["stage"] == "online", n and (n["stage"], n["error"]))

    # ---- everything finishes, nothing lost and nothing double counted
    end = time.time() + 300
    while time.time() < end:
        s, d, total = counts()
        if d >= total:
            break
        time.sleep(2)
    check("all tests complete", d == total, (d, total))
    time.sleep(2)
    bad = []
    for i in range(1, 121):
        sub = get(f"/api/sub?sid=T{i:03d}&prob=slow")
        sts = [t[1] for t in sub["tests"]]
        if sts != ["AC"] * 6 or sub["score"] != 100 or sub["state"] != "done":
            bad.append((sub["sid"], sts, sub["score"], sub["state"]))
    check("every result correct after two failures", not bad, bad[:3])
    m1 = get("/api/sub?sid=T001&prob=mem")
    check("100 MB recursion passes at 256 MB", m1["score"] == 100, [t[1] for t in m1["tests"]])
    pts = [t[7] for t in get("/api/sub?sid=T002&prob=mem")["tests"]]
    check("points from full marks", sum(pts) == 100 and pts == [16, 16, 17, 17, 17, 17], pts)
    check("ETA reaches zero", st()["eta"] == 0, st()["eta"])

    # ---- changing limits clears only what depends on them
    cfg["problems"][1]["ml"] = 64
    r = post("/api/contest/apply", cfg)
    check("limit change clears that problem only", r.get("cleared") == ["mem"], r)
    post("/api/control", {"op": "start"})
    end = time.time() + 60
    while time.time() < end:
        s, d, total = counts()
        if d >= total:
            break
        time.sleep(1)
    m1 = get("/api/sub?sid=T001&prob=mem")
    check("100 MB recursion fails at 64 MB", m1["score"] == 0 and m1["tests"][0][1] in ("MLE", "RE"), [t[1] for t in m1["tests"]])
    check("simple program unaffected at 64 MB", get("/api/sub?sid=T002&prob=mem")["score"] == 100)
    check("other problem kept its results", get("/api/sub?sid=T010&prob=slow")["score"] == 100)

    cfg2 = dict(cfg, name="测试赛 改名")
    cfg2["problems"] = [dict(cfg["problems"][0], full=60), cfg["problems"][1]]
    r = post("/api/contest/apply", cfg2)
    check("rename and full marks need no rejudge", r.get("cleared") == [] and st()["contest"]["name"] == "测试赛 改名", r)
    check("full marks applied", get("/api/sub?sid=T010&prob=slow")["score"] == 60, get("/api/sub?sid=T010&prob=slow")["score"])

    # ---- export carries the configured name
    with urllib.request.urlopen(BASE + "/api/export", timeout=60) as resp:
        html = resp.read().decode("utf8")
    check("export has name and no credentials", '"name":"测试赛 改名"' in html and KEY not in html)

    # ---- switching contests and back keeps results
    if REAL:
        rep = post("/api/contest/scan", {"data": REAL + "/data", "answers": REAL + "/answers"})
        check("real contest scanned", sorted(p["id"] for p in rep["problems"]) == ["crystal", "hub", "migrate", "subway"] and rep["students"] == 1901, [(p["id"], p["tests"], p["subs"]) for p in rep["problems"]])
        limits = {"crystal": 1000, "subway": 1000, "migrate": 1000, "hub": 3000}
        t0 = time.time()
        post("/api/contest/apply", {"name": "CSP-S 2026", "data": REAL + "/data", "answers": REAL + "/answers", "scale": True,
                                    "problems": [{"id": k, "name": k, "tl": v, "ml": 1024, "full": 100} for k, v in limits.items()]})
        s = wait_ready()
        check("real contest active", s["contest"]["name"] == "CSP-S 2026", f"packed in {time.time() - t0:.0f}s")
        check("shutdown code quarantined by default", [h["sid"] for h in s["held"]] == ["SC-S00791"], s["held"])
        n = wait_online(lambda x: x["id"] == rid, 240)
        check("nodes redeploy for new contest", n and n["stage"] == "online", n and (n["stage"], n["error"]))
        post("/api/nodes/update", {"id": rid, "slots": 6})
        post("/api/control", {"op": "start"})
        time.sleep(15)
        s, d, _ = counts()
        check("real contest judging", d > 0, (d, s["status"]))
        post("/api/control", {"op": "stop"})
        time.sleep(3)
        post("/api/contest/apply", cfg2)
        s = wait_ready()
        check("switching back restores results", s["contest"]["name"] == "测试赛 改名" and get("/api/sub?sid=T010&prob=slow")["score"] == 60,
              get("/api/sub?sid=T010&prob=slow")["score"])

    print("\nFAILED: " + ", ".join(fails) if fails else "\nALL PASSED")
    return 1 if fails else 0


if __name__ == "__main__":
    os.makedirs(FX, exist_ok=True)
    sys.exit(main())
