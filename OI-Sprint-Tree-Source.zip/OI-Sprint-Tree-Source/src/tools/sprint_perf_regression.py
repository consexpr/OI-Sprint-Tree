"""One controlled throughput comparison using many short points, including master scheduling."""
import json
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / "build/oi-sprint" / ("perf-" + uuid.uuid4().hex[:8])
RUN.mkdir(parents=True)
DATA, ANSWERS = RUN / "data", RUN / "answers"
DATA.mkdir()
POINTS, STUDENTS, SLOTS = 32, 8, 8
for test in range(1, POINTS + 1):
    (DATA / f"p{test}.in").write_text("1\n")
    (DATA / f"p{test}.ans").write_text("2\n")
for student in range(STUDENTS):
    path = ANSWERS / f"s{student}"
    path.mkdir(parents=True)
    code = '#include<bits/stdc++.h>\nint main(){freopen("p.out","w",stdout);std::cout<<2<<"\\n";}\n'
    (path / "p.cpp").write_text(code + f"// student {student}\n" + "// normal source padding\n" * 400)


def exercise(label, master_source, agent):
    app = RUN / label
    payload = app / "payload"
    payload.mkdir(parents=True)
    shutil.copy2(agent, payload / "oi-sprint-agent.exe")
    shutil.copy2(ROOT / "build/oi-sprint/dist/OI-Sprint/payload/runtime.tar.gz", payload / "runtime.tar.gz")
    (payload / "version.txt").write_text("short-points-" + label)
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    def api(path, body=None):
        req = urllib.request.Request(base + path, None if body is None else json.dumps(body).encode(),
                                     {"X-Judge": "1", "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as response:
            return json.load(response)
    def wait(predicate, timeout=60):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            try:
                current = api("/api/state?since=999999999")
                if predicate(current):
                    return current
            except (ConnectionError, urllib.error.URLError):
                pass
            time.sleep(0.04)
        raise TimeoutError(label)
    with open(RUN / (label + ".log"), "w") as log:
        proc = subprocess.Popen([sys.executable, str(master_source / "main.py"), "--app-dir", str(app),
                                 "--port", str(port), "--no-browser"], stdout=log, stderr=log,
                                creationflags=0x08000000)
        try:
            wait(lambda s: bool(s["nodes"]))
            report = api("/api/contest/scan", {"data": str(DATA), "answers": str(ANSWERS)})
            api("/api/contest/apply", {"name": "short points", "data": str(DATA), "answers": str(ANSWERS),
                                      "scale": False, "problems": [{**p, "tl": 2000, "ml": 256, "full": 100}
                                                                    for p in report["problems"]]})
            wait(lambda s: s["contest"] is not None and not s["preparing"])
            node = api("/api/state")["nodes"][0]
            api("/api/nodes/update", {"id": node["id"], "slots": SLOTS, "enabled": True})
            wait(lambda s: s["nodes"][0]["stage"] == "online")
            result = {}
            for phase in ("cold", "warm"):
                if phase == "warm":
                    api("/api/control", {"op": "pause"})
                    api("/api/act", {"op": "rejudge"})
                started = time.perf_counter()
                api("/api/control", {"op": "start"})
                state = wait(lambda s: s["problems"][0]["done"] == POINTS * STUDENTS)
                elapsed = time.perf_counter() - started
                assert state["status"] == {"AC": POINTS * STUDENTS}, state["status"]
                result[phase] = {"seconds": round(elapsed, 3), "points_per_second": round(POINTS * STUDENTS / elapsed, 1)}
                wait(lambda s: s["nodes"][0]["inflight"] == 0)
                print(label, phase, result[phase], flush=True)
            return result
        finally:
            proc.terminate()
            proc.wait(timeout=8)


before = exercise("before", ROOT / "build/oi-sprint/perf-before/master", ROOT / "build/oi-sprint/perf-before/oi-sprint-agent.exe")
after = exercise("after", ROOT / "src/master", ROOT / "build/oi-sprint/dist/OI-Sprint/payload/oi-sprint-agent.exe")
summary = {"points": POINTS * STUDENTS, "slots": SLOTS, "before": before, "after": after}
(RUN / "results.json").write_text(json.dumps(summary, indent=2))
print("Results:", RUN / "results.json", flush=True)
