"""Build isolated Linux-edition artifacts; never overwrite a Classic portable package."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build'/'oi-sprint-linux'
DIST=BUILD/'OI-Sprint-Linux'
PAYLOAD=DIST/'payload'


def sources():
    PAYLOAD.mkdir(parents=True,exist_ok=True)
    with tarfile.open(PAYLOAD/'linux-agent.tar.gz','w:gz',compresslevel=1) as archive:
        for path in sorted((ROOT/'src'/'linux_agent').glob('*.py')):
            archive.add(path,arcname=path.name)


def host():
    subprocess.check_call([sys.executable,'-m','PyInstaller','--noconfirm','--onefile','--noconsole',
                           '--name','oi-sprint-linux-host','--distpath',str(PAYLOAD),
                           '--workpath',str(BUILD/'host-pyi'),'--specpath',str(BUILD/'host-pyi'),
                           str(ROOT/'src'/'tools'/'linux_host.py')])


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--host',action='store_true')
    parser.add_argument('--freeze',action='store_true');parser.add_argument('--image');parser.add_argument('--manifest')
    args=parser.parse_args();sources()
    if args.image or args.manifest:
        if not args.image or not args.manifest:parser.error('--image 和 --manifest 必须同时提供')
        manifest=json.loads(Path(args.manifest).read_text(encoding='utf8'))
        if not all(manifest.get(k) for k in ('version','compiler','compiler_version','isolate_version')):
            raise SystemExit('Linux 镜像清单缺少固定的工具链与沙箱版本')
        shutil.copyfile(args.image,PAYLOAD/'linux-rootfs.tar.gz')
        shutil.copyfile(args.manifest,PAYLOAD/'linux-image.json')
    if args.host:host()
    if args.freeze:
        missing=[name for name in ('linux-rootfs.tar.gz','linux-image.json','oi-sprint-linux-host.exe') if not (PAYLOAD/name).is_file()]
        if missing:raise SystemExit('拒绝发布不完整的 Linux 便携包，缺少：'+', '.join(missing))
        work=BUILD/'master-pyi'
        subprocess.check_call([sys.executable,'-m','PyInstaller','--noconfirm','--onedir','--console','--name','OI-Sprint-Linux',
                               '--distpath',str(BUILD/'frozen'),'--workpath',str(work),'--specpath',str(work),
                               '--paths',str(ROOT/'src'),'--paths',str(ROOT/'src'/'master'),
                               '--add-data',str(ROOT/'src'/'master'/'web')+os.pathsep+'web',
                               '--hidden-import','provisioning','--hidden-import','linux_connection','--hidden-import','linux_deploy',
                               str(ROOT/'src'/'master'/'linux_main.py')])
        shutil.copytree(BUILD/'frozen'/'OI-Sprint-Linux',DIST,dirs_exist_ok=True)
    digest=hashlib.sha256()
    for name in ('linux-agent.tar.gz','oi-sprint-linux-host.exe','linux-image.json'):
        path=PAYLOAD/name
        if path.is_file():
            with path.open('rb') as source:
                while chunk:=source.read(1<<20):digest.update(chunk)
    (PAYLOAD/'version.txt').write_text(digest.hexdigest()[:16])
    print('Linux edition build directory:',DIST)
    if not (PAYLOAD/'linux-rootfs.tar.gz').is_file():print('NOT A RELEASE: Linux root filesystem and sandbox execution verification are still required.')


if __name__=='__main__':main()
