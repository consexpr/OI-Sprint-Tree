"""Small regression checks for the restored whole-submission scheduler. No worker processes."""
import os
import sys
import threading
from types import SimpleNamespace

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "master"))
import judge as J


def fixture(tests=3):
    j = J.Judge.__new__(J.Judge)
    j.lock = threading.RLock()
    j.cv = threading.Condition(j.lock)
    j.epoch, j.rev, j.task_seq = 1, 1, 0
    j.contest = {"scale": False}
    j.nodes = {}
    j.resetting = False
    j._reset([{"id": "p", "tl": 1000, "ml": 1024, "tests": tests, "points": [10] * tests, "on": True}])
    j.store = SimpleNamespace(put=lambda *args: None)
    s = J.Sub("s1", j.problems[0], "int main(){}")
    j.subs[(s.sid, s.prob)] = s
    j.students = [s.sid]
    for i in (1, 2):
        j.nodes[i] = J.Node(j, i, {"local": True, "slots": 2})
    with j.lock:
        j.enqueue(s)
    return j, s, j.nodes[1], j.nodes[2]


def take(j, node):
    with j.lock:
        task = j.start_task(node)
        if task:
            node.inflight[task.id] = task
        return task


def main():
    j, s, a, b = fixture()
    j.cpu_limit = 100
    task = take(j, a)
    assert task.tests == [1, 2, 3] and take(j, b) is None
    j.epoch += 1
    assert not j.on_test(task, 1, "AC", 1, 1, 1, "", "a")
    j.on_compile(task, "CE", 1, "old", "a")
    j.on_done(task, failed=True)
    assert not s.tests and s.compile is None and not s.attempts
    print("PASS whole-submission ownership and stale-contest isolation")

    j, s, a, b = fixture(2)
    for attempt in range(5):
        t = take(j, a)
        if attempt == 0:
            assert j.on_test(t, 2, "AC", 1, 1, 1, "", "a")
        j.on_test(t, 1, "SE", 0, 0, 0, "temporary data failure", "a")
        j.on_done(t, failed=True)
        assert (1 in s.tests) == (attempt == 4)
    assert s.tests[1][0] == "SE" and s.tests[2][0] == "AC" and s.state == "done"
    print("PASS bounded retry preserves completed tests")

    j, s, a, b = fixture()
    t = take(j, a)
    a.kill(t.id)
    j.on_done(t, failed=True)
    assert not s.attempts
    t = take(j, b)
    assert t.tests == [1, 2, 3]
    with j.lock:
        j._rejudge(s, set())
    assert not j.on_test(t, 1, "AC", 1, 1, 1, "", "b")
    print("PASS cancellation and rejudge")

    j, s, a, b = fixture()
    other = J.Sub("s0", s.problem, "int main(){return 0;}")
    j.subs[(other.sid, other.prob)] = other
    with j.lock:
        j.queues["p"].clear()
        j.enqueue(other)
        j.enqueue(s)
    assert take(j, a).sub is other and take(j, b).sub is s
    print("PASS original candidate order without affinity")

    j, s, a, b = fixture()
    task = take(j, a)
    j.on_test(task, 1, "AC", 1, 1, 1, "", "a")
    other = J.Sub("s2", s.problem, "int main(){}")
    other.tests[1] = ("WA", 1, 1, 1, "", "b")
    j.subs[(other.sid, other.prob)] = other
    j._recount()
    recount = j._recount
    def forbidden_recount():
        raise AssertionError("CE must not scan all submissions")
    j._recount = forbidden_recount
    j.on_compile(task, "CE", 1, "compile error", "a")
    j.on_compile(task, "CE", 1, "duplicate", "a")
    expected = (dict(j.done_tests), dict(j.total_tests), dict(j.status_counts))
    recount()
    assert expected == (dict(j.done_tests), dict(j.total_tests), dict(j.status_counts))
    assert j.status_counts == {"CE": 3, "WA": 1}
    print("PASS incremental CE counts match recount, with partial and duplicate results")

    j, s, a, b = fixture()
    j.cpu_limit = 100
    j.save_nodes = lambda: None
    a.set_slots(0)
    assert a.to_config()["slots"] == 0
    a.info = {"mem": 16384, "logical": 8}
    a.curve = [(1, 100), (2, 90), (4, 70)]
    assert a.recommended_slots() == 4
    a.slots = 8
    assert a.compile_limit() == 8
    import tempfile, json
    with tempfile.TemporaryDirectory() as directory:
        j.state_dir = directory
        a.stage = b.stage = "online"
        j.set_cpu_limit(50)
        assert j.cpu_limit == 50
        assert json.load(open(os.path.join(directory,"settings.json")))["cpu_limit"] == 50
        assert a.outbox.get_nowait() == b"CONFIG 8 50\n"
        assert b.outbox.get_nowait() == b"CONFIG 2 50\n"
        assert a.power() == 4
        for invalid in (0, 101, True, 1.5):
            try:
                j.set_cpu_limit(invalid)
                raise AssertionError("invalid cap accepted")
            except ValueError:
                pass
        a._handle("CONFIG_OK 50")
        assert a.cpu_limit_applied == 50
        a.set_cpu_limit(30)
        assert a.outbox.get_nowait() == b"CONFIG 8 30\n"
        assert a.effective_cpu_limit() == 30 and a.to_config()["cpu_limit"] == 30
        restored_node = J.Node(j, 3, a.to_config())
        assert restored_node.effective_cpu_limit() == 30
        j.set_cpu_limit(60)
        assert a.outbox.empty() and b.outbox.get_nowait() == b"CONFIG 2 60\n"
        assert a.effective_cpu_limit() == 30 and b.effective_cpu_limit() == 60
        a.set_cpu_limit(None)
        assert a.outbox.get_nowait() == b"CONFIG 8 60\n" and a.to_config()["cpu_limit"] is None
        assert J.Node(j, 4, a.to_config()).effective_cpu_limit() == 60
        for invalid in (0, 101, True, 1.5, ""):
            try:
                a.set_cpu_limit(invalid)
                raise AssertionError("invalid node cap accepted")
            except ValueError:
                pass
    print("PASS zero slots, original parallelism and persisted global CPU cap")
    print("PASS node overrides, global inheritance, serialization and validation")

    j, s, a, b = fixture()
    p2 = {**j.problems[0], "id": "q"}
    j.problems.append(p2);j.problem_by_id["q"] = p2
    j._save_contest = lambda: None
    assert j.reorder_problems(["q", "p"])["order"] == ["q", "p"]
    print("PASS problem ordering retained")

    j,s,a,b=fixture(8)
    a.stage=b.stage="online"
    a.slots=b.slots=4
    j.sum_wall["p"],j.count_wall["p"]=8000,8
    j.compile_sum,j.compile_count=10,1
    first,second=take(j,a),take(j,b)
    assert first.tests and second.tests and not set(first.tests)&set(second.tests)
    assert len(first.tests)<8
    j.on_test(first,first.tests[0],"AC",1,1,1,"","a")
    j.on_done(first)
    assert not s.attempts
    print("PASS adaptive tail batches have exclusive point ownership")

    j,s,a,b=fixture(8)
    task=take(j,a)
    a.stage=b.stage="online";a.slots=b.slots=4
    j.sum_wall["p"],j.count_wall["p"]=8000,8
    with j.lock:j.rebalance_tail()
    assert task.yielded and a.outbox.get_nowait()==f"YIELD {task.id}\n".encode()
    j.on_test(task,1,"AC",1,1,1,"","a")
    j.on_done(task)
    assert not s.attempts and 1 in s.tests
    print("PASS tail yield preserves current point and does not count as a fault")


if __name__ == "__main__":
    main()
