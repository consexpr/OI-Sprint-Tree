"""One isolated deployment while a submission stays active in an older, unmodified master."""
import json
from pathlib import Path
import socket
import subprocess
import sys
import time
import urllib.request
import uuid
import zipfile
from types import SimpleNamespace
from unittest.mock import patch
import tempfile

import deploy_assist

ROOT = Path(__file__).resolve().parents[2]


def port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def main():
    # Force the upload-to-online race: slots=0 must prevent removal of an active submission.
    with tempfile.TemporaryDirectory() as temp:
        directory = Path(temp)
        (directory / "state").mkdir()
        cfg = {"host": "192.0.2.1", "user": "test", "port": 22, "slots": 2, "dir": "", "password_sealed": ""}
        (directory / "state/nodes.json").write_text(json.dumps([cfg]))
        node = {**cfg, "id": 5, "local": False, "stage": "uploading", "enabled": True, "inflight": 0}
        live = {"contest": {"id": "0123456789abcdef"}, "nodes": [node]}
        def post_race(base, route, value):
            assert route != "/api/nodes/remove", "active node was removed"
            if value.get("slots") == 0:
                node.update(slots=0, stage="online", inflight=1)
            elif "slots" in value:
                node["slots"] = value["slots"]
        def connect_race(conn):
            conn.sftp_dir = "/C:/fixture/.oi_sprint_classic"
            return SimpleNamespace(close=lambda: None)
        with patch.object(deploy_assist, "state", return_value=live), patch.object(deploy_assist, "post", side_effect=post_race), patch.object(deploy_assist.J.SSHConn, "_connect", connect_race):
            journal = deploy_assist.takeover(temp, "unused", [5])
        assert node["inflight"] == 1 and node["slots"] == 2 and journal["nodes"][0]["phase"] == "restored"
        print("PASS upload-to-online race preserves the running submission and restores slots", flush=True)
    run = ROOT / "build/oi-sprint" / ("assist-check-" + uuid.uuid4().hex[:8])
    run.mkdir()
    with zipfile.ZipFile(ROOT / "OI-Sprint-Classic-Portable-Transfer.zip") as archive:
        archive.extractall(run)
    app = run / "OI-Sprint-Classic"
    data, answers, home = run / "data", run / "answers/s1", run / "ssh-home"
    for directory in (data, answers, home):
        directory.mkdir(parents=True)
    (data / "p1.in").write_text("1\n")
    (data / "p1.ans").write_text("1\n")
    (answers / "p.cpp").write_text("int main(){volatile unsigned x=0;for(;;)++x;}\n")
    http_port, ssh_port = port(), port()
    base = f"http://127.0.0.1:{http_port}"
    logs = [open(run / name, "wb") for name in ("master.log", "ssh.log")]
    master = subprocess.Popen([str(app / "OI-Sprint-Classic.exe"), "--no-browser", "--port", str(http_port)],
                              stdout=logs[0], stderr=logs[0], creationflags=subprocess.CREATE_NO_WINDOW)
    ssh = subprocess.Popen([sys.executable, str(ROOT / "src/tools/test_ssh_server.py"), str(home), str(ssh_port)],
                           stdout=logs[1], stderr=logs[1], creationflags=subprocess.CREATE_NO_WINDOW)
    pending_home = run / "pending-home"
    pending_home.mkdir()
    pending_port = port()
    pending_log = open(run / "pending-ssh.log", "wb")
    pending_ssh = subprocess.Popen([sys.executable, str(ROOT / "src/tools/test_ssh_server.py"), str(pending_home),
                                    str(pending_port), "127.0.0.2", "--slow-original"],
                                   stdout=pending_log, stderr=pending_log, creationflags=subprocess.CREATE_NO_WINDOW)

    def api(path, data=None):
        req = urllib.request.Request(base + path, data=json.dumps(data).encode() if data is not None else None,
                                     headers={"X-Judge": "1", "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as response:
            return json.load(response)

    def wait(predicate):
        until = time.monotonic() + 40
        while time.monotonic() < until:
            try:
                current = api("/api/state?since=999999999999")
                if predicate(current):
                    return current
            except OSError:
                pass
            time.sleep(.1)
        raise TimeoutError("isolated master did not reach expected state")

    try:
        wait(lambda s: not s["contest"])
        api("/api/contest/apply", {"data": str(data), "answers": str(answers.parent), "scale": False,
                                  "problems": [{"id": "p", "tl": 90000, "ml": 128, "full": 100}]})
        current = wait(lambda s: bool(s["contest"]) and not s["preparing"])
        local = current["nodes"][0]["id"]
        api("/api/nodes/update", {"id": local, "enabled": True, "slots": 1})
        wait(lambda s: s["nodes"][0]["stage"] == "online")
        api("/api/control", {"op": "start"})
        before = wait(lambda s: s["nodes"][0]["inflight"] == 1)
        target = {"host": "127.0.0.1", "port": ssh_port, "user": "test", "password": "testpw"}
        result = deploy_assist.prepare_new(str(app), base, [target], allow_local=True)
        assert result == {"ready": ["127.0.0.1"], "failed": []}, result
        after = api("/api/state?since=999999999999")
        assert after["epoch"] == before["epoch"] and after["running"]
        assert after["nodes"][0]["inflight"] == 1 and after["problems"][0]["done"] == 0
        print("PASS predeployment alongside older master: active submission and contest unchanged", flush=True)

        api("/api/nodes/add", {"text": f"test@127.0.0.1:{ssh_port} password:testpw slots:1"})
        connected = wait(lambda s: len(s["nodes"]) == 2 and all(n["stage"] == "online" for n in s["nodes"]))
        assert connected["running"] and connected["nodes"][0]["inflight"] == 1
        try:
            deploy_assist.prepare_new(str(app), base, [target], allow_local=True)
            raise AssertionError("existing node was not rejected")
        except ValueError as error:
            assert "拒绝接管" in str(error)
        print("PASS original master accepts warmed node; existing-node protection rejects takeover", flush=True)

        api("/api/nodes/add", {"text": f"nopw@127.0.0.2:{pending_port}"})
        pending = wait(lambda s: any(n["host"] == "127.0.0.2" and n["stage"] == "uploading" for n in s["nodes"]))
        original = next(n for n in pending["nodes"] if n["host"] == "127.0.0.2")
        api("/api/nodes/update", {"id": original["id"], "cpu_limit": 35})
        journal = deploy_assist.takeover(str(app), base, [original["id"]])
        assert journal["nodes"][0]["phase"] == "restored" and journal["nodes"][0]["prepared"]
        warmed = wait(lambda s: any(n["host"] == "127.0.0.2" and n["stage"] == "online" and n["cpu_limit_applied"] == 35 for n in s["nodes"]))
        replacement = next(n for n in warmed["nodes"] if n["host"] == "127.0.0.2")
        assert replacement["id"] != original["id"] and "/.upload_assist_" in replacement["dir"]
        assert replacement["slots"] == replacement["recommended"]
        assert warmed["epoch"] == before["epoch"] and warmed["running"]
        assert warmed["nodes"][0]["inflight"] == 1 and warmed["problems"][0]["done"] == 0
        print("PASS live takeover of existing passwordless upload: fresh directory, automatic slots and CPU override restored; other submission still running", flush=True)

        source = run / "worker-check.bin"
        source.write_bytes(b"x" * (2 * 1024 * 1024))
        target.update(source=str(source), destination="worker-check.bin")
        worker = subprocess.run([str(ROOT / "OI-Sprint-Deploy-Assist.exe"), "--upload-worker"],
                                input=json.dumps(target).encode() + b"\n", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=20, creationflags=subprocess.CREATE_NO_WINDOW)
        assert worker.returncode == 0, worker.stderr.decode("utf8", "replace")
        assert json.loads(worker.stdout.splitlines()[-1])["ok"]
        assert (home / "worker-check.bin").read_bytes() == source.read_bytes()
        print("PASS standalone frozen helper upload worker, contents preserved", flush=True)
        print("Artifacts:", run, flush=True)
    finally:
        for process in (master, ssh, pending_ssh):
            if process.poll() is None:
                process.terminate()
            process.wait(8)
        for log in logs:
            log.close()
        pending_log.close()


if __name__ == "__main__":
    main()
