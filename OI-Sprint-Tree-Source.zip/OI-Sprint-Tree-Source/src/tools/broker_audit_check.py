"""One local branch, four points. No SSH targets or real contest data."""
import base64
from pathlib import Path
import shutil
import sys
import tempfile
import threading
import time

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'master'))
import assigned_data
import judge as J
from broker import Broker


def main():
    J.PROTOCOL='OI-SPRINT-TREE/1';J.AGENT_NAME='oi-sprint-tree-agent.exe'
    J.LOCAL_SUBDIR='worker-tree'
    payload=Path(__file__).resolve().parents[2]/'build/oi-sprint-tree/OI-Sprint-Tree/payload'
    with tempfile.TemporaryDirectory(prefix='sprint-broker-') as raw:
        root=Path(raw);version='0123456789abcdef';name='data_'+version
        bundle=root/('payload_'+version);bundle.mkdir()
        for filename in (J.AGENT_NAME,'runtime.tar.gz'):
            shutil.copyfile(payload/filename,bundle/filename)
        source=root/'source';source.mkdir()
        for test in (1,2):
            for extension in ('.in','.ans'):
                (source/('p'+str(test)+extension)).write_bytes((str(test)+'\n').encode())
        packet=root/'packet.tar.gz'
        assigned_data.write_packet(packet,[(path,name+'/'+path.name) for path in source.iterdir()])
        lines=[];condition=threading.Condition()
        def emit(line):
            with condition:lines.append(line);condition.notify_all()
        branch=Broker(root,dict(version=version,data_name=name,scale=False),emit)
        try:
            branch.install(packet)
            branch.configure_workers([dict(id=1,host='127.0.0.1',relay_local=True,enabled=True,slots=2)])
            deadline=time.monotonic()+40
            while branch.nodes[1].stage!='online':
                if branch.nodes[1].stage=='error':raise RuntimeError(branch.nodes[1].error)
                if time.monotonic()>deadline:raise TimeoutError(branch.nodes[1].stage)
                time.sleep(.05)
            code='#include<cstdio>\nint main(){freopen("p.in","r",stdin);freopen("p.out","w",stdout);int n=0;scanf("%d",&n);printf("%d\\n",n);}'
            encoded=base64.b64encode(code.encode()).decode()
            for tid in (10,11):
                branch.control(f'TASK {tid} p 1000 128 0 1,2 {encoded}')
                deadline=time.monotonic()+20
                with condition:
                    while f'DONE {tid}' not in lines:
                        if time.monotonic()>deadline:raise TimeoutError(lines)
                        condition.wait(.1)
                points=[line.split() for line in lines if line.startswith(f'TEST {tid} ')]
                assert sorted(int(row[2]) for row in points)==[1,2],lines
                assert all(row[3]=='AC' and base64.b64decode(row[8])==b'127.0.0.1' for row in points),lines
            assert branch.nodes[1].cache_hits>=1
            assert not branch.jobs and not branch.subs and not branch.nodes[1].inflight
            print('PASS local relay: assigned data -> private queue -> agent -> 4 AC results; cache reuse; leases released')
        finally:
            branch.close()
            for node in branch.nodes.values():
                if node.thread:node.thread.join(5)


if __name__=='__main__':main()
