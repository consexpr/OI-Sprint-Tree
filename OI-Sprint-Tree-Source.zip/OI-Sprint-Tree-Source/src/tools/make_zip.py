"""Packs build/dist/OI-Sprint-Classic into the portable ZIP. The worker bundle is already gzip, so it is stored."""
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DIST = os.path.join(ROOT, "build", "oi-sprint", "dist")
OUT = os.path.join(ROOT, "OI-Sprint-Classic-Portable.zip")
STORED = {".gz", ".zip", ".exe", ".pyd", ".dll"}


def main():
    n = 0
    with zipfile.ZipFile(OUT + ".tmp", "w", zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as z:
        for dirpath, _, files in os.walk(os.path.join(DIST, "OI-Sprint-Classic")):
            relative = os.path.relpath(dirpath, os.path.join(DIST, "OI-Sprint-Classic"))
            if relative.split(os.sep)[0] in {"state", "exports", "cache", "run"}:
                continue
            for f in files:
                full = os.path.join(dirpath, f)
                rel = os.path.relpath(full, DIST)
                method = zipfile.ZIP_STORED if os.path.splitext(f)[1].lower() in STORED else zipfile.ZIP_DEFLATED
                z.write(full, rel, compress_type=method)
                n += 1
    os.replace(OUT + ".tmp", OUT)
    print("files", n, "MB", os.path.getsize(OUT) >> 20, OUT)


if __name__ == "__main__":
    sys.exit(main())
