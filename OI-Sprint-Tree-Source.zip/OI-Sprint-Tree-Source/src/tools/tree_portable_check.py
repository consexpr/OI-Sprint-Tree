"""One-point smoke check of the actual ZIP in a fresh directory."""
import json
import os
from pathlib import Path
import socket
import subprocess
import time
import urllib.request
import uuid
import zipfile
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]


def main():
    run=ROOT/'build/oi-sprint-tree'/('portable-check-'+uuid.uuid4().hex[:8]);run.mkdir()
    single='--onefile' in sys.argv
    if single:
        shutil.copyfile(ROOT/'OI-Sprint-Tree.exe',run/'OI-Sprint-Tree.exe')
        app=run;names=['OI-Sprint-Tree.exe']
    else:
        with zipfile.ZipFile(ROOT/'OI-Sprint-Tree-Portable.zip') as archive:
            names=archive.namelist()
            assert all(not any(part in ('state','exports','__pycache__','cache') for part in Path(n).parts) for n in names)
            assert all(n.startswith('OI-Sprint-Tree/') for n in names)
            archive.extractall(run)
        app=run/'OI-Sprint-Tree'
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    base=f'http://127.0.0.1:{port}'
    env=dict(os.environ);env['PATH']=os.path.join(os.environ['SystemRoot'],'System32')
    log=(run/'check.log').open('ab')
    process=None

    def api(path,body=None):
        req=urllib.request.Request(base+path,None if body is None else json.dumps(body).encode(),
                                   {'X-Judge':'1','Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=8) as response:return json.load(response)

    def wait(test,timeout=40):
        end=time.monotonic()+timeout;last=None
        while time.monotonic()<end:
            try:
                last=api('/api/state?since=0')
                if test(last):return last
                if last.get('preparing') and last['preparing'].get('stage')=='error':raise RuntimeError(last['preparing'])
            except (OSError,ConnectionError):pass
            time.sleep(.1)
        raise TimeoutError(last)

    def start():
        return subprocess.Popen([str(app/'OI-Sprint-Tree.exe'),'--no-browser','--port',str(port)],
                                cwd=app,env=env,stdout=log,stderr=log,creationflags=0x08000000)

    def stop():
        if process and process.poll() is None:
            subprocess.run(['taskkill.exe','/PID',str(process.pid),'/T','/F'],
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=0x08000000)
            process.wait(timeout=8)

    try:
        process=start();wait(lambda s:s['contest'] is None)
        if single:
            assert (run/'Tree/state').is_dir() and not (run/'state').exists()
            worker=subprocess.run([str(app/'OI-Sprint-Tree.exe'),'--upload-worker'],
                input=json.dumps(dict(host='127.0.0.1',port=1,user='test',source=str(app/'OI-Sprint-Tree.exe'),destination='/test')).encode()+b'\n',
                stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=15,creationflags=0x08000000)
            assert worker.returncode==1 and 'error' in json.loads(worker.stdout.decode().splitlines()[-1]),worker.stdout
            print('PASS single GUI executable: Tree data directory and headless upload-worker pipes',flush=True)
        data=run/'data';data.mkdir();(data/'p1.in').write_text('3\n');(data/'p1.ans').write_text('3\n')
        if single:
            many=run/'bulk-answers'
            for i in range(2048):
                folder=many/f's{i:05}';folder.mkdir(parents=True)
                (folder/'p.cpp').write_text(f'// {i}\nint main(){{return 0;}}')
            api('/api/contest/apply',dict(name='frozen process preparation check',data=str(data),answers=str(many),scale=False,
                                        problems=[dict(id='p',name='p',tl=1000,ml=128,full=100)]))
            wait(lambda s:s['contest'] and not s['preparing'] and s['students']==2048)
            stop();process=start()
            wait(lambda s:s['students']==2048)
            print('PASS frozen multiprocessing: 2048-source preparation and restart loading',flush=True)
        answers=run/'answers/s1';answers.mkdir(parents=True)
        (answers/'p.cpp').write_text('#include<cstdio>\nint main(){freopen("p.in","r",stdin);freopen("p.out","w",stdout);int n;scanf("%d",&n);printf("%d\\n",n);}')
        api('/api/contest/apply',dict(name='portable-check',data=str(data),answers=str(answers.parent),scale=False,
                                    problems=[dict(id='p',name='p',tl=1000,ml=128,full=100)]))
        state=wait(lambda s:s['contest'] and not s['preparing'])
        local=next(n for n in state['nodes'] if n['local'])
        api('/api/nodes/update',dict(id=local['id'],enabled=True,slots=1))
        wait(lambda s:any(n['local'] and n['stage']=='online' for n in s['nodes']))
        api('/api/control',dict(op='start'))
        state=wait(lambda s:s['status']=={'AC':1})
        assert state['rows'][0][1]==100
        api('/api/control',dict(op='pause'))
        stop();process=start()
        restored=wait(lambda s:s['status']=={'AC':1})
        assert restored['rows'][0][1]==100
        result=dict(artifact=str(ROOT/('OI-Sprint-Tree.exe' if single else 'OI-Sprint-Tree-Portable.zip')),files=len(names),fresh_extraction=True,
                    system_path_only=True,local_result='1 AC / 100 points',restart_restored=True)
        (run/'result.json').write_text(json.dumps(result,indent=2))
        print('PASS fresh standalone build: starts, local 1 AC / 100 points, results survive restart',flush=True)
        print(run/'result.json',flush=True)
    finally:
        stop();log.close()


if __name__=='__main__':main()
