"""Small synthetic check: preparation progress, responsive polling and preserved source content."""
import os
import sys
import tempfile
import threading
import zipfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "master"))
import contest as C
import judge as J


def main():
    with tempfile.TemporaryDirectory(prefix="oi-prepare-") as root:
        data, answers = os.path.join(root, "data"), os.path.join(root, "answers")
        os.makedirs(data)
        os.makedirs(os.path.join(answers, "s1"))
        source = b'// system("shutdown /s");\nint main(){return 0;}\n'
        for name, content in (("p1.in", "1\n"), ("p1.ans", "1\n")):
            with open(os.path.join(data, name), "w") as f:
                f.write(content)
        path = os.path.join(answers, "s1", "p.cpp")
        with open(path, "wb") as f:
            f.write(source)
        counts = []
        archive = os.path.join(root, "check.zip")
        C.pack_answers({"p": {"s1": path}}, ["p"], archive, lambda d, t: counts.append((d, t)))
        assert counts == [(0, 1), (1, 1)]
        with zipfile.ZipFile(archive) as z:
            assert z.read("s1/p/p.cpp") == source

        j = J.Judge(os.path.join(root, "app"))
        entered, release = threading.Event(), threading.Event()
        original = J.Sub

        def waiting_sub(*args):
            entered.set()
            assert release.wait(5), "poll blocked while loading sources"
            return original(*args)

        J.Sub = waiting_sub
        try:
            assert j.configure({"data": data, "answers": answers})["switching"]
            assert entered.wait(5)
            assert j.lock.acquire(timeout=1), "source loading holds the master lock"
            try:
                state = j.state_json(0)
                assert state["preparing"]["stage"] == "load"
                assert state["preparing"]["total"] == 1
            finally:
                j.lock.release()
        finally:
            release.set()
            j.prepare_thread.join(5)
            J.Sub = original
        assert not j.prepare_thread.is_alive() and j.preparing is None
        assert len(j.subs) == 1 and not j.subs[("s1", "p")].reasons
        assert j.subs[("s1", "p")].problem is j.problem_by_id["p"]
        assert j.subs[("s1", "p")].problem["points"] == [100]
        j.store.close()
        print("PASS source progress, unchanged archive, responsive polling, activation and comments")


if __name__ == "__main__":
    main()
