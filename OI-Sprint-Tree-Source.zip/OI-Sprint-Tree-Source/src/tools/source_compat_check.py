"""One harmless compiler invocation for the LP64 rewriting regressions."""
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src/master'))
import scan
import judge as J


def main():
    source='''#include<cstdio>
int main(){
long /* system("shutdown") is only a comment */ long a=4;
unsigned /* keep this comment */ long u=5000000000UL;
long b=1;
printf("%ld %lu %lld %s",b,u,a,"%ld");
}'''
    rewritten,changed=scan.rewrite_long(source)
    assert changed and not scan.scan(source),scan.scan(source)
    assert rewritten.count('\n')==source.count('\n')
    assert 'long /* system("shutdown") is only a comment */ long' in rewritten
    assert '"%lld %llu %lld %s"' in rewritten and ',"%ld"' in rewritten
    assert not scan.lp64_risks(source)
    dynamic='long a;const char*f="%ld";int main(){scanf(f,&a);}'
    assert scan.lp64_risks(dynamic)
    assert J.Sub('s',{'id':'p'},dynamic).reasons
    with tempfile.TemporaryDirectory(prefix='sprint-source-') as raw:
        root=Path(raw);cpp=root/'source.cpp';exe=root/'test.exe'
        cpp.write_text(rewritten)
        command=[r'D:\mingw64\bin\g++.exe','-std=c++14','-O2','-static','-include',str(ROOT/'src/agent/compat/lp64.h'),str(cpp),'-o',str(exe)]
        build=subprocess.run(command,capture_output=True,creationflags=0x08000000)
        assert build.returncode==0,build.stderr.decode('utf8','replace')
        result=subprocess.run([str(exe)],capture_output=True,creationflags=0x08000000)
        assert result.returncode==0 and result.stdout==b'1 5000000000 4 %ld',result
    print('PASS commented type specifiers; line preservation; 64-bit formats; literal output unchanged; unsafe dynamic formats held')


if __name__=='__main__':main()
