"""One small real SSH run: promote a busy worker automatically, then attach its peer."""
import json
from pathlib import Path
import socket
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src/master'))
import tree_main
import judge as J
from topology import Controller


def main():
    run = ROOT / 'build/oi-sprint-tree' / ('auto-ssh-' + uuid.uuid4().hex[:8])
    run.mkdir()
    processes, logs = [], []
    j = None

    def wait(predicate, timeout=65):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if predicate(): return
            time.sleep(.1)
        raise TimeoutError([(n.id, n.stage, n.error) for n in j.nodes.values()])

    try:
        j = J.Judge(str(run / 'app'))
        j.payload = str(ROOT / 'build/oi-sprint-tree/OI-Sprint-Tree/payload')
        c = j.topology = Controller(j)
        c.MIN_RELAY_MACHINES = 2  # exercise the eight-machine policy using only two actual workers
        data = run / 'data'; data.mkdir()
        answers = run / 'answers'
        for t in range(1, 4):
            (data / f'p{t}.in').write_text(str(t))
            (data / f'p{t}.ans').write_text(str(t))
        code = '#include<cstdio>\nint main(){freopen("p.in","r",stdin);freopen("p.out","w",stdout);int n;scanf("%d",&n);volatile unsigned v=0;for(unsigned i=0;i<250000000u;++i)v+=i;printf("%d\\n",n);}'
        for sid in ('s1', 's2', 's3', 's4'):
            folder = answers / sid; folder.mkdir(parents=True)
            (folder / 'p.cpp').write_text(code)
        j.configure(dict(name='auto-tree-check', data=str(data), answers=str(answers), scale=False,
                         problems=[dict(id='p', name='p', tl=10000, ml=128, full=100)]))
        wait(lambda: j.contest and not j.preparing)
        nodes = []
        for host in ('127.0.0.2', '127.0.0.3'):
            with socket.socket() as sock:
                sock.bind((host, 0)); port = sock.getsockname()[1]
            home = run / host; home.mkdir()
            log = (run / (host + '.log')).open('ab'); logs.append(log)
            processes.append(subprocess.Popen([sys.executable, str(ROOT / 'src/tools/test_ssh_server.py'),
                              str(home), str(port), host], stdout=log, stderr=log, creationflags=0x08000000))
            time.sleep(.3)
            nodes.append(j.add_node(dict(host=host, port=port, user='test', password='testpw',
                                        slots=1, auto_route=True)))
        wait(lambda: all(n.stage == 'online' for n in nodes))
        c.tick(0)
        j.start()
        wait(lambda: all(n.inflight for n in nodes))
        c.tick(11)
        assert any(a[0] == 'promote' for a in c.pending.values())
        candidate = j.nodes[next(nid for nid, a in c.pending.items() if a[0] == 'promote')]
        assert candidate.routing_draining
        wait(lambda: not candidate.inflight)
        c.tick(12)
        rid = candidate.relay_id
        gateway = c.gateway(rid)
        wait(lambda: gateway.stage == 'online' and candidate.stage == 'online')
        c.tick(13); c.tick(24)
        peer = next(n for n in nodes if n is not candidate)
        wait(lambda: not peer.inflight)
        c.tick(25)
        wait(lambda: peer.relay_id == rid and peer.stage == 'online')
        wait(lambda: j.done_tests['p'] == 12)
        assert j.status_counts == {'AC': 12}, j.status_counts
        assert all(not sub.attempts for sub in j.subs.values())
        assert candidate.id in j.nodes and peer.id in j.nodes
        result = dict(check='automatic promotion during judging + automatic peer placement',
                      points=12, results=dict(j.status_counts), score=sum(s.score() for s in j.subs.values()),
                      node_ids=[n.id for n in nodes], relay=rid,
                      environment='two independent loopback SSH services on one physical Windows host')
        (run / 'result.json').write_text(json.dumps(result, indent=2))
        print('PASS automatic vice elected while judging; peer placed automatically; 12 AC / 400 points', flush=True)
        print(run / 'result.json', flush=True)
    finally:
        if j:
            for n in list(j.nodes.values()): n.shutdown()
            j.relays.close()
            if j.store: j.store.flush()
        for p in processes:
            if p.poll() is None:
                subprocess.run(['taskkill.exe', '/PID', str(p.pid), '/T', '/F'],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=0x08000000)
                p.wait(timeout=8)
        for log in logs: log.close()


if __name__ == '__main__': main()
