"""Run just contest preparation against supplied read-only inputs, in an isolated app directory."""
import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid


def main():
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    app = os.path.join(root, "build", "oi-sprint", "prepare-" + uuid.uuid4().hex[:8])
    os.makedirs(app)
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    url = f"http://127.0.0.1:{port}"
    log = open(os.path.join(app, "console.log"), "wb")
    exe = os.path.join(root, "build", "oi-sprint", "dist", "OI-Sprint-Classic", "OI-Sprint-Classic.exe")
    proc = subprocess.Popen([exe, "--no-browser", "--app-dir", app, "--port", str(port)],
                            stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)

    def request(path, data=None, timeout=15):
        req = urllib.request.Request(url + path, data=json.dumps(data).encode() if data is not None else None,
                                     headers={"Content-Type": "application/json", "X-Judge": "1"})
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return json.load(response)

    t0 = time.monotonic()
    try:
        for _ in range(100):
            try:
                request("/api/state")
                break
            except (OSError, urllib.error.URLError):
                time.sleep(.1)
        print("isolated app", app, "url", url, flush=True)
        result = request("/api/contest/apply", {"data": sys.argv[1], "answers": sys.argv[2]}, timeout=120)
        print("apply", result, "elapsed", round(time.monotonic() - t0, 2), flush=True)
        stage, last, since = None, 0, 0
        while time.monotonic() - t0 < 240:
            before = time.monotonic()
            progress_state = request("/api/preparation", timeout=5)
            poll_time = time.monotonic() - before
            prep = progress_state["preparing"]
            current = prep.get("stage") if prep else None
            if current != stage or time.monotonic() - last > 5:
                print("elapsed", round(time.monotonic() - t0, 2), "poll", round(poll_time, 2), prep, flush=True)
                stage, last = current, time.monotonic()
            if not prep:
                state = request("/api/state?since=" + str(since), timeout=30)
                print("READY", state["students"], "students", sum(p["subs"] for p in state["problems"]),
                      "submissions", "seconds", round(time.monotonic() - t0, 2), flush=True)
                if "--hold" in sys.argv:
                    time.sleep(15)  # Leave enough time to inspect the completed UI.
                return
            if current == "error":
                raise RuntimeError(prep["error"])
            time.sleep(.5)
        raise RuntimeError("Preparation exceeded bounded diagnostic time")
    finally:
        proc.terminate()
        proc.wait(10)
        log.close()


if __name__ == "__main__":
    main()
