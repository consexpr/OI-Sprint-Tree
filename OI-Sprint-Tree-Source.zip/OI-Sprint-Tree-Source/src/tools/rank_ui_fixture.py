"""Serve a small deterministic export using the HTML embedded in the delivered EXE."""
from collections import Counter
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import time

from PyInstaller.archive.readers import CArchiveReader

ROOT=Path(__file__).resolve().parents[2]
FOLDER=ROOT/'build/oi-sprint-tree/rank-ui-check'


def main():
    FOLDER.mkdir(exist_ok=True)
    archive=CArchiveReader(str(ROOT/'OI-Sprint-Tree.exe'))
    member=next(name for name in archive.toc if name.replace('\\','/')=='web/index.html')
    template=archive.extract(member).decode('utf8')
    rows=[];subs={};statuses=Counter()
    samples=[('b001',[1,1,1]),('b002',[1,1,0]),('a001',[1,0,1]),('a002',[1,0,1]),('a003',[0,0,1])]
    samples.extend((f'z{i:03}',[0,0,0]) for i in range(250))
    for sid,passed in samples:
        points=[40,40,20]
        tests=[[i+1,'AC' if ok else 'WA',1,1,1024,'','0.0.0.0',points[i] if ok else 0] for i,ok in enumerate(passed)]
        score=sum(t[7] for t in tests)
        rows.append([sid,score,[score],[''.join('A' if ok else 'W' for ok in passed)]])
        statuses.update(t[1] for t in tests)
        subs[sid+'/p']=dict(sid=sid,prob='p',state='done',score=score,code='int main(){return 0;}',
                            tests=tests,compile=['OK',1,''],reasons=[],rewritten=False,running_tests=[])
    data=dict(export=True,generated=time.time(),name='分页与搜索排名校验',
              contest=dict(id='0123456789abcdef',scale=False),
              problems=[dict(id='p',name='p',tl=1000,ml=128,tests=3,full=100)],rows=rows,status=dict(statuses),subs=subs)
    blob=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('</','<\\/').replace('<!--','\\u003c!--')
    (FOLDER/'report.html').write_text(template.replace('/*__EXPORT_DATA__*/null',blob),encoding='utf8')
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(FOLDER)))
    (FOLDER/'server.json').write_text(json.dumps(dict(port=server.server_port)),encoding='utf8')
    print(f'http://127.0.0.1:{server.server_port}/report.html',flush=True)
    server.serve_forever()


if __name__=='__main__':main()
