"""Build the independent repair utility without changing the portable judge."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
payload = root / "build/oi-sprint/repair-payload"
payload.mkdir(parents=True, exist_ok=True)
assert (payload / "runtime.tar.gz").is_file(), "Reuse the existing portable runtime bundle here first"
subprocess.check_call([r"D:\mingw64\bin\g++.exe", "-std=c++17", "-O2", "-static", "-municode", "-DOI_SPRINT_REPAIR",
                       str(root / "src/agent/agent.cpp"), "-o", str(payload / "oi-sprint-repair-agent.exe"), "-ladvapi32", "-lpsapi"])
work = root / "build/oi-sprint/repair-pyi"
subprocess.check_call([sys.executable, "-m", "PyInstaller", "--noconfirm", "--onefile", "--console", "--name", "OI-Sprint-Repair-Full",
                       "--distpath", str(root), "--workpath", str(work), "--specpath", str(work),
                       "--paths", str(root / "src/master"), "--hidden-import", "ijson.backends.yajl2_c",
                       "--add-data", str(payload / "runtime.tar.gz") + ";.",
                       "--add-binary", str(payload / "oi-sprint-repair-agent.exe") + ";.",
                       str(root / "src/tools/repair_report.py")])
