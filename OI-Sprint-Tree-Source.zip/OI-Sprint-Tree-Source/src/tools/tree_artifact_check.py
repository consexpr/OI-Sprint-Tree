"""Small disposable check of executable names, shared artifacts and input protection."""
import base64
import json
from pathlib import Path
import queue
import shutil
import subprocess
import tarfile
import threading
import time
import uuid

ROOT = Path(__file__).resolve().parents[2]
PAYLOAD = ROOT / 'build/oi-sprint-tree/OI-Sprint-Tree/payload'


def main():
    work = ROOT / 'build/oi-sprint-tree' / ('artifact-check-' + uuid.uuid4().hex[:8])
    work.mkdir()
    with tarfile.open(PAYLOAD / 'runtime.tar.gz') as archive:
        archive.extractall(work, filter='data')
    shutil.copyfile(PAYLOAD / 'oi-sprint-tree-agent.exe', work / 'agent.exe')
    data = work / 'data'
    data.mkdir(exist_ok=True)
    (data / 'sample1.in').write_bytes(b'2\n')
    (data / 'sample1.ans').write_bytes(b'2\n')
    proc = subprocess.Popen([str(work / 'agent.exe'), 'serve', str(work)],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            creationflags=0x08000000)
    messages = queue.Queue()
    def read():
        for line in proc.stdout:
            messages.put(line.decode('utf8', 'replace').strip())
        messages.put('EOF')
    threading.Thread(target=read, daemon=True).start()
    def send(line):
        proc.stdin.write((line + '\n').encode())
        proc.stdin.flush()
    def collect(marker, timeout=50):
        result = []
        until = time.monotonic() + timeout
        while time.monotonic() < until:
            line = messages.get(timeout=max(.1, until-time.monotonic()))
            result.append(line)
            if line.startswith(marker):
                return result
            if line.startswith(('FATAL', 'EOF')):
                raise RuntimeError(result)
        raise TimeoutError(result)
    try:
        collect('HELLO ')
        send('CONFIG 1 100')
        prefix = '#include<cstdio>\n'
        suffix = 'freopen("sample.out","w",stdout);printf("%d\\n",n);}'
        source = prefix + 'int main(){int n=0;FILE*f=fopen("sample.in","r");fscanf(f,"%d",&n);fclose(f);' + suffix
        hostile = prefix + 'int main(){int n=2;FILE*f=fopen("sample.in","w");if(f){fputs("999",f);fclose(f);n=999;}' + suffix
        rows = []
        for tid, code, expected in ((1, source, 'AC'), (2, source, 'AC'), (3, hostile, 'AC'),
                                    (4, prefix+'int main(){freopen("sample.out","w",stdout);puts("999");}', 'WA'),
                                    (5, 'int main(){for(;;);}', 'TLE')):
            encoded = base64.b64encode(code.encode()).decode()
            send(f'TASK {tid} sample 150 128 0 1 {encoded}')
            lines = collect(f'DONE {tid}')
            compile_row = next(x.split() for x in lines if x.startswith(f'COMPILE {tid} '))
            test_row = next(x.split() for x in lines if x.startswith(f'TEST {tid} '))
            assert compile_row[2] == 'OK', lines
            assert test_row[3] == expected, lines
            if tid == 2:
                assert compile_row[-1] == 'HIT', lines
            assert (data / 'sample1.in').read_bytes() == b'2\n'
            rows.append({'id': tid, 'verdict': expected, 'cache': compile_row[-1]})
        artifacts = list((work / 'cache').glob('*/*.exe'))
        assert artifacts and all(p.name == 'test.exe' for p in artifacts)
        print(json.dumps({'checks': rows, 'runtime_names': sorted({p.name for p in artifacts}),
                          'input_unchanged': True, 'work': str(work)}, ensure_ascii=False), flush=True)
    finally:
        if proc.poll() is None:
            try:
                send('QUIT')
                proc.wait(timeout=8)
            except (OSError, subprocess.TimeoutExpired):
                proc.kill()
                proc.wait()


if __name__ == '__main__':
    main()
