"""Builds dist/OI-Sprint: payload (runtime bundle, agent) plus the frozen master."""
import hashlib
import os
import shutil
import subprocess
import sys
import tarfile
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BUILD = os.path.join(ROOT, "build", "oi-sprint")
RAW = os.path.join(BUILD, "raw")
WORKER = os.path.join(BUILD, "worker")
DIST = os.path.join(BUILD, "dist", "OI-Sprint-Classic")
PAYLOAD = os.path.join(DIST, "payload")
SRC = os.path.join(ROOT, "src")


def build_agent():
    subprocess.check_call(["g++", "-std=c++17", "-O2", "-static", "-municode", os.path.join(SRC, "agent", "agent.cpp"),
                           "-o", os.path.join(PAYLOAD, "oi-sprint-classic-agent.exe"), "-ladvapi32", "-lpsapi"])


def build_runtime_bundle():
    # gzip level 6: decent size, and fast enough to extract on slower nodes.
    path = os.path.join(PAYLOAD, "runtime.tar.gz")
    with tarfile.open(path, "w:gz", compresslevel=6) as tf:
        for name in ("mingw", "compat"):
            tf.add(os.path.join(WORKER, name), arcname=name)
    print("runtime bundle MB", os.path.getsize(path) >> 20)


def write_version():
    h = hashlib.sha256()
    for name in ("oi-sprint-classic-agent.exe", "runtime.tar.gz", "oi-sprint-relay.exe"):
        if not os.path.isfile(os.path.join(PAYLOAD,name)):continue
        with open(os.path.join(PAYLOAD, name), "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
    with open(os.path.join(PAYLOAD, "version.txt"), "w") as f:
        f.write(h.hexdigest()[:16])


def freeze(venv_python):
    work = os.path.join(BUILD, "pyi")
    subprocess.check_call([
        venv_python, "-m", "PyInstaller", "--noconfirm", "--clean", "--onedir", "--console", "--name", "OI-Sprint-Classic",
        "--distpath", os.path.join(BUILD, "dist_exe"), "--workpath", work, "--specpath", work,
        "--add-data", os.path.join(SRC, "master", "web") + os.pathsep + "web",
        "--paths", os.path.join(SRC, "master"), "--hidden-import", "scan", "--hidden-import", "judge", "--hidden-import", "contest", "--hidden-import", "discover", "--hidden-import", "transfer_worker", "--hidden-import", "relay",
        os.path.join(SRC, "master", "main.py"),
    ])
    frozen = os.path.join(BUILD, "dist_exe", "OI-Sprint-Classic")
    for item in os.listdir(frozen):
        dst = os.path.join(DIST, item)
        src = os.path.join(frozen, item)
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dst)
    shutil.copy2(os.path.join(SRC, "tools", "README.txt"), os.path.join(DIST, "README.txt"))


def main():
    steps = sys.argv[1:] or ["payload", "freeze"]
    os.makedirs(PAYLOAD, exist_ok=True)
    if "payload" in steps:
        build_agent()
        build_runtime_bundle()
    if "agent" in steps:
        build_agent()
    if "relay" in steps:
        relay_work=os.path.join(BUILD,"relay-pyi")
        subprocess.check_call([sys.executable,"-m","PyInstaller","--noconfirm","--onefile","--console","--name","oi-sprint-relay",
                               "--distpath",PAYLOAD,"--workpath",relay_work,"--specpath",relay_work,
                               "--paths",os.path.join(SRC,"master"),"--hidden-import","transfer_worker",
                               os.path.join(SRC,"master","relay_worker.py")])
    if any(step in steps for step in ("payload","agent","relay")):
        write_version()
    if "freeze" in steps:
        freeze(os.environ.get("OI_SPRINT_BUILD_PYTHON", sys.executable))


if __name__ == "__main__":
    main()
