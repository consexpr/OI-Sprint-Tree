"""Separate MinGW tree build. Reuse the already packaged toolchain; do not touch old ZIPs."""
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build'/'oi-sprint-tree'
DIST=BUILD/'OI-Sprint-Tree'
PAYLOAD=DIST/'payload'


def portable():
    # Explicit runtime-only allowlist. Never recurse into the live state folder.
    members=[DIST/'OI-Sprint-Tree.exe']
    members.extend(sorted((DIST/'_internal').rglob('*')))
    members.extend(PAYLOAD/name for name in ('oi-sprint-tree-agent.exe','oi-sprint-relay.exe','runtime.tar.gz','version.txt'))
    files=[path for path in members if path.is_file()]
    for required in (DIST/'OI-Sprint-Tree.exe',DIST/'_internal/python312.dll',*list(PAYLOAD/name for name in
                     ('oi-sprint-tree-agent.exe','oi-sprint-relay.exe','runtime.tar.gz','version.txt'))):
        if not required.is_file():raise FileNotFoundError(required)
    readme=(ROOT/'src/tools/README-Tree.txt').read_bytes()
    output=ROOT/'OI-Sprint-Tree-Portable.zip'
    temporary=output.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as archive:
        for path in files:
            if path.suffix.lower() in ('.pyc','.log','.db') or '__pycache__' in path.parts:continue
            archive.write(path,'OI-Sprint-Tree/'+path.relative_to(DIST).as_posix())
        archive.writestr('OI-Sprint-Tree/使用说明.txt',readme)
    os.replace(temporary,output)
    print(f'{output} ({output.stat().st_size/1048576:.1f} MiB)',flush=True)


def single_executable():
    work=BUILD/'single-pyi'
    command=[sys.executable,'-m','PyInstaller','--noconfirm','--onefile','--noconsole',
             '--name','OI-Sprint-Tree','--distpath',str(ROOT),'--workpath',str(work),'--specpath',str(work),
             '--paths',str(ROOT/'src/master'),'--add-data',str(ROOT/'src/master/web')+os.pathsep+'web',
             '--hidden-import','transfer_worker','--hidden-import','parallel_work','--hidden-import','topology']
    for name in ('oi-sprint-tree-agent.exe','oi-sprint-relay.exe','runtime.tar.gz','version.txt'):
        source=PAYLOAD/name
        if not source.is_file():raise FileNotFoundError(source)
        command.extend(['--add-data',str(source)+os.pathsep+'payload'])
    command.append(str(ROOT/'src/master/tree_main.py'))
    subprocess.check_call(command)
    print(ROOT/'OI-Sprint-Tree.exe',flush=True)


def main():
    if sys.argv[1:]==['onefile']:
        single_executable()
        return
    if sys.argv[1:]==['portable']:
        portable()
        return
    PAYLOAD.mkdir(parents=True,exist_ok=True)
    runtime=ROOT/'build'/'oi-sprint'/'dist'/'OI-Sprint-Classic'/'payload'/'runtime.tar.gz'
    if not (PAYLOAD/'runtime.tar.gz').is_file():shutil.copyfile(runtime,PAYLOAD/'runtime.tar.gz')
    steps=sys.argv[1:] or ['agent','relay','freeze']
    if 'agent' in steps:
        subprocess.check_call([r'D:\mingw64\bin\g++.exe','-std=c++17','-O2','-static','-municode','-DOI_SPRINT_TREE',
                               str(ROOT/'src'/'agent'/'agent.cpp'),'-o',str(PAYLOAD/'oi-sprint-tree-agent.exe'),'-ladvapi32','-lpsapi'])
    if 'relay' in steps:
        work=BUILD/'relay-pyi'
        subprocess.check_call([sys.executable,'-m','PyInstaller','--noconfirm','--onefile','--noconsole',
                               '--name','oi-sprint-relay','--distpath',str(PAYLOAD),'--workpath',str(work),'--specpath',str(work),
                               '--paths',str(ROOT/'src'/'master'),'--hidden-import','transfer_worker',
                               str(ROOT/'src'/'master'/'relay_worker.py')])
    digest=hashlib.sha256()
    for name in ('oi-sprint-tree-agent.exe','oi-sprint-relay.exe','runtime.tar.gz'):
        if not (PAYLOAD/name).is_file():continue
        with (PAYLOAD/name).open('rb') as source:
            while chunk:=source.read(1<<20):digest.update(chunk)
    (PAYLOAD/'version.txt').write_text(digest.hexdigest()[:16])
    if 'freeze' in steps:
        work=BUILD/'master-pyi'
        subprocess.check_call([sys.executable,'-m','PyInstaller','--noconfirm','--onedir','--console','--name','OI-Sprint-Tree',
                               '--distpath',str(BUILD/'frozen'),'--workpath',str(work),'--specpath',str(work),
                               '--paths',str(ROOT/'src'/'master'),'--add-data',str(ROOT/'src'/'master'/'web')+os.pathsep+'web',
                               '--hidden-import','transfer_worker','--hidden-import','relay','--hidden-import','provisioning',
                               str(ROOT/'src'/'master'/'tree_main.py')])
        shutil.copytree(BUILD/'frozen'/'OI-Sprint-Tree',DIST,dirs_exist_ok=True)
    print(DIST,flush=True)


if __name__=='__main__':main()
