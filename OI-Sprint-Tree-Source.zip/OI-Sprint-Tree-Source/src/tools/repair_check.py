"""Small targeted check: streaming export and two real local point reruns."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import io
import csv
import sqlite3

import repair_report as R

ROOT = Path(__file__).resolve().parents[2]


def check(executable=None, full=False):
    with tempfile.TemporaryDirectory(prefix="repair-check-", dir=ROOT / "build/oi-sprint") as folder:
        root = Path(folder)
        data = root / "data"
        data.mkdir()
        for n in range(1, 6):
            (data / f"p{n}.in").write_text(str(n) + "\n")
            (data / f"p{n}.ans").write_text(str(n) + "\n")
        code = '#include<cstdio>\nint main(){freopen("p.in","r",stdin);freopen("p.out","w",stdout);int n;scanf("%d",&n);if(n==4){volatile unsigned x=0;while(1)++x;}printf("%d\\n",n==2?10:n);}\n'
        code += '// <!-- legacy export escaping -->\n'
        tests = [[n, status, cpu, cpu, 2048, "old detail", node, 20 if status == "AC" else 0]
                 for n, status, cpu, node in [(1,"TLE",20,"192.168.112.42"), (2,"WA",7,"10.0.0.47"),
                                             (3,"TLE",201,"192.168.112.36"), (4,"TLE",10,"10.0.0.36"),
                                             (5,"AC",10,"10.0.0.48")]]
        sub = {"sid":"001", "prob":"p", "state":"done", "score":20, "code":code, "tests":tests,
               "compile":["OK",10,""], "reasons":[], "rewritten":False,"running_tests":[]}
        untouched = copy.deepcopy(sub)
        untouched.update(sid="002", code=code + "//" + "x" * 1100000)
        for t in untouched["tests"]:
            t[1], t[7] = "WA", 0
        untouched["score"] = 0
        meta = {"export":True,"generated":123,"name":"Repair check","contest":{"scale":False},
                "problems":[{"id":"p","name":"P","tl":200,"ml":128,"tests":5,"full":100}],
                "rows":[["001",20,[20],["TW TTA".replace(" ","")]],["002",0,[0],["WWWWW"]]],
                "status":{"AC":1,"WA":6,"TLE":3},"subs":{"001/p":sub,"002/p":untouched}}
        if full:
            # Include an old AC that must become WA, and both directions of CE.
            tests[1][1], tests[1][7] = "AC", 20
            sub["score"] = 40
            old_ce = copy.deepcopy(sub)
            old_ce.update(sid="003", compile=["CE",1,"old rejection"], score=0,
                          tests=[[n,None,0,0,0,"","",0] for n in range(1,6)])
            new_ce = copy.deepcopy(sub)
            new_ce.update(sid="004", code="int main( bad syntax", compile=["OK",1,""])
            meta["subs"].update({"003/p":old_ce,"004/p":new_ce})
        html = root / "original.html"
        template = (ROOT / "src/master/web/index.html").read_text(encoding="utf8")
        legacy = json.dumps(meta,ensure_ascii=False,separators=(",",":")).replace("</","<\\/").replace("<!--","<\\!--")
        original = template.replace("/*__EXPORT_DATA__*/null", legacy).encode("utf8")
        html.write_bytes(original)
        output = root / "repaired.html"
        runner = [str(executable)] if executable else [sys.executable,str(ROOT / "src/tools/repair_report.py")]
        cmd = runner[:]
        cmd += [str(html),"--data",str(data),"--output",str(output),"--no-scale","--yes","--mode","full" if full else "tle"]
        if full:
            cmd += ["--batch-size","1"]
        result = subprocess.run(cmd, input="\n", encoding="utf8", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
        print(result.stdout)
        assert result.returncode == (2 if full else 0), result.returncode
        if full:
            with R.JsonRange(output, *R.locate_json(output)) as f:
                partial = json.load(f)
            assert not partial["repair"]["complete"] and partial["repair"]["pending"] == 15
            work = Path(next(line.split("：",1)[1] for line in result.stdout.splitlines() if line.startswith("断点目录：")))
            output = root / "resumed.html"
            result = subprocess.run(runner + ["--resume",str(work),"--output",str(output),"--yes"], input="\n",
                                    encoding="utf8", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
            print(result.stdout)
            assert result.returncode == 0, result.returncode
        assert html.read_bytes() == original
        bounds = R.locate_json(output)
        with R.JsonRange(output, *bounds) as f:
            fixed = json.load(f)
        assert output.read_bytes().count(b'id="oi-sprint-repair-status"') == 1
        assert output.read_bytes()[bounds[1]:] == original[R.locate_json(html)[1]:]
        if full:
            assert fixed["repair"]["complete"] and fixed["repair"]["pending"] == 0
            assert fixed["repair"]["selected"] == fixed["repair"]["rerun"] == 20
            assert fixed["subs"]["001/p"]["tests"][1][1] == "WA"
            for sid in ("001","002","003"):
                assert fixed["subs"][sid+"/p"]["score"] == 60
                assert [t[1] for t in fixed["subs"][sid+"/p"]["tests"]] == ["AC","WA","AC","TLE","AC"]
                assert all(t[6] == "0.0.0.0" for t in fixed["subs"][sid+"/p"]["tests"])
            assert fixed["subs"]["004/p"]["compile"][0] == "CE"
            assert fixed["subs"]["004/p"]["score"] == 0
            assert fixed["status"] == {"AC":9,"WA":3,"TLE":3,"CE":5}, fixed["status"]
            print("PASS: legacy export escaping; full rejudge includes old AC/WA/TLE/CE, AC->WA, CE->OK, OK->CE; checkpoint/resume and totals consistent")
            return
        assert fixed["repair"]["selected"] == fixed["repair"]["rerun"] == 2
        assert fixed["repair"]["wa_selected"] == 0
        assert fixed["subs"]["002/p"] == untouched
        repaired = fixed["subs"]["001/p"]
        for i in (1, 2, 4):
            assert repaired["tests"][i] == tests[i], (i,repaired["tests"][i])
        assert repaired["tests"][0][1] == "AC"
        assert repaired["tests"][3][1] == "TLE"
        assert all(repaired["tests"][i][6] == "0.0.0.0" for i in (0,3))
        assert repaired["score"] == 40
        assert fixed["rows"][0] == ["001",40,[40],["AWTTA"]]
        assert fixed["status"] == {"AC":2,"WA":6,"TLE":2}
        print("PASS: two real reruns across different node ranges; original WA/other points/source report unchanged; score/strip/status consistent; >1MB streaming JSON valid")


def faults():
    with tempfile.TemporaryDirectory(prefix="repair-fault-",dir=ROOT / "build/oi-sprint") as folder:
        root=Path(folder)
        sub={"sid":"001","prob":"p","state":"done","score":0,"code":"int main(){}",
             "compile":["OK",1,""],"tests":[[1,"TLE",5,5,100,"","0.0.0.0",0],[2,"WA",5,5,100,"","old",0]]}
        meta={"name":"Fault check","problems":[{"id":"p","tl":100,"ml":128,"tests":2,"full":100}],"subs":{"001/p":sub}}
        html=root/'original.html'
        html.write_text('<body>\nconst EXPORT = '+R.json_text(meta)+';\n</body>',encoding='utf8')
        db=sqlite3.connect(':memory:')
        _,statuses,info=R.index_report(html,R.locate_json(html),meta,db,'full')
        class Fake:
            factor=1
            def __init__(self, lines): self.lines=iter(lines);self.tasks=[]
            def send(self, task): self.tasks.append(task)
            def line(self, deadline): return next(self.lines)
        first=Fake(['COMPILE 1 OK 1 -','TEST 1 1 SE 0 0 0 -','TEST 1 2 AC 1 1 100 -','DONE 1'])
        R.rerun(db,meta,first,statuses,info,csv.writer(io.StringIO()),False)
        assert R.pending_points(db)==1 and info['rerun']==1
        R.write_report(html,R.locate_json(html),root/'partial.html',meta,db,statuses,info)
        assert not info['complete']
        second=Fake(['COMPILE 1 OK 1 -','TEST 1 1 AC 1 1 100 -','DONE 1'])
        R.rerun(db,meta,second,statuses,info,csv.writer(io.StringIO()),False)
        assert second.tasks[0].split()[6]=='1'
        assert R.pending_points(db)==0 and info['rerun']==2
        R.write_report(html,R.locate_json(html),root/'done.html',meta,db,statuses,info)
        assert info['complete'] and {k:v for k,v in statuses.items() if v}=={'AC':2}
        print('PASS: SE on pre-existing repair marker remains pending; only pending point retried; incomplete report never marked complete')


if __name__ == "__main__":
    if '--faults' in sys.argv: faults()
    else: check(Path(sys.argv[1]).resolve() if len(sys.argv)>1 and sys.argv[1] != "--full" else None, "--full" in sys.argv)
