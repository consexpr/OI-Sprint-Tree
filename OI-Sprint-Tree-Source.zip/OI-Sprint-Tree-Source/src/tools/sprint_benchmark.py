"""One warm-cache comparison: one submission batch versus four independent points."""
import base64
import hashlib
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time

worker = Path(sys.argv[1]).resolve()
data = worker / "sprint_bench"
data.mkdir(exist_ok=True)
for i, iterations in enumerate((0, 120000000, 160000000, 200000000, 240000000)):
    (data / f"bench{i}.in").write_text(str(iterations), encoding="ascii")
    (data / f"bench{i}.ans").write_text("2\n", encoding="ascii")
source = ('#include<cstdio>\nint main(){freopen("bench.in","r",stdin);freopen("bench.out","w",stdout);'
          'unsigned n;scanf("%u",&n);volatile unsigned x=1;for(unsigned i=0;i<n;++i)x=x*1664525u+1013904223u;'
          'printf("2\\n");}\n')
process = subprocess.Popen([str(worker / "oi-sprint-agent.exe"), "serve", str(worker), data.name],
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           creationflags=0x08000000)
messages = queue.Queue()


def read():
    for line in process.stdout:
        messages.put(line.decode("ascii").strip().split())


threading.Thread(target=read, daemon=True).start()


def send(line):
    process.stdin.write((line + "\n").encode("ascii"))
    process.stdin.flush()


def task(tid, tests, memory=128):
    send(f"TASK {tid} bench 15000 {memory} 0 {tests} {base64.b64encode(source.encode()).decode()}")


def collect(ids):
    todo = set(ids)
    compiles = []
    while todo:
        message = messages.get(timeout=40)
        if message[0] == "FATAL":
            raise RuntimeError(message)
        if message[0] == "TEST":
            assert message[3] == "AC", message
        if message[0] == "COMPILE":
            assert message[2] == "OK", message
            compiles.append(message[-1])
        if message[0] == "DONE":
            todo.discard(int(message[1]))
    return compiles


try:
    hello = messages.get(timeout=45)
    assert hello[0] == "HELLO" and hello[-1] == "OI-SPRINT/3", hello
    send("CONFIG 1")
    task(1, "0")
    collect([1])
    start = time.perf_counter()
    task(2, "1,2,3,4")
    assert collect([2]) == ["HIT"]
    sequential = time.perf_counter() - start
    start = time.perf_counter()
    for tid in range(10, 14):
        task(tid, str(tid - 9))
    assert collect(range(10, 14)) == ["HIT"] * 4
    parallel = time.perf_counter() - start
    print(f"Warm cache, identical four inputs: grouped={sequential:.3f}s point_parallel={parallel:.3f}s ratio={sequential/parallel:.2f}x", flush=True)
    version = (worker / "VERSION").read_text()
    key = hashlib.sha256((version + "\n0\n128\nbench\n" + source).encode()).hexdigest()
    (worker / "cache" / (key + ".exe")).write_bytes(b"corrupted-cache-test")
    task(20, "0")
    assert collect([20]) == ["MISS"]
    task(21, "0", 129)
    assert collect([21]) == ["MISS"]
    print("PASS corrupt cache rebuild and stack/memory cache invalidation", flush=True)
finally:
    if process.poll() is None:
        send("QUIT")
        process.wait(timeout=8)
